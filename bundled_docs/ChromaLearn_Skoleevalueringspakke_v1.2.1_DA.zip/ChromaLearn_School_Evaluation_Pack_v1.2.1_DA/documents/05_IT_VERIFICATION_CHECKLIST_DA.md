# IT/EDB-verifikationscheckliste

## Før installation

- [ ] SHA-256 for `.deb` og source kontrolleret mod `SHA256SUMS.txt`
- [ ] source code gennemgået eller stikprøvekontrolleret
- [ ] testresultater genkørt lokalt
- [ ] testmaskinen er adskilt fra unødvendige produktionsdata
- [ ] pre-0.4 testinstallationer håndteres separat før pilot

## Roller

- [ ] almindelig Linux-bruger giver kun elevrolle
- [ ] lærergruppe testet
- [ ] admingruppe testet
- [ ] elev kan ikke fremtvinge lærer/admin via browser/API-request

## Sessionsdata

- [ ] session slettes ved aktiv reset
- [ ] idle timeout testet
- [ ] absolut timeout testet
- [ ] genstart nulstiller elevens session
- [ ] ingen session export endpoint fundet
- [ ] ingen elevhistorik gemmes af ChromaLearn

## Canary-test

Brug en unik, ikke-personlig markør, fx:

`CHROMALEARN-CANARY-[tilfældig streng]`

1. Indtast markøren i en testsession.
2. Gennemfør et kort læringsforløb.
3. Afslut/nulstil sessionen.
4. Stop ChromaLearn.
5. Brug `chromalearn-privacy-scan` på godkendte filområder.
6. Undersøg logs fra inference-server, proxy, container, journald og relevante sikkerhedsprodukter.
7. Dokumentér resultat, dato, softwareversioner og tester.

En ren filscan er ikke bevis for fravær i rå swap, hibernation, remote services eller snapshots.

## Modelserver

- [ ] prompt logging kendt og vurderet
- [ ] response logging kendt og vurderet
- [ ] metrics indeholder ikke prompttekst
- [ ] tracing/APM indeholder ikke prompttekst
- [ ] API-fejl logger ikke request body
- [ ] retention dokumenteret
- [ ] adgang til logs begrænset
- [ ] evt. underdatabehandlere dokumenteret

## Operativsystem

- [ ] journald/syslog vurderet
- [ ] swap vurderet
- [ ] hibernation vurderet
- [ ] core dumps vurderet
- [ ] temp/cache vurderet
- [ ] browser cache/extensions vurderet
- [ ] backup/snapshots vurderet
- [ ] fulddiskkryptering vurderet

## Netværk

- [ ] localhost-only hvor muligt
- [ ] TLS ved fjern-endpoint
- [ ] certifikatkontrol
- [ ] firewall
- [ ] DNS/proxy-politik
- [ ] ingen unødvendig internetadgang

## Resultat

- [ ] GO til begrænset pilot
- [ ] CONDITIONAL GO
- [ ] NO-GO

Åbne punkter:
Ansvarlig:
Dato:
