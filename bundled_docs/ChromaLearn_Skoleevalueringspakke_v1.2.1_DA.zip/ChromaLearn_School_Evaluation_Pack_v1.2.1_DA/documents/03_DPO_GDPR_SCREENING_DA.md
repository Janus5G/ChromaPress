# DPO/dataansvarlig - GDPR-screening

**Dette er en screeningsskabelon, ikke en færdig DPIA og ikke juridisk rådgivning.**

## A. Formål og nødvendighed

- Institution:
- Beslutningsejer:
- DPO/privacy-kontakt:
- Pilotperiode:
- Fag/klassetrin:
- Pædagogisk formål:
- Hvorfor er AI nødvendig eller sagligt nyttig til dette formål?
- Kan samme formål nås med mindre indgribende behandling?

## B. Data

Beskriv forventede datakategorier:

- [ ] almindeligt elevinput
- [ ] navn/elev-ID (bør som udgangspunkt undgås i pilot)
- [ ] skolearbejde
- [ ] lyd
- [ ] billeder
- [ ] særlige kategorier efter GDPR art. 9
- [ ] andre oplysninger

For hver kategori: begrund nødvendighed og hvor den behandles.

## C. Roller og leverandører

For hver komponent fastlægges og dokumenteres:

- dataansvarlig / databehandler / selvstændig dataansvarlig hvor relevant
- operatør
- fysisk/juridisk lokation
- underdatabehandlere
- eventuelle tredjelandsoverførsler
- databehandleraftale og øvrige kontraktuelle vilkår

At ChromaLearn kan køres lokalt uden udviklerdrevet cloudtjeneste betyder ikke i sig selv, at alle juridiske roller er afgjort. Rollen afhænger af den faktiske implementering og aftaler.

## D. Behandlingsgrundlag

- GDPR artikel 6-grundlag:
- Hvis art. 9-data forventes: særskilt grundlag/undtagelse:
- Er samtykke faktisk passende i skolekonteksten?:
- Nationale regler/hjemmel:
- Juridisk reviewer:

## E. GDPR-principper

Dokumentér:

- lovlighed, rimelighed og gennemsigtighed
- formålsbegrænsning
- dataminimering
- rigtighed
- opbevaringsbegrænsning
- integritet og fortrolighed
- ansvarlighed/dokumentation

## F. Privacy by design og sikkerhed

- Er standardkonfigurationen dataminimerende?
- Er elevsessionen teknisk tidsbegrænset?
- Er persistens gennem hele infrastrukturen verificeret?
- Er adgangsrettigheder passende?
- Er kommunikation krypteret, hvor den forlader localhost?
- Er sikkerhedsforanstaltninger regelmæssigt testet?

Relevante GDPR-bestemmelser omfatter bl.a. art. 5, 6, 9, 12-14, 25, 28, 30, 32 og 35 afhængigt af implementering.

## G. Børn og gennemsigtighed

Datatilsynet fremhæver, at børn har særlig beskyttelse. Information rettet til elever skal derfor være klar, enkel og alderssvarende.

- Elevinformation gennemgået:
- Forældreinformation nødvendig?:
- Kontaktpunkt for rettigheder:
- Hvordan forklares AI'ens begrænsninger?:

## H. DPIA-screening

Vurder om behandlingen sandsynligvis indebærer høj risiko for registreredes rettigheder og frihedsrettigheder. Hvis ja, gennemføres DPIA før behandlingen.

- DPIA krævet: Ja / Nej / Kræver yderligere vurdering
- Begrundelse:
- Reviewer:
- Dato:
