# Teknisk og privacy-overblik

## Datavej

Typisk datavej:

`Elevens browser -> ChromaLearn localhost-service -> skolens valgte inference-endpoint -> eventuel proxy/gateway -> modelserver -> svar tilbage`

Hver komponent er en selvstændig trust boundary og skal vurderes.

## ChromaLearn 0.4.5

Baseline-funktioner:

- elev, lærer og IT-administrator adskilt via Linux-roller/grupper
- ingen student-session export API
- ingen aktiv elev-chat-persistens
- ingen permanent adaptiv elevprofil
- idle-timeout og absolut sessionstimeout
- aktiv “afslut og nulstil session”
- applikationens HTTP access-log er deaktiveret
- administrator kan ikke via applikationens API slå permanent elevlagring til
- undervisningsprofiler kan gemmes som skolekonfiguration, men må ikke indeholde elevhistorik

## Infrastruktur, der skal verificeres særskilt

Før pilot skal IT gennemgå:

1. modelserverens prompt-/response-logging
2. reverse proxy/API gateway logging
3. Docker/Podman/container logging
4. systemd journal og syslog
5. swap og hibernation
6. systemd-coredump/core dumps
7. APM, tracing og debugging
8. browserextensions og endpoint-security software
9. backup, snapshots og hypervisor
10. netværkskryptering og certifikatvalidering
11. fjernleverandører, underdatabehandlere og eventuelle tredjelandsoverførsler

## “RAM-only” skal forstås præcist

RAM-only beskriver ChromaLearns applikationsdesign. Operativsystemet kan i visse konfigurationer skrive hukommelsessider til swap eller hibernation. Derfor skal skolen beslutte og dokumentere, om swap skal være deaktiveret, krypteret eller på anden måde accepteret i risikovurderingen.

## Historiske testversioner

0.4.5 foretager ingen automatisk oprydning af data fra pre-0.4 udviklings/testinstallationer. Hvis sådanne versioner har kørt, skal administratoren undersøge og rydde værten efter skolens egen dokumenterede procedure før pilot.

## Dokumentationsprincip

Dokumentér procedurer og systemkontroller frem for at gemme elevindhold “for en sikkerheds skyld”. Datatilsynet fremhæver dataminimering og opbevaringsbegrænsning som grundlæggende principper.
