# Udkast til elev-/forældreinformation

**Dette er et udkast. Skolen skal tilpasse det til sin faktiske behandling, retsgrundlag, leverandører og kontaktoplysninger.**

## Til eleven

Du bruger et AI-værktøj, der hedder ChromaLearn. AI'en skal hjælpe dig med at tænke selv. Den vil derfor ofte stille spørgsmål eller give hints i stedet for bare at give dig svaret.

AI kan tage fejl. Hvis noget virker forkert, eller du er i tvivl, skal du spørge din lærer.

I denne test er ChromaLearn indstillet til ikke at gemme din samtale eller din midlertidige læringsprofil mellem sessioner. Når sessionen slutter eller udløber, nulstilles ChromaLearns sessionshukommelse.

Skriv ikke følsomme eller private oplysninger om dig selv eller andre i chatten, medmindre læreren udtrykkeligt har sagt, at det er nødvendigt og godkendt.

Din lærer har ansvaret for undervisningen. AI'en bestemmer ikke din karakter, om du består, hvilket niveau du skal placeres på, eller om du får en sanktion.

Hvis du vil vide mere om, hvordan skolen bruger AI og behandler oplysninger, kan du kontakte [kontaktpunkt].

## Til forældre/værge

Skolen afprøver ChromaLearn som et begrænset, lærer-superviseret AI-læringsværktøj. Formålet er [indsæt konkret formål].

Skolen anvender følgende modelserver/leverandør: [indsæt].
Data sendes til: [indsæt].
Opbevaring/logning uden for ChromaLearn: [indsæt].
Retsgrundlag: [indsæt].
Dataansvarlig: [indsæt].
DPO/privacy-kontakt: [indsæt].

ChromaLearn-applikationen er designet til sessionsbaseret elevdata og gemmer ikke elevchat, checkpoint-svar eller adaptive læringsdata mellem sessioner. Skolens information skal dog beskrive hele den faktiske databehandling, herunder eventuelle eksterne systemer.
