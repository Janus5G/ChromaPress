# Kort beslutningsoplæg til skoleledelsen

## Hvad er ChromaLearn?

ChromaLearn er et open-source AI-læringsværktøj til Linux. Formålet er at lade elever bruge generativ AI som **vejleder** frem for som en maskine, der afleverer færdige besvarelser.

Elevforløbet er styret gennem trin som eget forsøg, diagnose, begrænset hint, refleksion og konsolidering. Læreren kan definere fag, klassetrin, opgavetype, hjælpeniveau og tilladte læringsformer. IT-administratoren vælger selv AI-model og inference-server.

## Hvorfor foreslås en pilot og ikke en fuld implementering?

Skolens konkrete anvendelse, valgte modelserver, logging, databehandlerforhold og pædagogiske brug afgør den endelige juridiske og sikkerhedsmæssige vurdering. Derfor bør ChromaLearn først afprøves som en lille, kontrolleret og lærer-superviseret pilot.

## Data og privatliv

ChromaLearn 0.4.5 gemmer ikke elevens samtale, checkpoint-svar eller adaptive læringsdata mellem sessioner. Disse data holdes i programmets RAM under den aktive session og slettes fra programmets sessionshukommelse ved udløb eller aktiv nulstilling.

Skolen skal særskilt verificere, om elevindhold kan blive gemt i modelserverlogs, proxy-/containerlogs, journald/syslog, swap, hibernation, crash dumps, browser/endpoint-telemetri, backups eller snapshots.

## Hvad ChromaLearn ikke er beregnet til

Baseline-piloten må ikke bruge ChromaLearn til karaktergivning, optagelse, placering, progression, disciplinære afgørelser eller automatisk overvågning af snyd. Systemet må heller ikke udvides med følelsesgenkendelse af elever i undervisningsmiljøet.

## Beslutningsforslag

Skoleledelsen kan godkende **teknisk og pædagogisk evaluering** under følgende forudsætninger:

- DPO/dataansvarlig eller relevant privacy-funktion gennemgår screeningspakken.
- IT verificerer den komplette datavej og udfører canary-test.
- Piloten bruger ikke unødvendige personoplysninger eller følsomme oplysninger.
- En lærer fører aktivt tilsyn.
- Ingen output bruges til konsekvensfulde beslutninger om eleven.
- Der er en navngiven stopansvarlig, som kan afbryde forsøget straks.
