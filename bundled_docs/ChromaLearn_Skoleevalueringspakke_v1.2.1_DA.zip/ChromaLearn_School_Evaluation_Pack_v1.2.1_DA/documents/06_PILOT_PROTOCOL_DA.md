# Pilotprotokol

## Formål

At teste om ChromaLearn kan støtte selvstændig læring uden at blive en genvej til færdige besvarelser, og samtidig verificere de tekniske privacy-kontroller i skolens konkrete miljø.

## Foreslået første pilot

- 1 lærer
- 1 IT/EDB-ansvarlig
- DPO/dataansvarlig/privacy-funktion involveret før elevtest
- lille, afgrænset elevgruppe
- ét fag og få lektioner
- ikke-følsomt undervisningsmateriale
- ingen karaktergivning eller konsekvensfulde elevbeslutninger
- kort, fast pilotperiode

## Før elevbrug

Alle følgende gates skal være grønne:

- ledelsesgodkendelse
- GDPR-screening
- AI Act-screening
- IT-verifikation
- modelserver/logging vurderet
- elevinformation klar
- lærerens AI-færdigheder/instruktion dokumenteret
- incident- og stopprocedure kendt

## Under pilot

Læreren observerer især:

- forsøger eleven selv før AI-hjælp?
- giver AI'en gradvise hints frem for afleveringsklar løsning?
- kan eleven efterfølgende forklare fremgangsmåden?
- kan eleven løse en tilsvarende opgave?
- opstår der hallucinationer/faglige fejl?
- prøver elever at omgå guardrails?
- fremkommer personoplysninger, som ikke var nødvendige?
- fungerer session reset og timeout?

## Hvad der ikke bør indsamles som standard

Pilotens evaluering bør så vidt muligt baseres på aggregerede eller lærerobserverede resultater frem for at gemme elevchat. Undgå at skabe en ny permanent elevprofil alene for at evaluere systemet.

## Stopkriterier

Piloten stoppes straks ved:

- utilsigtet vedvarende lagring af elevindhold
- væsentligt sikkerhedsbrud
- uklar/ulovlig dataoverførsel
- brug af output til ikke-godkendt elevbeslutning
- alvorlig eller gentagen pædagogisk skade
- aktivering af en funktion uden for den godkendte risikovurdering
- manglende mulighed for menneskeligt tilsyn

## Afsluttende evaluering

- Pædagogisk nytte:
- Selvstændig tænkning:
- Risiko for snyd:
- Faglig korrekthed:
- Privacy-verifikation:
- IT-drift:
- Elevforståelse af AI:
- Læreroplevelse:
- Hændelser:
- Forslag til ændringer:
- Beslutning: stop / ny pilot / begrænset implementering / yderligere juridisk vurdering
