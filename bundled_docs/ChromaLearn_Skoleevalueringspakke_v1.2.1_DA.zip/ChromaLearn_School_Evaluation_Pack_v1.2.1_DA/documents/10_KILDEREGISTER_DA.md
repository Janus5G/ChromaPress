# Kilderegister - juridisk og sektorspecifik vejledning

Kontrolleret 10. september 2026. Skolen bør kontrollere, om nyere konsoliderede tekster eller nationale vejledninger foreligger på tidspunktet for den faktiske pilot.

## Danske myndighedskilder

- **STIL mini-guide om lovlig brug af AI på uddannelsesinstitutioner (6. januar 2026):** https://stil.dk/aktuelt/2026/januar/060126_mini-guide-til-uddannelsesinstitutioner-om-lovlig-brug-af-kunstig-intelligens-ai/
- **STIL syvtrinsvejledning om lovlig brug af AI (2025):** https://stil.dk/aktuelt/2025/maj/250526-vejledning-til-uddannelsesinstitutioner-om-lovlig-brug-af-ai/
- **Datatilsynet - skoler og daginstitutioner:** https://www.datatilsynet.dk/regler-og-vejledning/skoler-og-daginstitutioner
- **Datatilsynet - grundlæggende GDPR-principper:** https://www.datatilsynet.dk/regler-og-vejledning/grundlaeggende-begreber/hvad-er-dine-forpligtelser/de-grundlaeggende-principper
- **Datatilsynet - anvendelse af personoplysninger som testdata:** https://www.datatilsynet.dk/regler-og-vejledning/behandlingssikkerhed/testdata-anvendelse-af-personoplysninger-ved-udvikling-og-test-af-it-systemer

## EU-retskilder

- **Databeskyttelsesforordningen (EU) 2016/679:** https://eur-lex.europa.eu/legal-content/DA/TXT/?uri=CELEX:32016R0679
- **EU AI Act, konsolideret tekst:** https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng
- **EU AI Act, EU-Tidende:** https://eur-lex.europa.eu/eli/reg/2024/1689/oj

## Centrale emner

- GDPR: formålsbegrænsning, dataminimering, opbevaringsbegrænsning, behandlingssikkerhed, privacy by design/default, databehandlerforhold og DPIA.
- Skoler og børn: særlig beskyttelse og alderssvarende transparens.
- Test/pilot: personoplysninger bliver ikke mindre beskyttelsesværdige, fordi behandlingen kaldes en test.
- AI Act: AI-færdigheder, forbudte praksisser, uddannelsesrelaterede højrisikokategorier, transparens, menneskeligt tilsyn, logging og eventuel fundamental-rights impact assessment.
