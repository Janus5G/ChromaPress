# Incident- og stopprocedure

## Formål

At sikre, at en pilot hurtigt kan afbrydes uden diskussion, hvis tekniske, juridiske eller pædagogiske forudsætninger ikke længere holder.

## Stopansvarlig

Navn:
Rolle:
Telefon:
E-mail:

Stedfortræder:

## Stop straks ved

- fund af elevindhold i ikke-godkendt persistent storage
- ukendt logning eller ukendt ekstern dataoverførsel
- kompromitterede credentials eller uautoriseret adgang
- alvorlig prompt-/output-lækage
- systemet bruges til karakter/progression/disciplin uden ny vurdering
- alvorlige hallucinationer i sikkerhedskritisk undervisningsindhold
- manglende lærer-overrule
- ny funktion aktiveret uden vurdering
- mistanke om persondatasikkerhedsbrud

## Ved stop

1. Afbryd elevadgang.
2. Bevar kun de oplysninger, der er nødvendige og lovlige for incident-håndtering.
3. Kontakt skolens IT-sikkerhedsansvarlige og DPO/privacy-funktion.
4. Kortlæg berørte systemer og data.
5. Følg skolens eksisterende procedure for persondatasikkerhedsbrud og eventuel anmeldelse.
6. Genåbn først efter skriftlig beslutning og dokumenteret remediation.

## Ændringsregel

Enhver væsentlig ændring i model, inference-host, logging, datatyper, brugergruppe, faglig anvendelse eller beslutningsformål udløser revurdering før fortsat brug.
