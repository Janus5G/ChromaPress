# Udkast - anmodning til skoleleder om test

**Emne: Anmodning om begrænset test og verifikation af open-source AI-læringsværktøjet ChromaLearn**

Kære [navn]

Jeg vil gerne høre, om skolen kunne være interesseret i at gennemføre en lille, kontrolleret evaluering af ChromaLearn AI.

ChromaLearn er et open-source læringsværktøj, hvor AI'en er designet til at hjælpe eleven gennem eget forsøg, spørgsmål, gradvise hints og refleksion frem for at levere en færdig afleveringsbesvarelse. Læreren styrer de pædagogiske rammer, mens skolens IT/EDB-ansvarlige selv vælger den AI-model og serverløsning, som skolen ønsker at vurdere.

Den aktuelle version er udviklet med sessionsbaseret elevdata som grundprincip. ChromaLearn gemmer ikke elevens samtale, checkpoint-svar eller adaptive læringsdata mellem sessioner. Vi ønsker dog ikke at fremsætte en generel påstand om, at hele skolens tekniske miljø dermed automatisk er databeskyttelsesmæssigt godkendt. Modelserver, logs, operativsystem, backup, databehandlerforhold og den konkrete undervisningsanvendelse skal vurderes af skolen.

Derfor er forslaget ikke en bred implementering, men en **test- og verifikationspilot**. Før elevbrug foreslås det, at skolens dataansvarlige/DPO eller relevante privacy-funktion gennemgår den medfølgende screeningspakke, og at IT verificerer den komplette datavej og logging.

En første pilot kan afgrænses til én lærer, et enkelt fag, en lille elevgruppe og få lektioner. ChromaLearn bør i denne pilot ikke bruges til karaktergivning, optagelse, placering, progression, disciplinære beslutninger eller eksamensovervågning.

Kildekode, Debian-pakke, checksums, teknisk dokumentation og screeningsskabeloner stilles til rådighed, så skolen selv kan inspicere og teste løsningen.

Formålet er at få en faglig vurdering af tre spørgsmål:

1. Hjælper systemet eleverne med at lære uden at overtage deres arbejde?
2. Fungerer de beskrevne privacy- og sikkerhedskontroller i skolens eget miljø?
3. Kan løsningen anvendes inden for skolens egne juridiske, etiske og pædagogiske rammer?

Med venlig hilsen

Janus Rokkjær  
ChromaLearn AI - open-source projekt
