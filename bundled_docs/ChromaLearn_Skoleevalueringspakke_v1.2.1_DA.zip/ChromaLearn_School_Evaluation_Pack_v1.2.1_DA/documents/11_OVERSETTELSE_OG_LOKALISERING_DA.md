# Oversættelse og lokalisering

Dansk er det officielle referencesprog for denne evalueringspakke og for den danske ChromaLearn-pilot.

ChromaLearn 0.4.5 indeholder kommandoen:

```bash
chromalearn-translate <fil> --language <målsprog> --code <sprogkode>
```

Eksempel:

```bash
chromalearn-translate docs/ARCHITECTURE.md --language English --code en
```

Værktøjet bruger den OpenAI-kompatible AI-backend, som skolen selv har konfigureret. Det betyder, at indholdet i den valgte fil sendes til denne backend. Funktionen er derfor **kun** til statiske projekt-, UI- og dokumentationsfiler, som må behandles af den valgte AI-tjeneste.

Værktøjet må ikke bruges til elevchat, sessionsdata, checkpoint-svar, personhenførbare opgaver, logs med personoplysninger, API-nøgler eller credentials.

Alle AI-oversættelser markeres som kladder. Særligt juridiske, privacy- og elev-/forældretekster skal gennemgås af et menneske før officiel anvendelse. AI-oversættelse er en hjælp til bidragydere - ikke en automatisk juridisk godkendelse.
