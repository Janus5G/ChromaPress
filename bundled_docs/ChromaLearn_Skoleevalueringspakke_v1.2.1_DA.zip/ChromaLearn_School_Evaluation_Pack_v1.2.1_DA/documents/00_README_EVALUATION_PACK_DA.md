# ChromaLearn School Evaluation Pack v1.2.1 - dansk udgave

**Softwarebaseline:** ChromaLearn AI 0.4.5  
**Evalueringspakkens dato:** 10. september 2026  
**Formål:** kontrolleret teknisk, pædagogisk og juridisk/privacy-mæssig vurdering før anvendelse på en dansk skole.

Dette er en test- og verifikationspakke. Den er **ikke** et compliance-certifikat og er ikke juridisk rådgivning.

## Anbefalet rækkefølge

1. Skoleledelsen definerer den konkrete pilot og navngiver beslutningsejer.
2. IT/EDB verificerer den faktiske implementeringsarkitektur, herunder valgt AI-/inference-backend.
3. Dataansvarlig/DPO gennemfører GDPR- og AI Act-screeningen.
4. Læreren gennemgår de pædagogiske grænser og pilotprotokollen.
5. Kun hvis alle obligatoriske gates er grønne, gennemføres en lille lærer-superviseret pilot.
6. Stop og revurdér ved ændringer i anvendelse, model, dataflow eller beslutningsformål.

## Medfølgende software

- `software/chromalearn_0.4.5_all.deb`
- `software/chromalearn-ai-0.4.5-source.zip`
- `SHA256SUMS.txt`

ChromaLearn 0.4.5 bygger funktionelt videre på den tidligere teknisk verificerede 0.4.4-baseline og ændrer ikke læringsmotor, roller eller den sessionsbaserede privacy-model. 0.4.5 gør dansk til referencesprog og tilføjer et AI-assisteret oversættelsesværktøj til statiske projektfiler.

## Central arkitekturpåstand

ChromaLearn er designet, så elevsamtaler, checkpoint-svar og adaptiv læringsevidens kun findes i processens hukommelse under den aktive session og ikke gemmes af applikationen mellem sessioner. Undervisningsprofiler og IT-konfiguration kan gemmes, men må ikke indeholde elevspecifik læringshistorik.

Dette dækker ikke automatisk modelserver, reverse proxy, container-runtime, browser, operativsystemets swap/hibernation, crash dumps, backups, snapshots, endpoint-security eller tredjepartstelemetri. Skolen skal verificere disse dele særskilt, før der fremsættes en end-to-end-påstand om, at elevindhold ikke opbevares.

## Dansk som referencesprog

Materialet i denne pakke er på dansk og er referencesprog for den danske skolepilot. ChromaLearn 0.4.5 indeholder `chromalearn-translate`, som kan lave AI-assisterede **oversættelseskladder** til andre sprog af statiske `.md`, `.txt` og `.json`-filer.

Maskinoversatte juridiske, privacy- eller elev-/forældretekster skal altid menneskegennemgås før officiel brug. Elevsessioner og personoplysninger må ikke anvendes som input til oversættelsesfunktionen.

## Historiske testinstallationer

ChromaLearn 0.4.5 udfører ingen automatisk oprydning af data fra tidligere udviklings-/testversioner. Hvis en skole har anvendt en pre-0.4 testversion, skal den relevante vært gennemgås og eventuelle historiske testdata håndteres af administratoren uden for ChromaLearn efter skolens egne dokumenterede procedurer.
