# EU AI Act - anvendelses- og risikoscreening

**Kontrollér altid den aktuelle konsoliderede EU-tekst ved implementering. Denne skabelon erstatter ikke juridisk rådgivning.**

## 1. Tilsigtet anvendelse

- Beskriv præcist, hvad ChromaLearn skal bruges til:
- Hvem anvender systemet?
- Hvem påvirkes?
- Hvilke funktioner er aktiveret?

## 2. Forbudte praksisser - stopgate

Piloten må ikke fortsætte, hvis en funktion falder inden for en forbudt praksis. Særligt relevant for uddannelse:

- ChromaLearn må ikke bruges til AI-baseret følelsesinferens af elever/personer i uddannelsesinstitutioner, bortset fra eventuelle snævre lovbestemte medicinske/sikkerhedsmæssige undtagelser.
- Manipulerende eller vildledende design må ikke udnytte elevers sårbarhed på en måde omfattet af forbuddene.

Resultat: PASS / STOP / Juridisk vurdering

## 3. Annex III - uddannelsesbrug

Vurder om den **tilsigtede anvendelse** falder i en Annex III-kategori, herunder:

- adgang/optagelse eller tildeling til uddannelsesinstitution
- evaluering af læringsresultater, herunder når resultater bruges til at styre læringsprocessen
- vurdering af passende uddannelsesniveau
- overvågning/opdagelse af forbudt adfærd under prøver

ChromaLearns formative checkpoint og anbefaling af næste undervisningsform kan være relevant for vurderingen af “evaluering af læringsresultater ... til at styre læringsprocessen”. Sessionsbaseret data gør ikke i sig selv anvendelsen ikke-højrisiko.

## 4. Begrænsning af pilotens anvendelse

Baseline-pilot:

- ingen karaktergivning
- ingen optagelse/adgang
- ingen placering
- ingen progression
- ingen disciplinære beslutninger
- ingen eksamens-/snydovervågning
- ingen emotion recognition
- lærer kan tilsidesætte og ignorere AI-output
- AI-output er vejledning, ikke bindende beslutning

## 5. Hvis anvendelsen vurderes højrisiko

Vurder og dokumentér mindst:

- leverandør-/provider-rolle og deployer-rolle
- brugsinstruktioner og teknisk dokumentation
- menneskeligt tilsyn
- logging/record-keeping
- monitorering og incident-håndtering
- relevante informationsforpligtelser
- AI-færdigheder hos personale
- om fundamental-rights impact assessment efter art. 27 er påkrævet
- samspil med GDPR/DPIA

Hvis systemet er højrisiko, kan AI Act kræve, at automatisk genererede logs under deployerens kontrol opbevares i mindst seks måneder, medmindre anden EU-/national ret, herunder databeskyttelsesret, bestemmer andet. Det er derfor forkert at gøre “ingen elevchat gemmes” synonymt med “ingen regulatoriske logs må eksistere”. Eventuelle nødvendige audit-logs bør dataminimeres og designes til ikke at indeholde unødvendigt elevindhold.

## 6. Transparens

Eleven skal tydeligt kunne forstå, at vedkommende interagerer med AI, og hvem der er ansvarlig for skolens anvendelse. Gør det tydeligt, at AI kan tage fejl, og at læreren har det menneskelige ansvar.

## 7. AI-færdigheder

Skolen bør dokumentere passende instruktion/uddannelse af de medarbejdere, der konfigurerer eller anvender systemet, med hensyn til deres rolle og kontekst.

## 8. Konklusion

- Klassifikation:
- Begrundelse:
- Krævede afhjælpninger:
- Godkendt anvendelsesområde:
- Forbudte anvendelser lokalt:
- Reviewer:
- Dato:
- Næste revurdering:
