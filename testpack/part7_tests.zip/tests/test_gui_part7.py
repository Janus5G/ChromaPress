import os; os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
import pytest
pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication, QMessageBox

from chromapress.gui.production_page import ProductionWorkflowPage
from chromapress.gui.changes import ChangesPanel
from chromapress.models import ProjectState, SourceState, ChangeStatus

SHA="a"*64

@pytest.fixture(scope="module")
def qapp(): return QApplication.instance() or QApplication([])

@pytest.fixture(autouse=True)
def no_modal(monkeypatch):
    for name in ("warning","information","critical"):
        monkeypatch.setattr(QMessageBox,name,lambda *a,**k:None)


def project():
    p=ProjectState(name="GUI Production")
    p.source=SourceState(path=r"E:\\ISO\\source.iso",distribution="Ubuntu",version="26.04",architecture="amd64",sha256=SHA,package_format="deb")
    return p


def test_part7_gui_requires_source_and_preflight_before_stage(qapp):
    page=ProductionWorkflowPage(); assert not page.stage_btn.isEnabled()
    page.set_project(project()); assert not page.stage_btn.isEnabled()
    page.output_dir.setText(r"E:\\Builds"); page.output_name.setText("out.iso")
    assert not page.stage_btn.isEnabled()
    page.preflight(); assert page.stage_btn.isEnabled(); assert "PASS" in page.preflight_status.text()
    page.output_name.setText("changed.iso"); assert not page.stage_btn.isEnabled()


def test_part7_gui_stage_changes_test_and_undo(qapp):
    page=ProductionWorkflowPage(); page.set_project(project()); page.output_dir.setText(r"E:\\Builds"); page.output_name.setText("out.iso"); page.preflight()
    changes=ChangesPanel(); page.stage_requested.connect(changes.add_change); page.stage()
    assert len(changes.changes)==1
    changes.list.setCurrentRow(0); changes._test_selected(); assert changes.changes[0].status==ChangeStatus.PASS
    changes._undo_selected(); assert len(changes.changes)==0


def test_part7_gui_does_not_fake_production_presets(qapp):
    page=ProductionWorkflowPage(); page.set_project(project())
    assert page.preset.count()==1 and page.preset.itemData(0)==""
