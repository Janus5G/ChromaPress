from pathlib import Path
import json
import pytest

from chromapress.models import ProjectState, SourceState, ChangeItem, ChangeKind
from chromapress.services.part7 import (
    create_profile, validate_profile, save_profile, load_profile, diff_profiles,
    profile_change_items, compare_sources, compare_change_plans,
    available_production_presets, make_expert_hook, create_build_plan_payload,
    validate_build_plan_payload, production_change,
)
from chromapress.services.preflight import test_change as preflight_change

SHA="a"*64


def project():
    p=ProjectState(name="Demo")
    p.source=SourceState(path=r"E:\\ISO\\source.iso",distribution="Ubuntu",version="26.04",architecture="amd64",sha256=SHA,installer="Subiquity/Autoinstall",package_format="deb")
    p.scenario="development"
    p.changes=[ChangeItem("Pkg",ChangeKind.PACKAGE_REPOSITORY,"demo",{"package":"git","manager":"apt"})]
    return p


def test_profile_roundtrip_is_inspectable_and_deterministic(tmp_path):
    p=project(); prof=create_profile(p,"Demo Profile",{"output_dir":r"E:\\Builds","output_name":"demo.iso"})
    ok,msg=validate_profile(prof); assert ok,msg
    path=tmp_path/"demo.chromapress-profile"; save_profile(prof,path); loaded=load_profile(path)
    assert loaded==prof
    assert prof["profile_fingerprint"]==create_profile(p,"Demo Profile",{"output_dir":r"E:\\Builds","output_name":"demo.iso"})["profile_fingerprint"]
    assert "created_at" not in json.dumps(prof) and '"id"' not in json.dumps(prof)


def test_profile_blocks_real_secret_like_values():
    p=project(); p.changes.append(ChangeItem("bad",ChangeKind.CONFIG,"bad",{"api_key":"super-secret-value-123456"}))
    with pytest.raises(ValueError): create_profile(p,"Bad Profile")


def test_profile_import_requires_matching_source_and_recreates_plan():
    p=project(); prof=create_profile(p,"Importable")
    items=profile_change_items(prof,SHA)
    assert len(items)==1 and items[0].payload["package"]=="git"
    with pytest.raises(ValueError): profile_change_items(prof,"b"*64)


def test_profile_diff_compares_source_scenario_and_changes():
    a=project(); b=project(); b.changes.append(ChangeItem("Pkg2",ChangeKind.PACKAGE_REPOSITORY,"demo",{"package":"curl","manager":"apt"}))
    pa=create_profile(a,"A"); pb=create_profile(b,"B")
    d=diff_profiles(pa,pb)
    assert not d["same"] and d["source"]["same"] and len(d["changes"]["added"])==1
    assert compare_sources(pa["source"],pb["source"])["same"]
    assert not compare_change_plans(pa["changes"],pb["changes"])["same"]


def test_production_presets_never_exposed_without_underlying_capabilities():
    p=project(); assert available_production_presets(p)==[]
    p.changes += [
        ChangeItem("Kiosk",ChangeKind.CONFIG,"",{"config_type":"part5_kiosk_session","mode":"browser_kiosk"}),
        ChangeItem("Volatile",ChangeKind.CONFIG,"",{"config_type":"runtime_integration","integration_target":"volatile_overlay"}),
    ]
    ids={x["id"] for x in available_production_presets(p)}
    assert "immutable_browser_kiosk" in ids and "volatile_kiosk" in ids


def test_expert_hook_requires_review_and_is_sha_locked(tmp_path):
    hook_path=tmp_path/"hook.sh"; hook_path.write_text("#!/bin/sh\necho ok\n")
    hook=make_expert_hook(hook_path,"pre_build","bash",True)
    assert len(hook["sha256"])==64 and hook["human_reviewed"] is True
    assert hook["may_bypass_preflight"] is False and hook["may_mutate_source_iso"] is False


def test_build_plan_is_source_locked_output_bounded_and_preflighted(tmp_path):
    p=project(); hook_path=tmp_path/"hook.sh"; hook_path.write_text("echo ok\n")
    hook=make_expert_hook(hook_path,"pre_build","bash",True)
    payload=create_build_plan_payload(p,output_dir=r"E:\\Builds",output_name="demo.iso",compression="preserve",verification_policy="sha256_boot_structure",expert_hooks=[hook])
    ok,msg=validate_build_plan_payload(payload); assert ok,msg
    change=production_change(payload); status,message=preflight_change(change)
    assert status.value=="PASS",message
    assert payload["source_read_only"] and payload["overwrite_existing_output"] is False and payload["stage_only"]


def test_build_plan_blocks_source_overwrite():
    p=project()
    with pytest.raises(ValueError, match="source ISO"):
        create_build_plan_payload(p,output_dir=r"E:\\ISO",output_name="source.iso")


def test_build_plan_blocks_unreviewed_hook(tmp_path):
    p=project(); f=tmp_path/"hook.sh"; f.write_text("echo ok\n")
    hook=make_expert_hook(f,"pre_build","bash",False)
    with pytest.raises(ValueError): create_build_plan_payload(p,output_dir=r"E:\\Builds",output_name="demo.iso",expert_hooks=[hook])
