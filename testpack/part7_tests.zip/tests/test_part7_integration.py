from pathlib import Path


def root(): return Path.cwd()


def test_part7_testpack_files_exist():
    r=root()
    for name in ("part7_tests.zip","part7_tests.zip.sha256","part7_manifest.json"):
        assert (r/"testpack"/name).is_file()


def test_acceptance_runs_part7_after_prior_packs():
    text=(root()/"chromapress_acceptance.py").read_text()
    for n in (4,5,6,7): assert f"_run_testpack({n})" in text
    assert "PART7_TESTPACK=" in text and "PART7_STAGED_GATES=" in text


def test_testpack_reports_part7_gui_gate():
    text=(root()/"chromapress_testpack.py").read_text()
    assert "junit_part7_summary" in text and "part7_staged_gate_status" in text


def test_part7_version_markers():
    r=root()
    assert 'version = "1.0.0a72"' in (r/"pyproject.toml").read_text()
    assert '__version__ = "1.0.0a72"' in (r/"src/chromapress/__init__.py").read_text()


def test_build_verify_page_is_real_part7_page_not_old_disabled_placeholder():
    main=(root()/"src/chromapress/gui/main_window.py").read_text()
    assert "ProductionWorkflowPage" in main
    assert "_stage_part7_change" in main and "_guard_part7_plan_source" in main
