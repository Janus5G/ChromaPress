from pathlib import Path
from chromapress.engine_cli import _installer_evidence
from chromapress.services.part5 import installer_capability, desktop_capability, kiosk_capability


def test_installer_detection_does_not_infer_from_distribution_name():
    e=_installer_evidence(["/casper/filesystem.squashfs"], {"base-files":"1"})
    assert e["installer"]=="unknown"


def test_explicit_package_manifest_drives_installer_family():
    e=_installer_evidence(["/casper/filesystem.squashfs"], {"subiquity":"1"})
    assert e["installer"]=="Subiquity/Autoinstall"
    cap=installer_capability(e["installer"],"deb",e["installer_evidence"],e["installer_config_files"])
    assert cap["capability_status"]=="SUPPORTED_WITH_REQUIREMENTS"


def test_kiosk_is_generic_and_not_provider_bound():
    d=desktop_capability({"plasma-desktop":"6","firefox":"1"}); k=kiosk_capability({"plasma-desktop":"6","firefox":"1"},d)
    assert k["provider_or_website_hardcoded"] is False and "browser_kiosk" in k["supported_modes"]


def test_part5_testpack_files_exist():
    root=Path(__file__).resolve().parents[1]
    assert (root/"testpack/part5_tests.zip").is_file()
    assert (root/"testpack/part5_tests.zip.sha256").is_file()
    assert (root/"testpack/part5_manifest.json").is_file()


def test_acceptance_runs_separate_part4_and_part5_testpacks():
    root=Path(__file__).resolve().parents[1]
    text=(root/"chromapress_acceptance.py").read_text()
    assert '_run_testpack(4)' in text
    assert '_run_testpack(5)' in text
    assert 'PART5_TESTPACK=' in text
    assert 'PART5_STAGED_GATES=' in text


def test_consolidated_runner_supports_part_selection():
    root=Path(__file__).resolve().parents[1]
    text=(root/"chromapress_testpack.py").read_text()
    assert '"--part"' in text
    assert 'partN_tests.zip'.replace('N','{part}') not in text or 'part{part}_tests.zip' in text


def test_part5_gui_pack_suppresses_modal_test_result_dialogs():
    root=Path(__file__).resolve().parents[1]
    gui=(root/"tests/test_gui_part5.py").read_text()
    assert 'QMessageBox, "information"' in gui
    assert 'no_modal_message_boxes' in gui


def test_testpack_has_inner_timeout_shorter_than_acceptance_timeout():
    root=Path(__file__).resolve().parents[1]
    text=(root/"chromapress_testpack.py").read_text()
    assert 'timeout=120' in text


def test_testpack_prepare_preserves_unrelated_future_part_files(tmp_path):
    import hashlib
    import zipfile
    from chromapress_testpack import safe_prepare_tests, cleanup_tests

    root=tmp_path
    tests=root/"tests"
    tests.mkdir()
    future=tests/"test_future_part6.py"
    future.write_text("def test_future():\n    assert True\n", encoding="utf-8")
    current_bytes=b"def test_current():\n    assert True\n"
    bundle=root/"part4_tests.zip"
    with zipfile.ZipFile(bundle,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("tests/test_current_part4.py", current_bytes)
    digest=hashlib.sha256(current_bytes).hexdigest()
    manifest={"tests/test_current_part4.py":digest}
    paths,preexisting,interrupted=safe_prepare_tests(root,4,bundle,manifest,{})
    assert future.is_file()
    assert [p.name for p in paths]==["test_current_part4.py"]
    cleanup_tests(root,4,manifest,preexisting,interrupted)
    assert future.is_file()
    assert not (tests/"test_current_part4.py").exists()


def test_testpack_pytest_commands_are_scoped_to_active_part_paths():
    root=Path(__file__).resolve().parents[1]
    text=(root/"chromapress_testpack.py").read_text()
    assert "def _pytest_targets" in text
    assert "*_pytest_targets(root, test_paths)" in text
    assert "unrelated files are left untouched" in text
