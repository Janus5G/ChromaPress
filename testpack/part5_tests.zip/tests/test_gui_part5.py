import os; os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
import pytest
pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication, QMessageBox
from chromapress.gui.installer_page import InstallerPage
from chromapress.gui.files_page import FilesPage
from chromapress.gui.desktop_page import DesktopPage
from chromapress.gui.changes import ChangesPanel
from chromapress.models import ChangeStatus

@pytest.fixture(scope="module")
def qapp(): return QApplication.instance() or QApplication([])

@pytest.fixture(autouse=True)
def no_modal_message_boxes(monkeypatch):
    # ChangesPanel._test_selected() reports results through QMessageBox.information.
    # In the offscreen Windows acceptance runner that dialog is intentionally
    # non-interactive, so suppress both modal message-box paths for every GUI test.
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)

def analysis():
    return {"sha256":"a"*64,"installer":"Subiquity/Autoinstall","installer_modes":["Autoinstall family detected"],"installer_evidence":[{"value":"subiquity","version":"1"}],"installer_config_files":[],
            "part5_installer_evidence":{"capability_status":"SUPPORTED_WITH_REQUIREMENTS","analysis_scope":"target_iso_installer_evidence","installer_family":"Subiquity/Autoinstall","native_generator":"autoinstall","reason":"ok"},
            "part5_custom_content_evidence":{"capability_status":"SUPPORTED_WITH_REQUIREMENTS","analysis_scope":"target_iso_rootfs_metadata","reason":"ok"},
            "part5_desktop_evidence":{"capability_status":"SUPPORTED_WITH_REQUIREMENTS","analysis_scope":"target_iso_package_manifest","active_desktop":"LXQt","native_adapter":"lxqt-config","reason":"ok"},
            "part5_kiosk_evidence":{"capability_status":"SUPPORTED_WITH_REQUIREMENTS","analysis_scope":"target_iso_package_manifest","supported_modes":["browser_kiosk","custom_application_kiosk","minimal_wayland_weston"],"weston_verified":True,"browser_packages":["firefox"],"reason":"ok"}}

def test_gui_part5_installer_stage_test_undo(qapp,monkeypatch):
    monkeypatch.setattr(QMessageBox,"warning",lambda *a,**k:None)
    p=InstallerPage(); p.set_analysis(analysis()); c=ChangesPanel(); p.stage_requested.connect(c.add_change)
    p.username.setText("tester"); p.display_name.setText("Test User"); p.hostname.setText("test-host"); p.stage_btn.click()
    assert len(c.changes)==1 and "CHROMAPRESS_PASSWORD_HASH" in c.changes[0].payload["generated_native_template"]
    c.list.setCurrentRow(0); c._test_selected(); assert c.changes[0].status==ChangeStatus.PASS; c._undo_selected(); assert c.changes==[]

def test_gui_part5_installer_unknown_fails_closed(qapp):
    a=analysis(); a["part5_installer_evidence"]={"capability_status":"UNKNOWN","analysis_scope":"target_iso_installer_evidence","reason":"unknown"}
    p=InstallerPage(); p.set_analysis(a); assert not p.stage_btn.isEnabled()

def test_gui_part5_files_stage_test_undo(qapp,tmp_path,monkeypatch):
    monkeypatch.setattr(QMessageBox,"warning",lambda *a,**k:None)
    f=tmp_path/"x.txt"; f.write_text("x")
    p=FilesPage(); p.set_analysis(analysis()); p._append_sources([str(f)]); c=ChangesPanel(); p.stage_requested.connect(c.add_change); p.stage_btn.click()
    assert len(c.changes)==1 and c.changes[0].payload["target_root"]=="/etc/skel/"
    c.list.setCurrentRow(0); c._test_selected(); assert c.changes[0].status==ChangeStatus.PASS; c._undo_selected(); assert c.changes==[]

def test_gui_part5_desktop_stage_test_undo(qapp,monkeypatch):
    monkeypatch.setattr(QMessageBox,"warning",lambda *a,**k:None)
    p=DesktopPage(); p.set_analysis(analysis()); p.wallpaper.setText("/usr/share/backgrounds/a.jpg"); c=ChangesPanel(); p.stage_requested.connect(c.add_change); p.stage_desktop_btn.click()
    assert len(c.changes)==1; c.list.setCurrentRow(0); c._test_selected(); assert c.changes[0].status==ChangeStatus.PASS; c._undo_selected(); assert c.changes==[]

def test_gui_part5_kiosk_stage_test_undo(qapp,monkeypatch):
    monkeypatch.setattr(QMessageBox,"warning",lambda *a,**k:None)
    p=DesktopPage(); p.set_analysis(analysis()); idx=p.kiosk_mode.findData("browser_kiosk"); p.kiosk_mode.setCurrentIndex(idx); p.kiosk_target.setText("https://example.org")
    c=ChangesPanel(); p.stage_requested.connect(c.add_change); p.stage_kiosk_btn.click(); assert len(c.changes)==1
    c.list.setCurrentRow(0); c._test_selected(); assert c.changes[0].status==ChangeStatus.PASS; c._undo_selected(); assert c.changes==[]

def test_gui_part5_headless_unknown_hides_controls(qapp):
    a=analysis(); a["part5_desktop_evidence"]={"capability_status":"UNKNOWN","analysis_scope":"target_iso_package_manifest","reason":"none"}; a["part5_kiosk_evidence"]={"capability_status":"UNKNOWN","supported_modes":[],"reason":"none"}
    p=DesktopPage(); p.set_analysis(a); assert not p.stage_desktop_btn.isEnabled() and not p.stage_kiosk_btn.isEnabled()
