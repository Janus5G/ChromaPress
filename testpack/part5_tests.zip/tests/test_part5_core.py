from pathlib import Path
import io
import tarfile
import pytest

from chromapress.models import ChangeItem, ChangeKind, ChangeStatus, SourceState
from chromapress.services.preflight import test_change as run_preflight
from chromapress.services.part5 import (
    installer_capability, desktop_capability, custom_content_capability, kiosk_capability,
    generate_installer_template, validate_installer_payload, inspect_custom_content,
    validate_custom_content_payload, validate_desktop_payload, validate_kiosk_payload,
)

SHA = "a" * 64


def installer_payload(generator="autoinstall", status="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "config_type":"part5_installer_profile","part":5,"gate_version":"part5-complete","source_sha256":SHA,
        "analysis_scope":"target_iso_installer_evidence","capability_status":status,"installer_family":"Subiquity/Autoinstall",
        "native_generator":generator,"control_depth":"advanced","username":"janus","display_name":"Janus Test",
        "groups":["audio","video"],"admin":True,"credential_policy":"secure_hash_deferred_to_verified_apply",
        "hostname":"test-host","language":"en","locale":"en_US.UTF-8","keyboard":"us","timezone":"Europe/Copenhagen",
        "network_mode":"dhcp","ipv4_address":"","gateway":"","dns_servers":[],"package_selections":["curl","vim"],
        "installer_profile":"standard","installation_behavior":"interactive_reviewed","partitioning":"preserve_installer_default",
        "destructive_partitioning_confirmed":False,"credential_secret_read":False,"credential_secret_staged":False,
        "native_tool_validation_performed":False,"require_native_tool_validation_before_apply":True,
        "require_secure_credential_material_before_apply":True,"require_source_reverification_before_apply":True,
        "source_read_only":True,"preserve_unrelated":True,"stage_only":True,
    }


def test_installer_capability_is_family_evidence_bound():
    assert installer_capability("Subiquity/Autoinstall","deb",[],[])["native_generator"] == "autoinstall"
    assert installer_capability("Anaconda/Kickstart","rpm",[],[])["native_generator"] == "kickstart"
    assert installer_capability("Debian Installer/Preseed","deb",[],[])["native_generator"] == "preseed"
    assert installer_capability("Calamares","deb",[],[])["capability_status"] == "UNSUPPORTED"
    assert installer_capability("unknown","deb",[],[])["capability_status"] == "UNKNOWN"

@pytest.mark.parametrize("generator", ["kickstart","autoinstall","preseed"])
def test_installer_templates_are_credential_free_and_structurally_valid(generator):
    p = installer_payload(generator)
    if generator == "kickstart": p["installer_family"]="Anaconda/Kickstart"
    if generator == "preseed": p["installer_family"]="Debian Installer/Preseed"
    ok, msg = validate_installer_payload(p)
    assert ok, msg
    text = generate_installer_template(p)
    assert "${CHROMAPRESS_PASSWORD_HASH}" in text
    assert "secret123" not in text


def test_installer_static_network_is_validated():
    p=installer_payload(); p.update(network_mode="static", ipv4_address="192.0.2.10/24", gateway="192.0.2.1", dns_servers=["1.1.1.1"])
    assert validate_installer_payload(p)[0]
    p["gateway"]="not-an-ip"; assert not validate_installer_payload(p)[0]


def test_installer_destructive_partitioning_requires_confirmation():
    p=installer_payload(); p["partitioning"]="guided_use_entire_disk"
    assert not validate_installer_payload(p)[0]
    p["destructive_partitioning_confirmed"]=True; assert validate_installer_payload(p)[0]


def test_installer_preflight_rejects_real_secret_field():
    p=installer_payload(); p["password_hash"]="$6$real-ish-secret"
    p["generated_native_template"] = generate_installer_template(installer_payload())
    p["generated_template_contains_real_secret"] = False
    st,_=run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",p)); assert st==ChangeStatus.FAIL


def test_installer_preflight_passes_safe_template():
    p=installer_payload(); p["generated_native_template"]=generate_installer_template(p); p["generated_template_contains_real_secret"]=False
    st,msg=run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",p)); assert st==ChangeStatus.PASS, msg


def test_desktop_detection_is_positive_not_distro_guess():
    e=desktop_capability({"lxqt-session":"2","lxqt-panel":"2"}); assert e["capability_status"]=="SUPPORTED_WITH_REQUIREMENTS" and e["active_desktop"]=="LXQt"
    e=desktop_capability({"base-files":"1"}); assert e["capability_status"]=="UNKNOWN" and not e["active_desktop"]
    e=desktop_capability({"lxqt-session":"2","gnome-shell":"49"}); assert e["capability_status"]=="BLOCKED"


def test_kiosk_modes_require_verified_runtime_packages():
    d=desktop_capability({"lxqt-session":"2","lxqt-panel":"2"})
    k=kiosk_capability({"lxqt-session":"2","lxqt-panel":"2","firefox":"1","weston":"14"},d)
    assert "browser_kiosk" in k["supported_modes"] and "minimal_wayland_weston" in k["supported_modes"]
    k2=kiosk_capability({"base-files":"1"},desktop_capability({"base-files":"1"})); assert k2["capability_status"]=="UNKNOWN"


def test_custom_content_capability_requires_rootfs():
    assert custom_content_capability(["/casper/filesystem.squashfs"])["capability_status"]=="SUPPORTED_WITH_REQUIREMENTS"
    assert custom_content_capability([])["capability_status"]=="UNKNOWN"


def test_custom_content_file_and_folder_inspection(tmp_path):
    f=tmp_path/"hello.txt"; f.write_text("hello")
    d=tmp_path/"folder"; d.mkdir(); (d/"a.txt").write_text("a")
    out=inspect_custom_content([str(f),str(d)]); assert out["entry_count"]>=2 and out["safe_paths_verified"]


def test_custom_content_tar_rejects_traversal(tmp_path):
    bad=tmp_path/"bad.tar.gz"
    with tarfile.open(bad,"w:gz") as tf:
        data=b"bad"; ti=tarfile.TarInfo("../escape.txt"); ti.size=len(data); tf.addfile(ti,io.BytesIO(data))
    with pytest.raises(ValueError, match="unsafe archive path"): inspect_custom_content([str(bad)])


def test_custom_content_tar_rejects_escaping_symlink(tmp_path):
    bad=tmp_path/"link.tar.gz"
    with tarfile.open(bad,"w:gz") as tf:
        ti=tarfile.TarInfo("safe/link"); ti.type=tarfile.SYMTYPE; ti.linkname="../../escape"; tf.addfile(ti)
    with pytest.raises(ValueError, match="unsafe archive symlink"): inspect_custom_content([str(bad)])


def content_payload(tmp_path):
    f=tmp_path/"hello.txt"; f.write_text("hello")
    inspected=inspect_custom_content([str(f)])
    return {"config_type":"part5_custom_content","part":5,"gate_version":"part5-complete","source_sha256":SHA,
            "analysis_scope":"target_iso_rootfs_metadata","capability_status":"SUPPORTED_WITH_REQUIREMENTS","target_kind":"default_user_content",
            "target_root":"/etc/skel/","conflict_policy":"PRESERVE","replace_unknown_content_confirmed":False,
            "entries":inspected["entries"],"entry_count":inspected["entry_count"],"archive_inspected":True,"safe_paths_verified":True,
            "symlinks_validated":True,"show_target_paths":True,"show_conflicts":True,"show_ownership":True,"show_permissions":True,
            "require_review_before_apply":True,"require_target_conflict_review_before_apply":True,"never_silently_overwrite_unknown_source_content":True,
            "source_read_only":True,"preserve_unrelated":True,"stage_only":True}


def test_custom_content_preflight_and_replace_guard(tmp_path):
    p=content_payload(tmp_path); st,_=run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",p)); assert st==ChangeStatus.PASS
    p["conflict_policy"]="REPLACE"; st,_=run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",p)); assert st==ChangeStatus.FAIL
    p["replace_unknown_content_confirmed"]=True; st,_=run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",p)); assert st==ChangeStatus.PASS


def desktop_payload():
    return {"config_type":"part5_desktop_defaults","part":5,"gate_version":"part5-complete","source_sha256":SHA,"analysis_scope":"target_iso_package_manifest",
            "capability_status":"SUPPORTED_WITH_REQUIREMENTS","active_desktop":"LXQt","native_adapter":"lxqt-config","controls":{"wallpaper":"/usr/share/backgrounds/a.jpg","desktop_icons":"enabled"},
            "desktop_config_contents_read":False,"host_desktop_state_accessed":False,"require_native_adapter_reverification_before_apply":True,
            "preserve_unrelated_desktop_configuration":True,"source_read_only":True,"stage_only":True}


def test_desktop_preflight_passes_and_unknown_fails_closed():
    p=desktop_payload(); assert run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",p))[0]==ChangeStatus.PASS
    p["capability_status"]="UNKNOWN"; assert run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",p))[0]==ChangeStatus.FAIL


def kiosk_payload(mode="browser_kiosk", target="https://example.org"):
    return {"config_type":"part5_kiosk_session","part":5,"gate_version":"part5-complete","source_sha256":SHA,"analysis_scope":"target_iso_package_manifest",
            "capability_status":"SUPPORTED_WITH_REQUIREMENTS","supported_modes":["browser_kiosk","custom_application_kiosk","minimal_wayland_weston"],
            "mode":mode,"target":target,"weston_verified":True,"browser_packages":["firefox"],"fullscreen":True,"autostart":True,
            "restricted_navigation":True,"restricted_session_controls":True,"controlled_recovery_escape":True,"provider_or_website_hardcoded":False,
            "require_runtime_session_validation_before_apply":True,"require_part4_security_review_before_apply":True,"source_read_only":True,"stage_only":True}


def test_kiosk_browser_and_app_targets_are_validated():
    assert run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",kiosk_payload()))[0]==ChangeStatus.PASS
    assert run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",kiosk_payload("browser_kiosk","file:///tmp/x")))[0]==ChangeStatus.FAIL
    assert run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",kiosk_payload("custom_application_kiosk","/usr/bin/app")))[0]==ChangeStatus.PASS
    assert run_preflight(ChangeItem("x",ChangeKind.CONFIG,"x",kiosk_payload("custom_application_kiosk","../app")))[0]==ChangeStatus.FAIL


def test_source_state_contains_all_part5_evidence_fields():
    fields=SourceState.__dataclass_fields__
    for name in ("part5_installer_evidence","part5_custom_content_evidence","part5_desktop_evidence","part5_kiosk_evidence"):
        assert name in fields


def test_part5_version_and_pages_are_complete():
    root=Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root/"pyproject.toml").read_text()
    assert '__version__ = "1.0.0a72"' in (root/"src/chromapress/__init__.py").read_text()
    main=(root/"src/chromapress/gui/main_window.py").read_text()
    assert 'PlaceholderPage("Files"' not in main and 'PlaceholderPage("Desktop"' not in main
    assert "FilesPage" in main and "DesktopPage" in main and "InstallerPage" in main


def test_default_user_content_can_target_safe_subdirectory(tmp_path):
    p=content_payload(tmp_path)
    p["target_root"]="/etc/skel/Documents/"
    ok,msg=validate_custom_content_payload(p)
    assert ok, msg
    p["target_root"]="/etc/skel/../root/"
    assert not validate_custom_content_payload(p)[0]


def test_installer_generator_must_match_verified_family():
    p=installer_payload("kickstart")
    p["installer_family"]="Subiquity/Autoinstall"
    assert not validate_installer_payload(p)[0]
