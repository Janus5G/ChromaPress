import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QMessageBox

from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _evidence(cap="SUPPORTED_WITH_REQUIREMENTS"):
    supported = cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha60", "analysis_scope": "target_iso_rootfs", "capability_status": cap,
        "verified": supported, "firewall_backend": "ufw" if supported else "",
        "backend_evidence_path": "/usr/sbin/ufw", "backend_evidence_layer": "/casper/minimal.squashfs",
        "rule_adapter": "ufw-additive-cli" if supported else "", "rule_command_path": "/usr/sbin/ufw" if supported else "",
        "rule_command_layer": "/casper/minimal.squashfs" if supported else "",
        "supported_operations": ["deny_inbound_tcp_port"] if supported else [],
        "rule_scope": "single_inbound_tcp_port_deny", "existing_rule_contents_read": False,
        "ports_services_policy_read": False, "application_profiles_read": False, "firewall_secrets_read": False,
        "host_firewall_accessed": False, "requires_apply_time_conflict_check": True,
        "requires_backend_state_reverification": True, "preserve_existing_rules": True,
        "source_read_only": True, "reason": "PASS" if supported else f"{cap} — blocked",
    }


def _analysis(cap="SUPPORTED_WITH_REQUIREMENTS"):
    return {"sha256": "a" * 64, "package_format": "deb", "system_firewall_rules_evidence": _evidence(cap)}


def test_alpha60_changes_stage_test_and_undo(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    changes = ChangesPanel(); page.stage_requested.connect(changes.add_change)
    page.firewall_rules_operation.setCurrentIndex(page.firewall_rules_operation.findData("deny_inbound_tcp_port"))
    page.firewall_rules_port.setText("65060")
    page.stage_firewall_rules_btn.click()
    assert len(changes.changes) == 1
    changes.list.setCurrentRow(0); changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == [] and changes.summary.text() == "No changes staged"


def test_alpha60_unknown_gui_fails_closed(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis("UNKNOWN"))
    emitted=[]; page.stage_requested.connect(emitted.append)
    page.firewall_rules_operation.setCurrentIndex(page.firewall_rules_operation.findData("deny_inbound_tcp_port"))
    page.firewall_rules_port.setText("65060")
    page.stage_firewall_rules_btn.click()
    assert emitted == []
    assert "UNKNOWN" in page.firewall_rules_plan_status.text()


def test_alpha60_gui_rejects_invalid_port(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    emitted=[]; page.stage_requested.connect(emitted.append)
    page.firewall_rules_operation.setCurrentIndex(page.firewall_rules_operation.findData("deny_inbound_tcp_port"))
    page.firewall_rules_port.setText("70000")
    page.stage_firewall_rules_btn.click()
    assert emitted == []
