from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _overlay(capability="SUPPORTED_WITH_REQUIREMENTS", entries=None):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha54",
        "analysis_scope": "target_iso_rootfs",
        "capability_status": capability,
        "verified": supported,
        "backend": "profile.d",
        "profile_path": "/etc/profile",
        "profile_layer": "/casper/minimal.squashfs" if supported else "",
        "target_directory": "/etc/profile.d",
        "target_directory_layer": "/casper/minimal.squashfs" if supported else "",
        "profile_d_sourcing_verified": supported,
        "existing_entry_names": list(entries or ["apps-bin-path.sh"]),
        "existing_dropin_contents_read": False,
        "supported_operations": ["add_managed_environment_overlay"] if supported else [],
        "host_configuration_accessed": False,
        "secret_read": False,
        "source_read_only": True,
        "reason": f"{capability} — test evidence",
    }


def _analysis(capability="SUPPORTED_WITH_REQUIREMENTS", entries=None):
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_config_overlay_evidence": _overlay(capability, entries),
    }


def _quiet(monkeypatch):
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.changes.QMessageBox.information", lambda *a, **k: None)


def _select_and_fill(page):
    page.config_overlay_operation.setCurrentIndex(page.config_overlay_operation.findData("add_managed_environment_overlay"))
    page.config_overlay_name.setText("chromatest54")
    page.config_overlay_variable.setText("CHROMAPRESS_TEST")
    page.config_overlay_value.setText("1")


def test_alpha54_overlay_controls_are_narrow(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.config_overlay_operation.findData("add_managed_environment_overlay") >= 0
    assert page.config_overlay_capability_value.text() == "SUPPORTED_WITH_REQUIREMENTS"
    assert page.config_overlay_directory_value.text() == "/etc/profile.d"


def test_alpha54_changes_test_and_undo(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    _select_and_fill(page)
    page.stage_config_overlay_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.payload["target_filename"] == "99-chromapress-chromatest54.sh"
    assert change.payload["environment_variable"] == "CHROMAPRESS_TEST"
    assert change.payload["public_nonsecret_value"] == "1"
    assert change.payload["host_configuration_accessed"] is False
    assert change.payload["preserve_existing_dropins"] is True

    changes = ChangesPanel()
    changes.set_changes([])
    changes.add_change(change)
    changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == []


def test_alpha54_unknown_gui_staging_fails_closed(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis("UNKNOWN", []))
    emitted = []
    page.stage_requested.connect(emitted.append)
    _select_and_fill(page)
    page.stage_config_overlay_btn.click()
    assert emitted == []


def test_alpha54_collision_and_secret_like_names_are_blocked(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis(entries=["99-chromapress-chromatest54.sh"]))
    emitted = []
    page.stage_requested.connect(emitted.append)
    _select_and_fill(page)
    page.stage_config_overlay_btn.click()
    assert emitted == []

    page.set_analysis(_analysis())
    _select_and_fill(page)
    page.config_overlay_variable.setText("API_KEY")
    page.stage_config_overlay_btn.click()
    assert emitted == []
