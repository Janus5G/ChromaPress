from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeKind


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis() -> dict:
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_package_evidence": [{"area": "Services / startup", "package": "systemd", "version": "1.0"}],
        "system_rootfs_verification": ["firewall remains gated"],
        "system_identity_evidence": {"verified": True, "reason": "PASS — identity", "passwd_layer": "/casper/minimal.standard.squashfs", "group_layer": "/casper/minimal.standard.squashfs", "uid_min": 1000, "regular_users": [], "admin_groups": ["sudo"], "shadow_read": False},
        "system_machine_identity_evidence": {"verified": True, "reason": "PASS — machine", "hostname": "lubuntu", "hostname_layer": "/casper/minimal.standard.squashfs", "machine_id_state": "present", "machine_id_layer": "/casper/minimal.squashfs", "machine_id_value_exposed": False},
        "system_autologin_evidence": {"verified": True, "reason": "PASS — autologin", "display_manager": "sddm", "display_manager_layer": "/casper/minimal.standard.squashfs", "autologin_state": "none", "autologin_user": "", "credential_secret_read": False},
        "system_locale_evidence": {"verified": True, "reason": "PASS — locale", "config_path": "/etc/default/locale", "config_layer": "/casper/minimal.standard.squashfs", "current_lang": "en_US.UTF-8", "current_language": "en"},
        "system_keyboard_evidence": {"verified": True, "reason": "PASS — keyboard", "config_path": "/etc/default/keyboard", "config_layer": "/casper/minimal.standard.squashfs", "current_layout": "us", "current_model": "pc105", "current_variant": ""},
        "system_timezone_evidence": {"verified": True, "reason": "PASS — timezone", "config_path": "/etc/timezone", "config_layer": "/casper/minimal.standard.squashfs", "current_timezone": "Etc/UTC"},
        "system_network_dns_evidence": {"verified": True, "reason": "PASS — networking", "backend": "NetworkManager", "backend_config_path": "/etc/NetworkManager/NetworkManager.conf", "backend_config_layer": "/casper/minimal.standard.squashfs", "resolver_path": "/etc/resolv.conf", "resolver_layer": "/casper/minimal.standard.squashfs", "connection_profiles_inspected": False, "wifi_vpn_secrets_read": False},
        "system_services_evidence": {"verified": True, "reason": "PASS — systemd", "init_system": "systemd", "vendor_unit_path": "/usr/lib/systemd/system", "vendor_unit_layer": "/casper/minimal.standard.squashfs", "local_unit_path": "/etc/systemd/system", "local_unit_layer": "/casper/minimal.standard.squashfs", "unit_contents_read": False, "enablement_links_read": False},
    }


def test_alpha44_system_page_shows_services_evidence(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert "PASS" in page.services_status_value.text()
    assert page.services_init_value.text() == "systemd"
    assert page.services_vendor_path_value.text() == "/usr/lib/systemd/system"
    assert "ROOTFS PART 4 PASS" in page.status.text()


def test_alpha44_services_controls_default_to_preserve(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.services_operation.currentData() == "preserve"
    assert not page.services_target.isEnabled()


def test_alpha44_services_stages(qapp, monkeypatch):
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    page.services_operation.setCurrentIndex(1)
    page.services_target.setText("NetworkManager.service")
    page.stage_services_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "system_services"
    assert change.payload["operation"] == "enable_service"
    assert change.payload["service_unit"] == "NetworkManager.service"
    assert change.payload["unit_contents_read"] is False
    assert change.payload["require_target_unit_verification_before_apply"] is True
