from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_targets_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _good_payload() -> dict:
    return {
        "config_type": "system_targets",
        "source_sha256": "a" * 64,
        "operation": "set_default_target",
        "target_unit": "graphical.target",
        "init_system": "systemd",
        "vendor_unit_path": "/usr/lib/systemd/system",
        "vendor_unit_layer": "/casper/minimal.standard.squashfs",
        "local_unit_path": "/etc/systemd/system",
        "local_unit_layer": "/casper/minimal.standard.squashfs",
        "rootfs_targets_verified": True,
        "require_target_unit_verification_before_apply": True,
        "preserve_services_timers": True,
        "preserve_unit_file_contents": True,
        "target_contents_read": False,
        "default_target_symlink_read": False,
        "service_secrets_read": False,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def test_alpha46_targets_evidence_reuses_metadata_only_systemd_gate(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"not-read-by-test")
    layers = ["/casper/minimal.standard.squashfs"]
    monkeypatch.setattr(
        "chromapress.engine_cli._system_services_rootfs_evidence",
        lambda *a, **k: {
            "verified": True,
            "init_system": "systemd",
            "vendor_unit_path": "/usr/lib/systemd/system",
            "vendor_unit_layer": layers[0],
            "local_unit_path": "/etc/systemd/system",
            "local_unit_layer": layers[0],
        },
    )
    evidence = _system_targets_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["init_system"] == "systemd"
    assert evidence["vendor_unit_path"] == "/usr/lib/systemd/system"
    assert evidence["target_contents_read"] is False
    assert evidence["default_target_symlink_read"] is False


def test_alpha46_targets_preflight_passes():
    status, message = run_preflight(ChangeItem("Targets / startup plan", ChangeKind.CONFIG, "test", _good_payload()))
    assert status == ChangeStatus.PASS
    assert "rootfs-evidence bound" in message
    assert "target-unit-verification gated" in message


def test_alpha46_targets_preflight_rejects_unsafe_target_or_symlink_read():
    payload = _good_payload()
    payload["target_unit"] = "../evil.target"
    status, _ = run_preflight(ChangeItem("Targets / startup plan", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL

    payload = _good_payload()
    payload["default_target_symlink_read"] = True
    status, _ = run_preflight(ChangeItem("Targets / startup plan", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL


def test_alpha46_version_locked():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
