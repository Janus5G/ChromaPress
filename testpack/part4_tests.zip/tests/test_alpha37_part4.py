from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _parse_identity_rootfs, _read_squashfs_overlay_text, _system_identity_rootfs_evidence, _unsquashfs_supports_offset
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _good_payload() -> dict:
    return {
        "config_type": "system_identity",
        "source_sha256": "a" * 64,
        "operation": "configure_default_user",
        "username": "chromatest",
        "display_name": "Chroma Test",
        "account_role": "standard",
        "admin_group": "",
        "uid_min": 1000,
        "passwd_layer": "/casper/minimal.squashfs",
        "group_layer": "/casper/minimal.squashfs",
        "existing_regular_users": ["lubuntu"],
        "rootfs_identity_verified": True,
        "shadow_read": False,
        "credential_secret_staged": False,
        "credential_policy": "deferred_secure_verified_apply",
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def test_alpha37_identity_parser_uses_non_secret_metadata_only():
    parsed = _parse_identity_rootfs(
        "root:x:0:0:root:/root:/bin/bash\n"
        "daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\n"
        "lubuntu:x:1000:1000:Lubuntu:/home/lubuntu:/bin/bash\n"
        "nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin\n",
        "root:x:0:\nsudo:x:27:lubuntu\nusers:x:100:\n",
        "UID_MIN 1000\nUID_MAX 60000\n",
    )
    assert parsed["uid_min"] == 1000
    assert parsed["regular_users"] == ["lubuntu"]
    assert parsed["admin_groups"] == ["sudo"]
    assert parsed["account_count"] == 4



def test_alpha37_offset_capability_uses_full_help_when_short_help_hides_option(monkeypatch):
    class Result:
        def __init__(self, stdout: str = "", stderr: str = "", returncode: int = 0):
            self.stdout = stdout
            self.stderr = stderr
            self.returncode = returncode

    calls = []

    def fake_run(args, **kwargs):
        calls.append(list(args))
        if "-help-all" in args:
            return Result(stdout="Miscellaneous options:\n-o BYTES, -offset BYTES\n")
        return Result(stdout="Unsquashfs help sections: use -help-all for all options\n")

    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: "/usr/bin/unsquashfs")
    monkeypatch.setattr("chromapress.engine_cli.subprocess.run", fake_run)

    assert _unsquashfs_supports_offset() is True
    assert any("-help-all" in args for args in calls)

def test_alpha37_identity_plan_preflight_passes_without_secret():
    change = ChangeItem("Identity / accounts plan", ChangeKind.CONFIG, "test", _good_payload())
    status, message = run_preflight(change)
    assert status == ChangeStatus.PASS
    assert "credential-secret free" in message


def test_alpha37_identity_plan_rejects_secret_or_unverified_evidence():
    payload = _good_payload()
    payload["credential_secret_staged"] = True
    status, _ = run_preflight(ChangeItem("Identity", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL

    payload = _good_payload()
    payload["rootfs_identity_verified"] = False
    status, _ = run_preflight(ChangeItem("Identity", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL


def test_alpha37_identity_plan_rejects_unverified_admin_group():
    payload = _good_payload()
    payload["account_role"] = "administrator"
    payload["admin_group"] = "adm"
    status, _ = run_preflight(ChangeItem("Identity", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL



def test_alpha37_rootfs_identity_read_does_not_depend_on_help_parser(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"not-read-by-test")
    layers = ["/casper/minimal.squashfs"]

    class Result:
        def __init__(self, stdout: str = "", stderr: str = "", returncode: int = 0):
            self.stdout = stdout
            self.stderr = stderr
            self.returncode = returncode

    def fake_run(args, **kwargs):
        member = args[-1]
        if member == "etc/passwd":
            return Result(stdout="root:x:0:0:root:/root:/bin/bash\nlubuntu:x:1000:1000:Lubuntu:/home/lubuntu:/bin/bash\n")
        if member == "etc/group":
            return Result(stdout="root:x:0:\nsudo:x:27:lubuntu\n")
        if member == "etc/login.defs":
            return Result(stdout="UID_MIN 1000\n")
        return Result(returncode=1)

    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: "/usr/bin/unsquashfs" if name == "unsquashfs" else None)
    monkeypatch.setattr("chromapress.engine_cli.subprocess.run", fake_run)
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (4096, 1234)})
    # Deliberately claim help parsing failed: the real read must still be tried.
    monkeypatch.setattr("chromapress.engine_cli._unsquashfs_supports_offset", lambda: False)

    evidence = _system_identity_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["regular_users"] == ["lubuntu"]
    assert evidence["admin_groups"] == ["sudo"]
    assert evidence["shadow_read"] is False


def test_alpha37_direct_offset_reader_tries_long_and_short_spellings(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"x")
    layer = "/casper/minimal.squashfs"
    seen = []

    class Result:
        def __init__(self, stdout: str = "", returncode: int = 1):
            self.stdout = stdout
            self.stderr = ""
            self.returncode = returncode

    def fake_run(args, **kwargs):
        seen.append(list(args))
        if "-o" in args:
            return Result(stdout="root:x:0:0:root:/root:/bin/bash\n", returncode=0)
        return Result(returncode=1)

    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: "/usr/bin/unsquashfs")
    monkeypatch.setattr("chromapress.engine_cli.subprocess.run", fake_run)
    text, source_layer = _read_squashfs_overlay_text(iso, [layer], "/etc/passwd", {layer: (8192, 100)})
    assert text.startswith("root:")
    assert source_layer == layer
    assert any("-offset" in cmd for cmd in seen)
    assert any("-o" in cmd for cmd in seen)

def test_alpha37_version_is_consistent():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
    main = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert 'from chromapress import __version__' in main
    assert 'QLabel(__version__)' in main


def test_alpha37_identity_falls_back_to_temporary_readonly_mount(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    layer = "/casper/minimal.squashfs"

    class Result:
        def __init__(self, stdout: str = "", stderr: str = "", returncode: int = 0):
            self.stdout = stdout
            self.stderr = stderr
            self.returncode = returncode

    def fake_which(name):
        return f"/usr/bin/{name}" if name in {"unsquashfs", "mount", "umount"} else None

    def fake_run(args, **kwargs):
        exe = Path(args[0]).name
        if exe == "mount":
            mountpoint = Path(args[-1])
            squash = mountpoint / "casper" / "minimal.squashfs"
            squash.parent.mkdir(parents=True, exist_ok=True)
            squash.write_bytes(b"sq")
            return Result()
        if exe == "umount":
            return Result()
        if exe == "unsquashfs":
            # Direct ISO-offset access fails on this simulated host.
            if "-offset" in args or "-o" in args:
                return Result(returncode=1, stderr="offset access unsupported")
            member = args[-1]
            if member == "etc/passwd":
                return Result(stdout="root:x:0:0:root:/root:/bin/bash\nlubuntu:x:1000:1000:Lubuntu:/home/lubuntu:/bin/bash\n")
            if member == "etc/group":
                return Result(stdout="root:x:0:\nsudo:x:27:lubuntu\n")
            if member == "etc/login.defs":
                return Result(stdout="UID_MIN 1000\n")
        return Result(returncode=1)

    import chromapress.engine_cli as engine_cli
    monkeypatch.setattr(engine_cli.os, "geteuid", lambda: 0, raising=False)
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", fake_which)
    monkeypatch.setattr("chromapress.engine_cli.subprocess.run", fake_run)
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layer: (4096, 1234)})

    evidence = _system_identity_rootfs_evidence(iso, [layer])
    assert evidence["verified"] is True
    assert evidence["regular_users"] == ["lubuntu"]
    assert evidence["admin_groups"] == ["sudo"]
    assert evidence["shadow_read"] is False


def test_alpha37_wsl_source_analysis_runs_tightly_scoped_as_root(monkeypatch, tmp_path):
    from chromapress.services.wsl import WslBridge

    seen = []

    class Result:
        returncode = 0
        stdout = "{}"
        stderr = ""

    def fake_run(args, **kwargs):
        seen.append(list(args))
        return Result()

    monkeypatch.setattr("chromapress.services.wsl.subprocess.run", fake_run)
    monkeypatch.setattr("chromapress.services.wsl.project_root", lambda: tmp_path)
    monkeypatch.setattr("chromapress.services.wsl.windows_to_wsl", lambda value: "/mnt/e/test")

    assert WslBridge("Ubuntu").analyze_iso(r"E:\\test.iso") == {}
    cmd = seen[0]
    import os
    import sys
    if os.name == "nt":
        assert cmd[:5] == ["wsl.exe", "-d", "Ubuntu", "--user", "root"]
    else:
        assert cmd[:3] == [sys.executable, "-m", "chromapress.engine_cli"]
    assert "analyze" in cmd
