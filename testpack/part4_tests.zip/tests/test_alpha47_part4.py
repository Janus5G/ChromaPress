from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_firewall_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _payload(**overrides):
    data = {
        "config_type": "system_firewall",
        "source_sha256": "a" * 64,
        "operation": "enable_firewall",
        "backend": "ufw",
        "backend_path": "/etc/ufw",
        "backend_layer": "/casper/minimal.standard.squashfs",
        "rootfs_firewall_verified": True,
        "require_backend_apply_verification_before_apply": True,
        "preserve_rule_contents": True,
        "preserve_ports_services_profiles": True,
        "rule_contents_read": False,
        "ports_services_policy_read": False,
        "application_profiles_read": False,
        "firewall_secrets_read": False,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }
    data.update(overrides)
    return data


def test_alpha47_firewall_evidence_detects_ufw_without_reading_rules(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    layers = ["/casper/minimal.standard.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: "/usr/bin/unsquashfs" if name == "unsquashfs" else None)
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (0, 1)})
    def presence(path, roots, member, extents=None):
        return (member == "/etc/ufw", layers[0] if member == "/etc/ufw" else "")
    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", presence)
    monkeypatch.setattr("chromapress.engine_cli._inspect_firewall_from_readonly_mount", lambda *a, **k: {})
    evidence = _system_firewall_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["backend"] == "ufw"
    assert evidence["backend_path"] == "/etc/ufw"
    assert evidence["rule_contents_read"] is False
    assert evidence["ports_services_policy_read"] is False
    assert evidence["firewall_secrets_read"] is False


def test_alpha47_firewall_preflight_passes():
    status, detail = run_preflight(ChangeItem("Firewall plan", ChangeKind.CONFIG, "x", _payload()))
    assert status == ChangeStatus.PASS
    assert "backend-apply-verification gated" in detail
    assert "rule-content preserving" in detail


def test_alpha47_firewall_preflight_rejects_rule_read_or_missing_reverify():
    status, _ = run_preflight(ChangeItem("Firewall plan", ChangeKind.CONFIG, "x", _payload(rule_contents_read=True)))
    assert status == ChangeStatus.FAIL
    status, _ = run_preflight(ChangeItem("Firewall plan", ChangeKind.CONFIG, "x", _payload(require_backend_apply_verification_before_apply=False)))
    assert status == ChangeStatus.FAIL


def test_alpha47_firewall_preflight_supports_disable():
    status, _ = run_preflight(ChangeItem("Firewall plan", ChangeKind.CONFIG, "x", _payload(operation="disable_firewall", backend="nftables", backend_path="/etc/nftables.conf")))
    assert status == ChangeStatus.PASS


def test_alpha47_version_markers():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
