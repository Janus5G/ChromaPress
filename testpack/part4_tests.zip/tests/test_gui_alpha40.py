from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeKind


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis() -> dict:
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_package_evidence": [{"area": "Locale / keyboard / timezone", "package": "locales", "version": "2.40"}],
        "system_rootfs_verification": ["network profiles remain gated"],
        "system_identity_evidence": {"verified": True, "reason": "PASS — identity", "passwd_layer": "/casper/minimal.standard.squashfs", "group_layer": "/casper/minimal.standard.squashfs", "uid_min": 1000, "regular_users": [], "admin_groups": ["sudo"], "shadow_read": False},
        "system_machine_identity_evidence": {"verified": True, "reason": "PASS — machine", "hostname": "lubuntu", "hostname_layer": "/casper/minimal.standard.squashfs", "machine_id_state": "present", "machine_id_layer": "/casper/minimal.squashfs", "machine_id_value_exposed": False},
        "system_autologin_evidence": {"verified": True, "reason": "PASS — autologin", "display_manager": "sddm", "display_manager_layer": "/casper/minimal.standard.squashfs", "autologin_state": "no explicit autologin directive found", "autologin_user": "", "credential_secret_read": False},
        "system_locale_evidence": {"verified": True, "reason": "PASS — locale", "config_path": "/etc/default/locale", "config_layer": "/casper/minimal.standard.squashfs", "config_style": "debian-default-locale", "current_lang": "en_US.UTF-8", "current_language": "en", "current_lc_all": "", "locale_gen_present": True, "secret_read": False},
    }


def test_alpha40_system_page_shows_locale_evidence(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert "PASS" in page.locale_status_value.text()
    assert page.locale_path_value.text() == "/etc/default/locale"
    assert page.locale_lang_value.text() == "en_US.UTF-8"
    assert "ROOTFS PART 4 PASS" in page.status.text()


def test_alpha40_locale_controls_default_to_preserve(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.locale_operation.currentData() == "preserve"
    assert not page.locale_target.isEnabled()
    assert "LANGUAGE" in page.locale_policy_value.text()


def test_alpha40_locale_stages(qapp, monkeypatch):
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    page.locale_operation.setCurrentIndex(1)
    page.locale_target.setText("da_DK.UTF-8")
    page.stage_locale_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "system_locale"
    assert change.payload["target_lang"] == "da_DK.UTF-8"
    assert change.payload["preserve_language_and_lc_overrides"] is True
    assert change.payload["require_locale_availability_verification_before_apply"] is True
