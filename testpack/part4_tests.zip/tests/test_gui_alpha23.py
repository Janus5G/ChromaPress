from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.applications_page import ApplicationsPage
from chromapress.settings import AppSettings


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _page(qapp, scenario: str) -> ApplicationsPage:
    page = ApplicationsPage(AppSettings())
    page._source = {"distribution": "Lubuntu", "version": "26.04.1", "path": "test.iso"}
    page._catalog = [{"application":"About LXQt","package":"lxqt-about","description":"About LXQt","categories":["System"]}]
    page._catalog_loaded = True
    page.set_scenario(scenario)
    return page


def _texts(page: ApplicationsPage) -> list[str]:
    out=[]
    def walk(item):
        out.append(item.text(0))
        for i in range(item.childCount()): walk(item.child(i))
    for i in range(page.tree.topLevelItemCount()): walk(page.tree.topLevelItem(i))
    return out


def test_school_profile_shows_chromalearn_044_recommendation_open(qapp):
    page=_page(qapp,"education")
    texts=_texts(page)
    assert any("ChromaLearn AI" in text for text in texts)
    recommended=[page.tree.topLevelItem(i) for i in range(page.tree.topLevelItemCount())
                 if page.tree.topLevelItem(i).text(0).startswith("Recommended for School / Education")]
    assert recommended and recommended[0].isExpanded()


def test_chromalearn_global_search_from_other_profile(qapp):
    page=_page(qapp,"production")
    page.search.setText("ChromaLearn")
    assert any("ChromaLearn AI" in text for text in _texts(page))
