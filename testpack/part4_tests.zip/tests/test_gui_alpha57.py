from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _session(capability="SUPPORTED_WITH_REQUIREMENTS"):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha57", "analysis_scope": "target_iso_rootfs", "capability_status": capability,
        "verified": supported, "backend": "sddm-autologin-session-dropin" if supported else "",
        "display_manager": "sddm" if supported else "", "display_manager_layer": "/casper/minimal.squashfs" if supported else "",
        "session_directories": [{"path": "/usr/share/xsessions", "kind": "x11", "layer": "/casper/minimal.squashfs"}] if supported else [],
        "verified_sessions": [{"name": "lxqt.desktop", "kind": "x11", "layer": "/casper/minimal.squashfs", "directory": "/usr/share/xsessions"}] if supported else [],
        "target_config_directory": "/etc/sddm.conf.d", "target_config_directory_layer": "/casper/minimal.squashfs" if supported else "",
        "managed_filename": "99-chromapress-kiosk-session.conf", "managed_target_path": "/etc/sddm.conf.d/99-chromapress-kiosk-session.conf",
        "managed_target_present": False, "existing_regular_users": ["ubuntu", "viewer"] if supported else [], "admin_users": ["ubuntu"] if supported else [],
        "supported_operations": ["bind_kiosk_autologin_session"] if supported else [], "restriction_scope": "fixed_autologin_session_selection_only",
        "session_file_contents_read": False, "display_manager_config_contents_read": False, "credential_secret_read": False,
        "host_session_state_accessed": False, "pam_contents_read": False, "ssh_config_read": False, "source_read_only": True,
        "reason": f"{capability} — test evidence",
    }


def _analysis(capability="SUPPORTED_WITH_REQUIREMENTS"):
    return {"sha256": "a" * 64, "package_format": "deb", "system_restricted_session_evidence": _session(capability)}


def _quiet(monkeypatch):
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.changes.QMessageBox.information", lambda *a, **k: None)


def _fill(page, username="chromakiosk57"):
    page.restricted_session_operation.setCurrentIndex(page.restricted_session_operation.findData("bind_kiosk_autologin_session"))
    page.restricted_session_username.setText(username)
    page.restricted_session_choice.setCurrentIndex(page.restricted_session_choice.findData("lxqt.desktop"))


def test_alpha57_controls_are_narrow(qapp):
    page = SystemPage(); page.set_analysis(_analysis())
    assert page.restricted_session_operation.findData("bind_kiosk_autologin_session") >= 0
    assert page.restricted_session_capability_value.text() == "SUPPORTED_WITH_REQUIREMENTS"
    assert page.restricted_session_choice.findData("lxqt.desktop") >= 0
    assert "fixed sddm autologin-session" in page.restricted_session_scope_value.text().casefold()


def test_alpha57_changes_test_and_undo(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage(); page.set_analysis(_analysis())
    emitted=[]; page.stage_requested.connect(emitted.append)
    _fill(page); page.stage_restricted_session_btn.click()
    assert len(emitted)==1
    change=emitted[0]
    assert change.payload["session_name"] == "lxqt.desktop"
    assert change.payload["restricted_login_dependency"] == "alpha56_restricted_login_required"
    assert change.payload["autologin_dependency"] == "alpha39_autologin_same_user_required"
    changes=ChangesPanel(); changes.set_changes([]); changes.add_change(change); changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected(); assert changes.changes == []


def test_alpha57_existing_user_uses_verified_dependency(qapp, monkeypatch):
    _quiet(monkeypatch)
    page=SystemPage(); page.set_analysis(_analysis()); emitted=[]; page.stage_requested.connect(emitted.append)
    _fill(page,"viewer"); page.stage_restricted_session_btn.click()
    assert emitted[0].payload["account_dependency"] == "verified_existing_target_user"


def test_alpha57_admin_is_blocked(qapp, monkeypatch):
    _quiet(monkeypatch)
    page=SystemPage(); page.set_analysis(_analysis()); emitted=[]; page.stage_requested.connect(emitted.append)
    _fill(page,"ubuntu"); page.stage_restricted_session_btn.click(); assert emitted == []


def test_alpha57_unknown_gui_staging_fails_closed(qapp, monkeypatch):
    _quiet(monkeypatch)
    page=SystemPage(); page.set_analysis(_analysis("UNKNOWN")); emitted=[]; page.stage_requested.connect(emitted.append)
    page.restricted_session_operation.setCurrentIndex(page.restricted_session_operation.findData("bind_kiosk_autologin_session"))
    page.restricted_session_username.setText("chromakiosk57")
    page.stage_restricted_session_btn.click(); assert emitted == []
