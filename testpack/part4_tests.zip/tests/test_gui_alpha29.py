from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.boot_hardware_page import BootHardwarePage
from chromapress.models import ChangeKind, ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis():
    return {
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "rootfs": ["/casper/minimal.standard.live.squashfs"],
        "initramfs_mechanism": "update-initramfs",
        "hardware_package_hints": [
            {"package": "linux-firmware", "version": "1", "kind": "Firmware / microcode"},
            {"package": "broadcom-sta-dkms", "version": "2", "kind": "Driver / DKMS"},
            {"package": "linux-image-generic", "version": "3", "kind": "Kernel"},
        ],
    }


def test_alpha29_hardware_plan_uses_only_manifest_backed_firmware_driver_entries(qapp):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    assert page.stage_hardware_btn.isEnabled()
    labels = [page.hardware_package_combo.itemText(i) for i in range(page.hardware_package_combo.count())]
    assert any("linux-firmware" in x for x in labels)
    assert any("broadcom-sta-dkms" in x for x in labels)
    assert not any("linux-image-generic" in x for x in labels)


def test_alpha29_hardware_plan_stages_with_mandatory_safety_gates(qapp, monkeypatch):
    page = BootHardwarePage()
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.set_analysis(_analysis())
    monkeypatch.setattr(
        "chromapress.gui.boot_hardware_page.QMessageBox.information",
        lambda *args, **kwargs: None,
    )
    page.hardware_package_combo.setCurrentIndex(1)
    page.hardware_action_combo.setCurrentIndex(1)
    page.stage_hardware_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "hardware_package"
    assert change.payload["stage_only"] is True
    assert change.payload["require_signed_repository_metadata"] is True
    assert change.payload["require_dependency_resolution"] is True
    assert change.payload["protect_last_viable_kernel"] is True
    assert change.payload["regenerate_initramfs"] is True


def test_alpha29_hardware_plan_fails_closed_without_manifest_evidence(qapp, monkeypatch):
    page = BootHardwarePage()
    data = _analysis(); data["hardware_package_hints"] = []
    page.set_analysis(data)
    emitted = []
    shown = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr(
        "chromapress.gui.boot_hardware_page.QMessageBox.information",
        lambda *args, **kwargs: shown.append((args, kwargs)),
    )
    assert page.stage_hardware_btn.isEnabled()
    page.stage_hardware_btn.click()
    assert emitted == []
    assert "BLOCKED" in page.hardware_plan_status.text()
    assert "no manifest-backed" in page.hardware_plan_status.text().lower()
    assert shown


def test_alpha29_source_switch_blocks_stale_hardware_plan(qapp):
    from chromapress.gui.main_window import MainWindow
    from chromapress.models import ChangeItem
    window = MainWindow()
    change = ChangeItem("Firmware / driver plan", ChangeKind.CONFIG, "test", {
        "config_type": "hardware_package",
        "source_sha256": "a" * 64,
        "package": "linux-firmware",
        "hardware_kind": "Firmware / microcode",
        "rootfs": ["/casper/minimal.squashfs"],
        "initramfs_mechanism": "update-initramfs",
        "operation": "re_resolve",
        "require_signed_repository_metadata": True,
        "require_dependency_resolution": True,
        "protect_last_viable_kernel": True,
        "regenerate_initramfs": True,
        "stage_only": True,
    })
    window.project.changes.append(change)
    window.changes.set_changes(window.project.changes)
    window._guard_boot_plan_source("b" * 64)
    assert change.status == ChangeStatus.BLOCKED
    window.close()

def test_alpha29_hardware_plan_explains_missing_selection(qapp, monkeypatch):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    shown = []
    monkeypatch.setattr(
        "chromapress.gui.boot_hardware_page.QMessageBox.information",
        lambda *args, **kwargs: shown.append((args, kwargs)),
    )
    page.stage_hardware_btn.click()
    assert "Select a manifest-backed" in page.hardware_plan_status.text()
    assert shown


def test_alpha29_hardware_plan_confirms_successful_staging(qapp, monkeypatch):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    emitted = []
    shown = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr(
        "chromapress.gui.boot_hardware_page.QMessageBox.information",
        lambda *args, **kwargs: shown.append((args, kwargs)),
    )
    page.hardware_package_combo.setCurrentIndex(1)
    page.hardware_action_combo.setCurrentIndex(1)
    page.stage_hardware_btn.click()
    assert len(emitted) == 1
    assert page.hardware_plan_status.text() == "Staged — review/Test in Changes."
    assert shown

