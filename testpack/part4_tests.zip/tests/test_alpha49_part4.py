from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_sysctl_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _payload(**overrides):
    data = {
        "config_type": "system_sysctl",
        "source_sha256": "a" * 64,
        "operation": "set_integer_sysctl",
        "sysctl_key": "vm.swappiness",
        "sysctl_value": "10",
        "backend": "procps-sysctl",
        "evidence_path": "/usr/sbin/sysctl",
        "evidence_layer": "/casper/minimal.standard.squashfs",
        "rootfs_sysctl_verified": True,
        "require_target_key_apply_verification_before_apply": True,
        "preserve_existing_sysctl_config": True,
        "use_managed_dropin_on_apply": True,
        "config_contents_read": False,
        "runtime_values_read": False,
        "sysctl_secrets_read": False,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }
    data.update(overrides)
    return data


def test_alpha49_sysctl_evidence_detects_binary_without_reading_values(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    layers = ["/casper/minimal.standard.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: "/usr/bin/unsquashfs" if name == "unsquashfs" else None)
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (0, 1)})

    def presence(path, roots, member, extents=None):
        return (member == "/usr/sbin/sysctl", layers[0] if member == "/usr/sbin/sysctl" else "")

    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", presence)
    monkeypatch.setattr("chromapress.engine_cli._inspect_sysctl_from_readonly_mount", lambda *a, **k: {})
    evidence = _system_sysctl_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["backend"] == "procps-sysctl"
    assert evidence["evidence_path"] == "/usr/sbin/sysctl"
    assert evidence["config_contents_read"] is False
    assert evidence["runtime_values_read"] is False


def test_alpha49_sysctl_preflight_passes():
    status, detail = run_preflight(ChangeItem("sysctl plan", ChangeKind.CONFIG, "x", _payload()))
    assert status == ChangeStatus.PASS
    assert "target-key/apply-verification gated" in detail
    assert "existing-config preserving" in detail


def test_alpha49_sysctl_preflight_rejects_unsafe_key_or_noninteger_value():
    status, _ = run_preflight(ChangeItem("sysctl plan", ChangeKind.CONFIG, "x", _payload(sysctl_key="vm.swappiness;rm")))
    assert status == ChangeStatus.FAIL
    status, _ = run_preflight(ChangeItem("sysctl plan", ChangeKind.CONFIG, "x", _payload(sysctl_value="10 20")))
    assert status == ChangeStatus.FAIL


def test_alpha49_sysctl_preflight_rejects_read_existing_config():
    status, _ = run_preflight(ChangeItem("sysctl plan", ChangeKind.CONFIG, "x", _payload(config_contents_read=True)))
    assert status == ChangeStatus.FAIL


def test_alpha49_version_markers():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
