from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _lockdown(capability="SUPPORTED_WITH_REQUIREMENTS"):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    units = [
        {"name": "cups.service", "directory": "/usr/lib/systemd/system", "layer": "/casper/minimal.squashfs"},
        {"name": "dbus.service", "directory": "/usr/lib/systemd/system", "layer": "/casper/minimal.squashfs"},
    ] if supported else []
    return {
        "gate_version": "alpha58", "analysis_scope": "target_iso_rootfs", "capability_status": capability,
        "verified": supported, "backend": "systemd-disable-mask-intent" if supported else "", "init_system": "systemd" if supported else "",
        "vendor_unit_path": "/usr/lib/systemd/system" if supported else "", "vendor_unit_layer": "/casper/minimal.squashfs" if supported else "",
        "local_unit_path": "/etc/systemd/system" if supported else "", "local_unit_layer": "/casper/minimal.squashfs" if supported else "",
        "verified_service_units": units, "available_lockdown_units": units[:1] if supported else [],
        "protected_service_units": ["dbus.service"] if supported else [], "supported_operations": ["disable_and_mask_verified_service"] if supported else [],
        "lockdown_scope": "single_verified_noncritical_systemd_service", "unit_contents_read": False,
        "enablement_links_read": False, "enablement_link_targets_read": False, "environment_files_read": False,
        "service_secrets_read": False, "credential_secret_read": False, "host_service_state_accessed": False,
        "source_read_only": True, "reason": f"{capability} — test evidence",
    }


def _analysis(capability="SUPPORTED_WITH_REQUIREMENTS"):
    return {"sha256": "a" * 64, "package_format": "deb", "system_service_lockdown_evidence": _lockdown(capability)}


def _quiet(monkeypatch):
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.changes.QMessageBox.information", lambda *a, **k: None)


def _fill(page):
    page.service_lockdown_operation.setCurrentIndex(page.service_lockdown_operation.findData("disable_and_mask_verified_service"))
    page.service_lockdown_choice.setCurrentIndex(page.service_lockdown_choice.findData("cups.service"))


def test_alpha58_controls_show_only_verified_nonprotected_units(qapp):
    page = SystemPage(); page.set_analysis(_analysis())
    assert page.service_lockdown_capability_value.text() == "SUPPORTED_WITH_REQUIREMENTS"
    assert page.service_lockdown_choice.findData("cups.service") >= 0
    assert page.service_lockdown_choice.findData("dbus.service") < 0


def test_alpha58_changes_test_and_undo(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage(); page.set_analysis(_analysis()); emitted=[]; page.stage_requested.connect(emitted.append)
    _fill(page); page.stage_service_lockdown_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.payload["service_unit"] == "cups.service"
    assert change.payload["operation"] == "disable_and_mask_verified_service"
    changes=ChangesPanel(); changes.set_changes([]); changes.add_change(change); changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected(); assert changes.changes == []


def test_alpha58_unknown_gui_staging_fails_closed(qapp, monkeypatch):
    _quiet(monkeypatch)
    page=SystemPage(); page.set_analysis(_analysis("UNKNOWN")); emitted=[]; page.stage_requested.connect(emitted.append)
    page.service_lockdown_operation.setCurrentIndex(page.service_lockdown_operation.findData("disable_and_mask_verified_service"))
    page.stage_service_lockdown_btn.click(); assert emitted == []
