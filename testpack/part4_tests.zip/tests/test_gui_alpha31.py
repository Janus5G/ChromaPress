from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.boot_hardware_page import BootHardwarePage
from chromapress.models import ChangeKind, ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis():
    return {
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "rootfs": ["/casper/minimal.squashfs"],
        "rootfs_details": [{"path": "/casper/minimal.squashfs", "compression": "xz", "block_size": 131072}],
        "initramfs_mechanism": "update-initramfs",
    }


def test_alpha31_immutable_runtime_controls_require_complete_evidence(qapp):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    assert page.stage_immutable_btn.isEnabled()
    assert page.immutable_layer_combo.count() == 2
    assert "tmpfs" in page.immutable_writable_value.text()
    assert "do not survive reboot" in page.immutable_survival_value.text()


def test_alpha31_immutable_runtime_stages_volatile_plan(qapp, monkeypatch):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.boot_hardware_page.QMessageBox.information", lambda *a, **k: None)
    page.immutable_layer_combo.setCurrentIndex(1)
    page.immutable_mode_combo.setCurrentIndex(1)
    page.stage_immutable_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "immutable_runtime"
    assert change.payload["runtime_mode"] == "volatile_overlay"
    assert change.payload["writable_layer"] == "tmpfs"
    assert change.payload["runtime_changes_survive_reboot"] is False
    assert change.payload["source_read_only"] is True
    assert change.payload["stage_only"] is True


def test_alpha31_source_switch_blocks_stale_immutable_plan(qapp):
    from chromapress.gui.main_window import MainWindow
    from chromapress.models import ChangeItem
    window = MainWindow()
    change = ChangeItem("Immutable / volatile runtime plan", ChangeKind.CONFIG, "test", {
        "config_type": "immutable_runtime",
        "source_sha256": "a" * 64,
        "base_layer": "/casper/minimal.squashfs",
        "runtime_mode": "volatile_overlay",
        "writable_layer": "tmpfs",
        "persistence_policy": "volatile",
        "runtime_changes_survive_reboot": False,
        "initramfs_mechanism": "update-initramfs",
        "require_initramfs_integration": True,
        "require_boot_integration": True,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    })
    window.project.changes.append(change)
    window.changes.set_changes(window.project.changes)
    window._guard_boot_plan_source("b" * 64)
    assert change.status == ChangeStatus.BLOCKED
    window.close()
