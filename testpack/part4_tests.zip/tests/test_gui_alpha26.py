from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.boot_hardware_page import BootHardwarePage


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def test_alpha26_boot_page_renders_verified_configuration_evidence(qapp):
    page = BootHardwarePage()
    page.set_analysis({
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "bios_boot": True,
        "uefi_boot": True,
        "el_torito_boot": True,
        "hybrid_boot": True,
        "boot_catalog": "/boot.catalog",
        "bootloaders": ["GRUB"],
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "boot_entries": [{"source": "/boot/grub/grub.cfg", "title": "Try Linux", "id": ""}],
        "boot_defaults": ["0 (/boot/grub/grub.cfg)"],
        "boot_timeouts": ["10 s (/boot/grub/grub.cfg)"],
        "kernel_arguments": [{"source": "/boot/grub/grub.cfg", "args": "boot=casper quiet"}],
        "hardware_package_hints": [{"package": "linux-firmware", "version": "1", "kind": "Firmware / microcode"}],
    })
    assert page.boot_fields["catalog"].text() == "/boot.catalog"
    assert "0 (" in page.config_fields["defaults"].text()
    assert "10 s" in page.config_fields["timeouts"].text()
    names = [page.structure.topLevelItem(i).text(0) for i in range(page.structure.topLevelItemCount())]
    assert "Boot entries" in names
    assert "Kernel arguments" in names
    assert "Manifest-backed kernel / firmware / driver packages" in names
    assert "read-only" in page.footer.text().lower()
