from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.applications_page import ApplicationsPage
from chromapress.settings import AppSettings


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _page(qapp, scenario: str) -> ApplicationsPage:
    page = ApplicationsPage(AppSettings())
    page._source = {"distribution": "Lubuntu", "version": "26.04.1", "path": "test.iso"}
    page._catalog = [
        {"application": "About LXQt", "package": "lxqt-about", "description": "About LXQt", "categories": ["System"]},
    ]
    page._catalog_loaded = True
    page.set_scenario(scenario)
    return page


def test_recommended_group_is_open_by_default_for_selected_profile(qapp):
    page = _page(qapp, "gaming_team")
    recommended = None
    for i in range(page.tree.topLevelItemCount()):
        item = page.tree.topLevelItem(i)
        if item.text(0).startswith("Recommended for Gaming / Team"):
            recommended = item
            break
    assert recommended is not None
    assert recommended.isExpanded()
    assert recommended.childCount() > 0
    assert all(recommended.child(i).isExpanded() for i in range(recommended.childCount()))


def test_profile_change_reopens_new_profiles_recommendations(qapp):
    page = _page(qapp, "gaming_team")
    page.set_scenario("production")
    matches = [page.tree.topLevelItem(i) for i in range(page.tree.topLevelItemCount())
               if page.tree.topLevelItem(i).text(0).startswith("Recommended for Production / Industrial")]
    assert matches
    assert matches[0].isExpanded()
