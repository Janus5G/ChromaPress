from pathlib import Path

from chromapress_acceptance import AcceptanceRunner


def test_alpha59_staged_sweep_reports_packaged_gate_results(tmp_path):
    runner = AcceptanceRunner(tmp_path, 4, None, None, tmp_path / "reports")
    runner.testpack_report = {
        "part4_staged_gate_status": "AUTOMATED_GATE_PASS",
        "part4_staged_gates": {
            "57": {"passed": 5, "failed": 0, "errors": 0, "skipped": 0},
            "58": {"passed": 3, "failed": 0, "errors": 0, "skipped": 0},
            "59": {"passed": 2, "failed": 0, "errors": 0, "skipped": 0},
        },
    }
    runner.run_part4_staged_gate_sweep()
    assert runner.part4_staged_sweep_status == "AUTOMATED_GATE_PASS"
    assert runner.checks[-1].status == "PASS"
    assert all("AUTOMATED_GATE_PASS" in c.detail for c in runner.checks if c.check_id.startswith("P4-STAGED-A"))


def test_alpha59_staged_sweep_can_report_fail_and_skip(tmp_path):
    runner = AcceptanceRunner(tmp_path, 4, None, None, tmp_path / "reports")
    runner.testpack_report = {
        "part4_staged_gate_status": "AUTOMATED_GATE_FAIL",
        "part4_staged_gates": {
            "58": {"passed": 0, "failed": 1, "errors": 0, "skipped": 0},
            "59": {"passed": 0, "failed": 0, "errors": 0, "skipped": 2},
        },
    }
    runner.run_part4_staged_gate_sweep()
    assert runner.part4_staged_sweep_status == "AUTOMATED_GATE_FAIL"
    by_id = {c.check_id: c for c in runner.checks}
    assert by_id["P4-STAGED-A58"].status == "FAIL"
    assert by_id["P4-STAGED-A59"].status == "SKIP"
    assert by_id["P4-STAGED-SWEEP"].status == "FAIL"
