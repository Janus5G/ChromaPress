from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeKind


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis() -> dict:
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_package_evidence": [{"area": "Locale / keyboard / timezone", "package": "keyboard-configuration", "version": "1.240"}],
        "system_rootfs_verification": ["timezone remains gated"],
        "system_identity_evidence": {"verified": True, "reason": "PASS — identity", "passwd_layer": "/casper/minimal.standard.squashfs", "group_layer": "/casper/minimal.standard.squashfs", "uid_min": 1000, "regular_users": [], "admin_groups": ["sudo"], "shadow_read": False},
        "system_machine_identity_evidence": {"verified": True, "reason": "PASS — machine", "hostname": "lubuntu", "hostname_layer": "/casper/minimal.standard.squashfs", "machine_id_state": "present", "machine_id_layer": "/casper/minimal.squashfs", "machine_id_value_exposed": False},
        "system_autologin_evidence": {"verified": True, "reason": "PASS — autologin", "display_manager": "sddm", "display_manager_layer": "/casper/minimal.standard.squashfs", "autologin_state": "no explicit autologin directive found", "autologin_user": "", "credential_secret_read": False},
        "system_locale_evidence": {"verified": True, "reason": "PASS — locale", "config_path": "/etc/default/locale", "config_layer": "/casper/minimal.standard.squashfs", "config_style": "debian-default-locale", "current_lang": "en_US.UTF-8", "current_language": "en", "current_lc_all": "", "locale_gen_present": True, "secret_read": False},
        "system_keyboard_evidence": {"verified": True, "reason": "PASS — keyboard", "config_path": "/etc/default/keyboard", "config_layer": "/casper/minimal.standard.squashfs", "config_style": "debian-default-keyboard", "current_layout": "us", "current_model": "pc105", "current_variant": "", "current_options": "", "secret_read": False},
    }


def test_alpha41_system_page_shows_keyboard_evidence(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert "PASS" in page.keyboard_status_value.text()
    assert page.keyboard_path_value.text() == "/etc/default/keyboard"
    assert page.keyboard_layout_value.text() == "us"
    assert "ROOTFS PART 4 PASS" in page.status.text()


def test_alpha41_keyboard_controls_default_to_preserve(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.keyboard_operation.currentData() == "preserve"
    assert not page.keyboard_target.isEnabled()
    assert "variant" in page.keyboard_policy_value.text().casefold()


def test_alpha41_keyboard_stages(qapp, monkeypatch):
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    page.keyboard_operation.setCurrentIndex(1)
    page.keyboard_target.setText("dk")
    page.stage_keyboard_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "system_keyboard"
    assert change.payload["target_layout"] == "dk"
    assert change.payload["preserve_model_variant_options"] is True
    assert change.payload["require_layout_availability_verification_before_apply"] is True
