from __future__ import annotations

import hashlib
from pathlib import Path

from chromapress.engine_cli import _parse_identity_rootfs, _system_identity_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _alpha50_user_payload() -> dict:
    return {
        "config_type": "system_identity",
        "gate_version": "alpha50",
        "source_sha256": "a" * 64,
        "capability_status": "SUPPORTED_WITH_REQUIREMENTS",
        "users_groups_status": "SUPPORTED_WITH_REQUIREMENTS",
        "uid_gid_status": "SUPPORTED_WITH_REQUIREMENTS",
        "group_membership_status": "SUPPORTED_WITH_REQUIREMENTS",
        "password_policy_status": "SUPPORTED_WITH_REQUIREMENTS",
        "control_depth": "advanced",
        "operation": "create_user",
        "plan_slot": "user:chromatest",
        "username": "chromatest",
        "display_name": "Chroma Test",
        "display_name_mode": "set",
        "target_exists": False,
        "account_role": "administrator",
        "admin_group": "sudo",
        "uid": 1500,
        "uid_mode": "set",
        "primary_gid": 100,
        "primary_gid_mode": "set",
        "supplementary_groups": ["users"],
        "group_membership_mode": "set",
        "password_policy": {"mode": "configure", "min_days": 1, "max_days": 365, "warn_days": 14},
        "require_uid_gid_conflict_check_before_apply": True,
        "require_group_reverification_before_apply": True,
        "require_password_policy_reverification_before_apply": True,
        "uid_min": 1000,
        "passwd_layer": "/casper/minimal.squashfs",
        "group_layer": "/casper/minimal.squashfs",
        "login_defs_layer": "/casper/minimal.squashfs",
        "rootfs_identity_verified": True,
        "analysis_scope": "target_iso_rootfs",
        "host_accounts_touched": False,
        "shadow_read": False,
        "credential_secret_read": False,
        "credential_secret_staged": False,
        "secret_read": False,
        "secret_staged": False,
        "credential_policy": "deferred_secure_verified_apply",
        "source_read_only": True,
        "preserve_unrelated": True,
        "preserve_autologin": True,
        "stage_only": True,
        "existing_regular_users": ["lubuntu"],
        "available_groups": ["sudo", "users", "lubuntu"],
        "existing_user_uids": [1000],
        "existing_group_gids": [27, 100, 1000],
    }


def test_alpha50_parser_returns_users_groups_uid_gid_membership_and_non_secret_policy():
    parsed = _parse_identity_rootfs(
        "root:x:0:0:root:/root:/bin/bash\n"
        "lubuntu:x:1000:1000:Lubuntu User:/home/lubuntu:/bin/bash\n",
        "root:x:0:\nsudo:x:27:lubuntu\nusers:x:100:lubuntu\nlubuntu:x:1000:\n",
        "UID_MIN 1000\nPASS_MIN_DAYS 1\nPASS_MAX_DAYS 365\nPASS_WARN_AGE 14\nENCRYPT_METHOD SHA512\n",
    )
    assert parsed["regular_users"] == ["lubuntu"]
    user = parsed["user_records"][0]
    assert user["uid"] == 1000 and user["gid"] == 1000
    assert user["display_name"] == "Lubuntu User"
    assert user["primary_group"] == "lubuntu"
    assert set(user["groups"]) == {"lubuntu", "sudo", "users"}
    assert "sudo" in parsed["groups"]
    assert parsed["password_policy"] == {"min_days": 1, "max_days": 365, "warn_days": 14, "encrypt_method": "SHA512"}


def test_alpha50_unknown_detection_is_truthful_and_fail_closed(tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    evidence = _system_identity_rootfs_evidence(iso, [])
    assert evidence["verified"] is False
    assert evidence["capability_status"] == "UNKNOWN"
    assert evidence["password_policy_status"] == "UNKNOWN"
    assert evidence["host_accounts_touched"] is False
    assert evidence["shadow_read"] is False


def test_alpha50_real_evidence_schema_stays_target_iso_only_and_source_read_only(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"read-only-source-bytes")
    before = hashlib.sha256(iso.read_bytes()).hexdigest()
    layer = "/casper/minimal.squashfs"

    values = {
        "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nlubuntu:x:1000:1000:Lubuntu:/home/lubuntu:/bin/bash\n",
        "/etc/group": "root:x:0:\nsudo:x:27:lubuntu\nlubuntu:x:1000:\n",
        "/etc/login.defs": "UID_MIN 1000\nPASS_MAX_DAYS 365\nPASS_MIN_DAYS 1\nPASS_WARN_AGE 14\n",
    }
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: "/usr/bin/unsquashfs" if name == "unsquashfs" else None)
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layer: (4096, 100)})
    monkeypatch.setattr("chromapress.engine_cli._read_squashfs_overlay_text", lambda _iso, _layers, member, _extents=None: (values.get(member, ""), layer if member in values else ""))

    evidence = _system_identity_rootfs_evidence(iso, [layer])
    after = hashlib.sha256(iso.read_bytes()).hexdigest()
    assert before == after
    assert evidence["gate_version"] == "alpha50"
    assert evidence["analysis_scope"] == "target_iso_rootfs"
    assert evidence["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["users_groups_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["uid_gid_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["group_membership_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["password_policy_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["host_accounts_touched"] is False
    assert evidence["credential_secret_read"] is False
    assert evidence["shadow_read"] is False


def test_alpha50_create_user_admin_groups_password_policy_preflight_passes():
    change = ChangeItem("Users / Groups / Password Policy plan", ChangeKind.CONFIG, "safe", _alpha50_user_payload())
    status, message = run_preflight(change)
    assert status == ChangeStatus.PASS
    assert "capability-gated" in message
    assert "credential-secret free" in message


def test_alpha50_modify_user_and_create_group_are_supported():
    payload = _alpha50_user_payload()
    payload.update({
        "operation": "modify_user",
        "plan_slot": "user:lubuntu",
        "username": "lubuntu",
        "target_exists": True,
        "uid": None,
        "uid_mode": "preserve",
        "primary_gid": None,
        "primary_gid_mode": "preserve",
        "display_name_mode": "preserve",
        "supplementary_groups": [],
        "group_membership_mode": "preserve",
        "password_policy": {"mode": "preserve"},
        "require_password_policy_reverification_before_apply": False,
        "account_role": "standard",
        "admin_group": "",
    })
    status, _ = run_preflight(ChangeItem("Users", ChangeKind.CONFIG, "modify", payload))
    assert status == ChangeStatus.PASS

    group = _alpha50_user_payload()
    group.update({
        "operation": "create_group",
        "plan_slot": "group:research",
        "target_group": "research",
        "group_gid": 1501,
        "password_policy": {"mode": "preserve"},
        "group_membership_mode": "preserve",
    })
    status, _ = run_preflight(ChangeItem("Groups", ChangeKind.CONFIG, "create group", group))
    assert status == ChangeStatus.PASS


def test_alpha50_unknown_or_unsupported_capability_is_blocked():
    for state in ("UNKNOWN", "UNSUPPORTED", "BLOCKED"):
        payload = _alpha50_user_payload()
        payload["capability_status"] = state
        status, _ = run_preflight(ChangeItem("Users", ChangeKind.CONFIG, "blocked", payload))
        assert status == ChangeStatus.FAIL


def test_alpha50_secret_material_is_rejected_even_if_injected_into_project_payload():
    for key in ("password", "password_hash", "secret", "token", "recovery_secret"):
        payload = _alpha50_user_payload()
        payload[key] = "must-never-be-serialized-as-a-plan-secret"
        status, _ = run_preflight(ChangeItem("Users", ChangeKind.CONFIG, "bad", payload))
        assert status == ChangeStatus.FAIL


def test_alpha50_identity_plan_preserves_separate_autologin_policy():
    payload = _alpha50_user_payload()
    payload["preserve_autologin"] = False
    status, _ = run_preflight(ChangeItem("Users", ChangeKind.CONFIG, "bad", payload))
    assert status == ChangeStatus.FAIL

    autologin = {
        "config_type": "system_autologin",
        "source_sha256": "b" * 64,
        "rootfs_autologin_verified": True,
        "display_manager": "sddm",
        "display_manager_layer": "/casper/minimal.squashfs",
        "operation": "enable_autologin",
        "target_user": "chromatest",
        "require_target_user_verification_before_apply": True,
        "credential_secret_staged": False,
        "credential_secret_read": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }
    status, _ = run_preflight(ChangeItem("Autologin", ChangeKind.CONFIG, "existing gate", autologin))
    assert status == ChangeStatus.PASS


def test_alpha50_acceptance_runner_has_dedicated_users_groups_password_gate():
    text = (Path(__file__).parents[1] / "chromapress_acceptance.py").read_text(encoding="utf-8")
    assert "P4-REAL-ROOTFS-USERS-GROUPS-PASSWORD" in text
    assert 'identity.get("gate_version") == "alpha50"' in text
    assert 'identity.get("host_accounts_touched") is False' in text


def test_alpha50_version_markers():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
