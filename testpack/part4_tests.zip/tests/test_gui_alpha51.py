from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis() -> dict:
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_network_dns_evidence": {
            "gate_version": "alpha51",
            "analysis_scope": "target_iso_rootfs",
            "verified": True,
            "reason": "PASS — Alpha 51 networking",
            "capability_status": "SUPPORTED_WITH_REQUIREMENTS",
            "addressing_status": "SUPPORTED_WITH_REQUIREMENTS",
            "dns_status": "SUPPORTED_WITH_REQUIREMENTS",
            "networkmanager_profile_status": "SUPPORTED_WITH_REQUIREMENTS",
            "ipv6_status": "BLOCKED",
            "ipv6_exposed": False,
            "backend": "NetworkManager",
            "backend_config_path": "/etc/NetworkManager/NetworkManager.conf",
            "backend_config_layer": "/casper/minimal.squashfs",
            "managed_config_path": "/etc/NetworkManager/system-connections/90-chromapress.nmconnection",
            "managed_config_style": "networkmanager-keyfile",
            "resolver_path": "/etc/resolv.conf",
            "resolver_layer": "/casper/minimal.squashfs",
            "supported_operations": ["configure_dns_servers", "configure_dhcp_ipv4", "configure_static_ipv4", "create_networkmanager_profile", "set_networkmanager_autoconnect"],
            "networkmanager_profile_names": ["wired.nmconnection"],
            "connection_profiles_inspected": False,
            "connection_profile_contents_read": False,
            "profile_names_from_metadata_only": True,
            "wifi_vpn_secrets_read": False,
            "credential_secret_read": False,
            "host_network_accessed": False,
            "source_read_only": True,
        },
    }


def _quiet(monkeypatch):
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.changes.QMessageBox.information", lambda *a, **k: None)


def test_alpha51_quick_mode_only_offers_safe_normal_network_choices(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    values = {str(page.network_operation.itemData(i)) for i in range(page.network_operation.count())}
    assert values == {"preserve", "configure_dns_servers", "configure_dhcp_ipv4"}
    assert page.network_depth.currentData() == "quick"
    assert "BLOCKED" in page.network_capability_value.text()


def test_alpha51_dhcp_changes_test_and_undo(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.network_operation.setCurrentIndex(page.network_operation.findData("configure_dhcp_ipv4"))
    page.network_profile_name.setText("ChromaPress Ethernet")
    page.network_interface.setText("enp1s0")
    page.stage_network_btn.click()
    assert len(emitted) == 1
    payload = emitted[0].payload
    assert payload["operation"] == "configure_dhcp_ipv4"
    assert payload["host_network_accessed"] is False
    assert payload["source_read_only"] is True

    changes = ChangesPanel()
    changes.set_changes([])
    changes.add_change(emitted[0])
    changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == []


def test_alpha51_advanced_static_ipv4_and_dns_stage(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.network_depth.setCurrentIndex(page.network_depth.findData("advanced"))
    page.network_operation.setCurrentIndex(page.network_operation.findData("configure_static_ipv4"))
    page.network_profile_name.setText("Static LAN")
    page.network_interface.setText("enp1s0")
    page.network_ipv4_address.setText("192.168.20.10/24")
    page.network_gateway.setText("192.168.20.1")
    page.network_dns_target.setText("1.1.1.1, 9.9.9.9")
    page.stage_network_btn.click()
    assert len(emitted) == 1
    assert emitted[0].payload["target_ipv4_address"] == "192.168.20.10/24"
    assert emitted[0].payload["target_gateway"] == "192.168.20.1"
    assert emitted[0].payload["target_dns_servers"] == ["1.1.1.1", "9.9.9.9"]


def test_alpha51_networkmanager_profile_autoconnect_stages_only_verified_filename(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.network_depth.setCurrentIndex(page.network_depth.findData("advanced"))
    page.network_operation.setCurrentIndex(page.network_operation.findData("set_networkmanager_autoconnect"))
    page.network_existing_profile.setCurrentIndex(page.network_existing_profile.findData("wired.nmconnection"))
    page.network_autoconnect.setCurrentIndex(1)
    page.stage_network_btn.click()
    assert len(emitted) == 1
    assert emitted[0].payload["existing_profile_filename"] == "wired.nmconnection"
    assert emitted[0].payload["autoconnect_enabled"] is False
    assert emitted[0].payload["connection_profile_contents_read"] is False


def test_alpha51_unknown_network_capability_blocks_staging(qapp, monkeypatch):
    _quiet(monkeypatch)
    data = _analysis()
    data["system_network_dns_evidence"] = dict(data["system_network_dns_evidence"])
    data["system_network_dns_evidence"].update({"verified": False, "capability_status": "UNKNOWN", "supported_operations": []})
    page = SystemPage()
    page.set_analysis(data)
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.stage_network_btn.click()
    assert emitted == []
