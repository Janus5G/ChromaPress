from __future__ import annotations

import hashlib
from pathlib import Path

from chromapress.engine_cli import _system_restricted_session_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _autologin(verified=True, dm="sddm"):
    return {
        "verified": verified,
        "display_manager": dm if verified else "",
        "display_manager_layer": "/casper/minimal.squashfs" if verified else "",
    }


def _login(capability="SUPPORTED_WITH_REQUIREMENTS"):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "capability_status": capability,
        "verified": supported,
        "existing_regular_users": ["ubuntu", "viewer"] if supported else [],
        "admin_users": ["ubuntu"] if supported else [],
    }


def _evidence(capability="SUPPORTED_WITH_REQUIREMENTS"):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha57", "analysis_scope": "target_iso_rootfs",
        "capability_status": capability, "verified": supported,
        "backend": "sddm-autologin-session-dropin" if supported else "",
        "display_manager": "sddm" if supported else "",
        "display_manager_layer": "/casper/minimal.squashfs" if supported else "",
        "session_directories": [{"path": "/usr/share/xsessions", "kind": "x11", "layer": "/casper/minimal.squashfs"}] if supported else [],
        "verified_sessions": [{"name": "lxqt.desktop", "kind": "x11", "layer": "/casper/minimal.squashfs", "directory": "/usr/share/xsessions"}] if supported else [],
        "target_config_directory": "/etc/sddm.conf.d",
        "target_config_directory_layer": "/casper/minimal.squashfs" if supported else "",
        "managed_filename": "99-chromapress-kiosk-session.conf",
        "managed_target_path": "/etc/sddm.conf.d/99-chromapress-kiosk-session.conf",
        "managed_target_present": False,
        "existing_regular_users": ["ubuntu", "viewer"] if supported else [], "admin_users": ["ubuntu"] if supported else [],
        "supported_operations": ["bind_kiosk_autologin_session"] if supported else [],
        "restriction_scope": "fixed_autologin_session_selection_only",
        "session_file_contents_read": False, "display_manager_config_contents_read": False,
        "credential_secret_read": False, "host_session_state_accessed": False,
        "pam_contents_read": False, "ssh_config_read": False, "source_read_only": True,
        "reason": f"{capability} — test evidence",
    }


def _payload(capability="SUPPORTED_WITH_REQUIREMENTS", username="chromakiosk57", existing=False):
    e = _evidence(capability)
    if existing:
        username = "viewer"
    return {
        "config_type": "restricted_session", "gate_version": "alpha57",
        "source_sha256": "a" * 64, "analysis_scope": "target_iso_rootfs",
        "capability_status": capability, "rootfs_restricted_session_verified": e["verified"],
        "operation": "bind_kiosk_autologin_session", "backend": e["backend"],
        "display_manager": e["display_manager"], "display_manager_layer": e["display_manager_layer"],
        "target_config_directory": e["target_config_directory"], "target_config_directory_layer": e["target_config_directory_layer"],
        "managed_target_path": e["managed_target_path"], "managed_target_present": False,
        "verified_sessions": list(e["verified_sessions"]), "existing_regular_users": list(e["existing_regular_users"]), "admin_users": list(e["admin_users"]),
        "username": username, "account_dependency": "verified_existing_target_user" if existing else "alpha55_dedicated_non_admin_kiosk_user",
        "session_name": "lxqt.desktop", "session_kind": "x11",
        "restriction_scope": "fixed_autologin_session_selection_only", "sddm_section": "Autologin", "sddm_key": "Session",
        "restricted_login_dependency": "alpha56_restricted_login_required", "autologin_dependency": "alpha39_autologin_same_user_required",
        "session_file_contents_read": False, "display_manager_config_contents_read": False,
        "credential_secret_read": False, "credential_secret_staged": False, "host_session_state_accessed": False,
        "pam_contents_read": False, "ssh_config_read": False,
        "preserve_existing_session_descriptors": True, "preserve_existing_display_manager_config": True,
        "preserve_other_users_sessions": True, "preserve_pam_configuration": True, "preserve_ssh_configuration": True,
        "require_managed_target_absence_reverification_before_apply": True,
        "require_dependencies_reverification_before_apply": True,
        "source_read_only": True, "preserve_unrelated": True, "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("Restricted session plan", ChangeKind.CONFIG, "test", payload))


def test_alpha57_detection_verifies_sddm_sessions_without_reading_contents(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"alpha57-source")
    before = hashlib.sha256(iso.read_bytes()).hexdigest()
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/casper/minimal.squashfs": (123, 456)})
    def listing(_iso, _layers, directory, _extents):
        if directory == "/usr/share/xsessions":
            return ["lxqt.desktop", "README", "bad name.desktop"], "/casper/minimal.squashfs"
        if directory == "/usr/share/wayland-sessions":
            return ["plasmawayland.desktop"], "/casper/minimal.squashfs"
        if directory == "/etc/sddm.conf.d":
            return ["10-theme.conf"], "/casper/minimal.squashfs"
        return [], ""
    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", listing)
    e = _system_restricted_session_evidence(iso, ["/casper/minimal.squashfs"], _autologin(), _login())
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert e["backend"] == "sddm-autologin-session-dropin"
    assert [(x["name"], x["kind"]) for x in e["verified_sessions"]] == [("lxqt.desktop", "x11"), ("plasmawayland.desktop", "wayland")]
    assert e["session_file_contents_read"] is False
    assert e["display_manager_config_contents_read"] is False
    assert e["host_session_state_accessed"] is False
    assert hashlib.sha256(iso.read_bytes()).hexdigest() == before


def test_alpha57_unknown_when_display_manager_or_session_mechanism_not_verified(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"iso")
    assert _system_restricted_session_evidence(iso, ["/casper/minimal.squashfs"], _autologin(False), _login())["capability_status"] == "UNKNOWN"
    assert _system_restricted_session_evidence(iso, ["/casper/minimal.squashfs"], _autologin(True, "lightdm"), _login())["capability_status"] == "UNKNOWN"
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/casper/minimal.squashfs": (1, 2)})
    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", lambda *_: ([], "/casper/minimal.squashfs"))
    e = _system_restricted_session_evidence(iso, ["/casper/minimal.squashfs"], _autologin(), _login())
    assert e["capability_status"] == "UNKNOWN"
    assert "UNSUPPORTED" not in e["reason"]


def test_alpha57_managed_collision_is_blocked(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"iso")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/casper/minimal.squashfs": (1, 2)})
    def listing(_iso, _layers, directory, _extents):
        if directory == "/usr/share/xsessions": return ["lxqt.desktop"], "/casper/minimal.squashfs"
        if directory == "/etc/sddm.conf.d": return ["99-chromapress-kiosk-session.conf"], "/casper/minimal.squashfs"
        return [], ""
    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", listing)
    e = _system_restricted_session_evidence(iso, ["/casper/minimal.squashfs"], _autologin(), _login())
    assert e["capability_status"] == "BLOCKED"
    assert e["managed_target_present"] is True


def test_alpha57_stages_verified_fixed_session_cleanly():
    status, message = _run(_payload())
    assert status == ChangeStatus.PASS, message
    assert "target-session/SDDM-evidence bound" in message
    assert "dependency-explicit" in message


def test_alpha57_existing_non_admin_target_can_be_used():
    assert _run(_payload(existing=True))[0] == ChangeStatus.PASS


def test_alpha57_unknown_blocked_and_unsupported_fail_closed():
    for capability in ("UNKNOWN", "BLOCKED", "UNSUPPORTED"):
        assert _run(_payload(capability))[0] == ChangeStatus.FAIL


def test_alpha57_unverified_or_fabricated_session_is_blocked():
    p = _payload(); p["session_name"] = "fake.desktop"
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["session_kind"] = "wayland"
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha57_admin_and_bad_account_dependencies_are_blocked():
    p = _payload(username="ubuntu"); p["account_dependency"] = "verified_existing_target_user"
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["account_dependency"] = "verified_existing_target_user"
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha57_alpha39_and_alpha56_dependencies_are_mandatory():
    for key, bad in (("restricted_login_dependency", ""), ("autologin_dependency", "")):
        p = _payload(); p[key] = bad
        assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha57_contents_secrets_and_host_state_are_forbidden():
    for key in ("session_file_contents_read", "display_manager_config_contents_read", "credential_secret_read", "credential_secret_staged", "host_session_state_accessed", "pam_contents_read", "ssh_config_read"):
        p = _payload(); p[key] = True
        assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha57_preservation_reverification_and_staging_are_mandatory():
    for key in ("preserve_existing_session_descriptors", "preserve_existing_display_manager_config", "preserve_other_users_sessions", "preserve_pam_configuration", "preserve_ssh_configuration", "require_managed_target_absence_reverification_before_apply", "require_dependencies_reverification_before_apply", "source_read_only", "preserve_unrelated", "stage_only"):
        p = _payload(); p[key] = False
        assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha57_acceptance_runner_has_dedicated_gate():
    text = (Path(__file__).parents[1] / "chromapress_acceptance.py").read_text(encoding="utf-8")
    assert "P4-ALPHA57-RESTRICTED-SESSION" in text
    assert "_add_alpha57_restricted_session_gate" in text
    assert "system_restricted_session_evidence" in text


def test_alpha57_acceptance_gate_executes_supported_and_unknown(tmp_path):
    import sys
    root = Path(__file__).parents[1]
    if str(root) not in sys.path: sys.path.insert(0, str(root))
    from chromapress_acceptance import AcceptanceRunner, PASS
    runner = AcceptanceRunner(root, 4, None, None, tmp_path)
    runner._add_alpha57_restricted_session_gate(_evidence(), "a" * 64)
    assert runner.checks[-1].status == PASS
    runner._add_alpha57_restricted_session_gate(_evidence("UNKNOWN"), "a" * 64)
    assert runner.checks[-1].status == PASS
    assert "fail-closed" in runner.checks[-1].detail


def test_alpha57_version_markers():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
