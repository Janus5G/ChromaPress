from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.system_page import SystemPage


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis() -> dict:
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_package_evidence": [
            {"area": "Identity / accounts", "package": "sudo", "version": "1.9"},
        ],
        "system_rootfs_verification": ["network profiles remain gated"],
        "system_identity_evidence": {
            "verified": True,
            "reason": "PASS — /etc/passwd and /etc/group verified read-only; /etc/shadow was not read.",
            "passwd_layer": "/casper/minimal.squashfs",
            "group_layer": "/casper/minimal.squashfs",
            "login_defs_layer": "/casper/minimal.squashfs",
            "uid_min": 1000,
            "regular_users": ["lubuntu"],
            "admin_groups": ["sudo"],
            "shadow_read": False,
        },
    }


def test_alpha37_system_page_shows_rootfs_identity_evidence(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert "PASS" in page.identity_status_value.text()
    assert "lubuntu" in page.identity_users_value.text()
    assert "sudo" in page.identity_admin_groups_value.text()
    assert page.identity_uid_min_value.text() == "1000"
    assert "ROOTFS IDENTITY PASS" in page.status.text()


def test_alpha37_identity_controls_default_to_preserve_and_no_secret_field(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.identity_operation.currentData() == "preserve"
    assert not page.identity_username.isEnabled()
    assert "No password" in page.credential_policy_value.text()
    assert page.identity_admin_group.itemData(0) == "sudo"
