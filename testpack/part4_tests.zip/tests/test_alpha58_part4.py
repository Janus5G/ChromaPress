from __future__ import annotations

import hashlib
from pathlib import Path

from chromapress.engine_cli import _system_service_lockdown_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _services(verified=True):
    return {
        "verified": verified,
        "init_system": "systemd" if verified else "",
        "vendor_unit_path": "/usr/lib/systemd/system" if verified else "",
        "vendor_unit_layer": "/casper/minimal.squashfs" if verified else "",
        "local_unit_path": "/etc/systemd/system" if verified else "",
        "local_unit_layer": "/casper/minimal.squashfs" if verified else "",
    }


def _evidence(capability="SUPPORTED_WITH_REQUIREMENTS"):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    units = [
        {"name": "cups.service", "directory": "/usr/lib/systemd/system", "layer": "/casper/minimal.squashfs"},
        {"name": "dbus.service", "directory": "/usr/lib/systemd/system", "layer": "/casper/minimal.squashfs"},
    ] if supported else []
    return {
        "gate_version": "alpha58", "analysis_scope": "target_iso_rootfs",
        "capability_status": capability, "verified": supported,
        "backend": "systemd-disable-mask-intent" if supported else "",
        "init_system": "systemd" if supported else "",
        "vendor_unit_path": "/usr/lib/systemd/system" if supported else "",
        "vendor_unit_layer": "/casper/minimal.squashfs" if supported else "",
        "local_unit_path": "/etc/systemd/system" if supported else "",
        "local_unit_layer": "/casper/minimal.squashfs" if supported else "",
        "verified_service_units": units,
        "available_lockdown_units": units[:1] if supported else [],
        "protected_service_units": ["dbus.service"] if supported else [],
        "supported_operations": ["disable_and_mask_verified_service"] if supported else [],
        "lockdown_scope": "single_verified_noncritical_systemd_service",
        "unit_contents_read": False, "enablement_links_read": False, "enablement_link_targets_read": False,
        "environment_files_read": False, "service_secrets_read": False, "credential_secret_read": False,
        "host_service_state_accessed": False, "source_read_only": True,
        "reason": f"{capability} — test evidence",
    }


def _payload(capability="SUPPORTED_WITH_REQUIREMENTS", unit="cups.service"):
    e = _evidence(capability)
    return {
        "config_type": "service_lockdown", "gate_version": "alpha58",
        "source_sha256": "a" * 64, "analysis_scope": "target_iso_rootfs",
        "capability_status": capability, "rootfs_service_lockdown_verified": e["verified"],
        "operation": "disable_and_mask_verified_service", "backend": e["backend"],
        "init_system": e["init_system"], "vendor_unit_path": e["vendor_unit_path"],
        "vendor_unit_layer": e["vendor_unit_layer"], "local_unit_path": e["local_unit_path"],
        "local_unit_layer": e["local_unit_layer"], "verified_service_units": e["verified_service_units"],
        "available_lockdown_units": e["available_lockdown_units"], "protected_service_units": e["protected_service_units"],
        "service_unit": unit, "service_unit_directory": "/usr/lib/systemd/system", "service_unit_layer": "/casper/minimal.squashfs",
        "lockdown_scope": "single_verified_noncritical_systemd_service",
        "unit_contents_read": False, "enablement_links_read": False, "enablement_link_targets_read": False,
        "environment_files_read": False, "service_secrets_read": False, "credential_secret_read": False,
        "host_service_state_accessed": False,
        "preserve_unit_file_contents": True, "preserve_timer_socket_units": True, "preserve_unrelated_services": True,
        "require_target_unit_reverification_before_apply": True, "require_systemd_apply_verification": True,
        "source_read_only": True, "preserve_unrelated": True, "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("Service lockdown plan", ChangeKind.CONFIG, "test", payload))


def test_alpha58_detection_lists_target_service_names_and_filters_protected(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"alpha58-source")
    before = hashlib.sha256(iso.read_bytes()).hexdigest()
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/casper/minimal.squashfs": (1, 2)})
    def listing(_iso, _layers, directory, _extents):
        if directory == "/usr/lib/systemd/system":
            return ["cups.service", "dbus.service", "systemd-logind.service", "not-a-service.timer", "bad/name.service"], "/casper/minimal.squashfs"
        if directory == "/etc/systemd/system":
            return ["custom-safe.service"], "/casper/minimal.squashfs"
        return [], ""
    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", listing)
    e = _system_service_lockdown_evidence(iso, ["/casper/minimal.squashfs"], _services())
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert [x["name"] for x in e["available_lockdown_units"]] == ["cups.service", "custom-safe.service"]
    assert "dbus.service" in e["protected_service_units"]
    assert "systemd-logind.service" in e["protected_service_units"]
    assert e["unit_contents_read"] is False
    assert e["enablement_link_targets_read"] is False
    assert e["host_service_state_accessed"] is False
    assert hashlib.sha256(iso.read_bytes()).hexdigest() == before


def test_alpha58_unknown_when_systemd_evidence_or_extents_not_verified(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"iso")
    assert _system_service_lockdown_evidence(iso, ["/casper/minimal.squashfs"], _services(False))["capability_status"] == "UNKNOWN"
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {})
    e = _system_service_lockdown_evidence(iso, ["/casper/minimal.squashfs"], _services())
    assert e["capability_status"] == "UNKNOWN"
    assert "UNSUPPORTED" not in e["reason"]


def test_alpha58_all_protected_is_blocked(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"iso")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/casper/minimal.squashfs": (1, 2)})
    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", lambda *_: (["dbus.service", "systemd-logind.service"], "/casper/minimal.squashfs"))
    e = _system_service_lockdown_evidence(iso, ["/casper/minimal.squashfs"], _services())
    assert e["capability_status"] == "BLOCKED"
    assert e["available_lockdown_units"] == []


def test_alpha58_stages_verified_nonprotected_unit():
    status, message = _run(_payload())
    assert status == ChangeStatus.PASS, message
    assert "verified-target-unit bound" in message
    assert "protected-unit filtered" in message


def test_alpha58_unknown_blocked_unsupported_fail_closed():
    for capability in ("UNKNOWN", "BLOCKED", "UNSUPPORTED"):
        assert _run(_payload(capability))[0] == ChangeStatus.FAIL


def test_alpha58_protected_or_unverified_unit_is_blocked():
    p = _payload(); p["service_unit"] = "dbus.service"
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["service_unit"] = "fake.service"
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha58_bulk_or_unsafe_target_is_blocked():
    p = _payload(); p["service_unit"] = "*.service"
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["lockdown_scope"] = "bulk"
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha58_privacy_host_and_preservation_flags_are_enforced():
    for key in ("unit_contents_read", "enablement_link_targets_read", "environment_files_read", "service_secrets_read", "credential_secret_read", "host_service_state_accessed"):
        p = _payload(); p[key] = True
        assert _run(p)[0] == ChangeStatus.FAIL
    for key in ("preserve_unit_file_contents", "preserve_timer_socket_units", "preserve_unrelated_services", "source_read_only", "preserve_unrelated", "stage_only"):
        p = _payload(); p[key] = False
        assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha58_apply_reverification_is_required():
    p = _payload(); p["require_target_unit_reverification_before_apply"] = False
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["require_systemd_apply_verification"] = False
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha58_acceptance_gate_executes_supported_and_unknown(tmp_path):
    import sys
    root = Path(__file__).parents[1]
    if str(root) not in sys.path: sys.path.insert(0, str(root))
    from chromapress_acceptance import AcceptanceRunner, PASS
    runner = AcceptanceRunner(root, 4, None, None, tmp_path)
    runner._add_alpha58_service_lockdown_gate(_evidence(), "a" * 64)
    assert runner.checks[-1].status == PASS
    runner._add_alpha58_service_lockdown_gate(_evidence("UNKNOWN"), "a" * 64)
    assert runner.checks[-1].status == PASS
    assert "fail-closed" in runner.checks[-1].detail


def test_alpha58_version_markers():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
