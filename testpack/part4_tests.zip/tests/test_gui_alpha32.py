from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.boot_hardware_page import BootHardwarePage
from chromapress.models import ChangeKind, ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis():
    return {
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "rootfs": ["/casper/minimal.squashfs"],
        "rootfs_details": [{"path": "/casper/minimal.squashfs", "compression": "xz", "block_size": 131072}],
        "initramfs_mechanism": "update-initramfs",
    }


def test_alpha32_persistence_controls_require_complete_evidence(qapp):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    assert page.stage_persistence_btn.isEnabled()
    assert page.persistence_layer_combo.count() == 2
    assert "only listed directories survive reboot" in page.persistence_survival_value.text().lower()


def test_alpha32_persistence_plan_stages_selected_directories(qapp, monkeypatch):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.boot_hardware_page.QMessageBox.information", lambda *a, **k: None)
    page.persistence_layer_combo.setCurrentIndex(1)
    page.persistence_directories_edit.setText("/var/lib/app;/home/kiosk/data")
    page.persistence_storage_combo.setCurrentIndex(1)
    page.persistence_size_spin.setValue(4096)
    page.persistence_label_edit.setText("CHROMAPERSIST")
    page.stage_persistence_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "controlled_persistence"
    assert change.payload["persistent_directories"] == ["/var/lib/app", "/home/kiosk/data"]
    assert change.payload["selected_directories_survive_reboot"] is True
    assert change.payload["unlisted_runtime_changes_survive_reboot"] is False
    assert change.payload["do_not_repartition_source_iso"] is True
    assert change.payload["stage_only"] is True


def test_alpha32_rejects_unsafe_persistence_path_in_gui(qapp, monkeypatch):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.boot_hardware_page.QMessageBox.information", lambda *a, **k: None)
    page.persistence_layer_combo.setCurrentIndex(1)
    page.persistence_directories_edit.setText("/proc/state")
    page.persistence_storage_combo.setCurrentIndex(1)
    page.stage_persistence_btn.click()
    assert not emitted
    assert "cannot be staged" in page.persistence_plan_status.text().lower()


def test_alpha32_source_switch_blocks_stale_persistence_plan(qapp):
    from chromapress.gui.main_window import MainWindow
    from chromapress.models import ChangeItem
    window = MainWindow()
    change = ChangeItem("Controlled persistence plan", ChangeKind.CONFIG, "test", {
        "config_type": "controlled_persistence",
        "source_sha256": "a" * 64,
    })
    window.project.changes.append(change)
    window.changes.set_changes(window.project.changes)
    window._guard_boot_plan_source("b" * 64)
    assert change.status == ChangeStatus.BLOCKED
    window.close()
