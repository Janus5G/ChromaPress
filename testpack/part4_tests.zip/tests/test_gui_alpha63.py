import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QMessageBox

from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _fido2(cap="SUPPORTED_WITH_REQUIREMENTS"):
    supported = cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha63",
        "analysis_scope": "target_iso_package_manifest",
        "capability_status": cap,
        "verified": supported,
        "backend": "pam-fido2-policy-intent",
        "package_format": "deb",
        "pam_fido2_packages": ["libpam-u2f"] if supported else [],
        "libfido2_packages": ["libfido2-1"] if supported else [],
        "fido2_tool_packages": ["fido2-tools"] if supported else [],
        "supported_operations": ["require_fido2_second_factor_for_recovery_admin"] if supported else [],
        "policy_scope": "recovery_administrator_fido2_second_factor",
        "alpha62_dependency_verified": supported,
        "pam_contents_read": False,
        "pam_contents_modified_during_analysis": False,
        "authenticator_devices_enumerated": False,
        "usb_hid_state_accessed": False,
        "credential_ids_read": False,
        "credential_secret_read": False,
        "credential_secret_staged": False,
        "authenticator_enrollment_performed": False,
        "webauthn_capability_claimed": False,
        "security_key_presence_claimed": False,
        "yubikey_capability_claimed": False,
        "platform_authenticator_claimed": False,
        "tpm_capability_claimed": False,
        "host_authenticator_state_accessed": False,
        "source_read_only": True,
        "reason": "PASS" if supported else f"{cap} — blocked",
    }


def _admin():
    return {
        "gate_version": "alpha62",
        "capability_status": "SUPPORTED_WITH_REQUIREMENTS",
        "verified": True,
        "existing_admin_users": ["liveadmin"],
        "autologin_user": "kiosk",
    }


def _analysis(cap="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "sha256": "a" * 64,
        "system_admin_recovery_policy_evidence": _admin(),
        "system_fido2_policy_evidence": _fido2(cap),
    }


def test_alpha63_stage_test_and_undo(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    changes = ChangesPanel(); page.stage_requested.connect(changes.add_change)
    page.fido2_operation.setCurrentIndex(page.fido2_operation.findData("require_fido2_second_factor_for_recovery_admin"))
    page.fido2_username.setText("liveadmin")
    page.stage_fido2_btn.click()
    assert len(changes.changes) == 1
    payload = changes.changes[0].payload
    assert payload["administrator_recovery_dependency"] == "alpha62_administrator_recovery_policy"
    assert payload["authentication_composition"] == "existing_primary_plus_fido2_second_factor"
    assert payload["authenticator_enrollment_performed"] is False
    changes.list.setCurrentRow(0); changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == [] and changes.summary.text() == "No changes staged"


def test_alpha63_unknown_gui_fails_closed(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis("UNKNOWN"))
    emitted = []; page.stage_requested.connect(emitted.append)
    page.fido2_operation.setCurrentIndex(page.fido2_operation.findData("require_fido2_second_factor_for_recovery_admin"))
    page.fido2_username.setText("liveadmin")
    page.stage_fido2_btn.click()
    assert emitted == []
    assert "UNKNOWN" in page.fido2_plan_status.text()


def test_alpha63_root_and_autologin_gui_are_blocked(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    emitted = []; page.stage_requested.connect(emitted.append)
    page.fido2_operation.setCurrentIndex(page.fido2_operation.findData("require_fido2_second_factor_for_recovery_admin"))
    page.fido2_username.setText("root"); page.stage_fido2_btn.click()
    page.fido2_username.setText("kiosk"); page.stage_fido2_btn.click()
    assert emitted == []
