from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_restricted_login_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _identity(verified=True):
    return {
        "verified": verified,
        "users_groups_status": "SUPPORTED_WITH_REQUIREMENTS" if verified else "UNKNOWN",
        "passwd_layer": "/casper/minimal.squashfs" if verified else "",
        "group_layer": "/casper/minimal.squashfs" if verified else "",
        "regular_users": ["ubuntu"],
        "admin_groups": ["sudo"],
        "user_records": [
            {"username": "ubuntu", "uid": 1000, "groups": ["sudo", "ubuntu"]},
            {"username": "viewer", "uid": 1001, "groups": ["users"]},
        ],
    }


def _evidence(capability="SUPPORTED_WITH_REQUIREMENTS"):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha56", "analysis_scope": "target_iso_rootfs",
        "capability_status": capability, "verified": supported,
        "backend": "shadow-utils-usermod" if supported else "",
        "management_tool_path": "/usr/sbin/usermod" if supported else "",
        "management_tool_layer": "/casper/minimal.squashfs" if supported else "",
        "passwd_layer": "/casper/minimal.squashfs" if supported else "",
        "group_layer": "/casper/minimal.squashfs" if supported else "",
        "existing_regular_users": ["ubuntu", "viewer"] if supported else [],
        "admin_users": ["ubuntu"] if supported else [],
        "supported_operations": ["lock_password_authentication"] if supported else [],
        "restriction_scope": "password_authentication_only",
        "shadow_read": False, "credential_secret_read": False, "host_login_state_accessed": False,
        "pam_contents_read": False, "ssh_config_read": False, "autologin_policy_read": False,
        "session_policy_read": False, "source_read_only": True,
        "reason": f"{capability} — test evidence",
    }


def _payload(capability="SUPPORTED_WITH_REQUIREMENTS", username="chromakiosk56", existing=False):
    e = _evidence(capability)
    if existing:
        username = "viewer"
    return {
        "config_type": "restricted_login", "gate_version": "alpha56",
        "source_sha256": "a" * 64, "analysis_scope": "target_iso_rootfs",
        "capability_status": capability, "rootfs_login_restriction_verified": e["verified"],
        "operation": "lock_password_authentication", "backend": e["backend"],
        "management_tool_path": e["management_tool_path"], "management_tool_layer": e["management_tool_layer"],
        "passwd_layer": e["passwd_layer"], "group_layer": e["group_layer"],
        "existing_regular_users": list(e["existing_regular_users"]), "admin_users": list(e["admin_users"]),
        "username": username,
        "account_dependency": "verified_existing_target_user" if existing else "alpha55_dedicated_non_admin_kiosk_user",
        "restriction_scope": "password_authentication_only", "password_authentication": "locked",
        "credential_secret_read": False, "credential_secret_staged": False, "shadow_read": False,
        "host_login_state_accessed": False, "pam_contents_read": False, "ssh_config_read": False,
        "preserve_autologin": True, "preserve_session_policy": True,
        "preserve_ssh_configuration": True, "preserve_pam_configuration": True,
        "require_account_dependency_reverification_before_apply": True,
        "source_read_only": True, "preserve_unrelated": True, "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("Restricted login plan", ChangeKind.CONFIG, "test", payload))


def test_alpha56_detection_uses_target_rootfs_tool_only(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/casper/minimal.squashfs": (123, 456)})
    def present(_iso, _layers, member, _extents):
        if member == "/usr/sbin/usermod":
            return True, "/casper/minimal.squashfs"
        return False, ""
    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", present)
    e = _system_restricted_login_evidence(iso, ["/casper/minimal.squashfs"], _identity(True))
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert e["backend"] == "shadow-utils-usermod"
    assert e["management_tool_path"] == "/usr/sbin/usermod"
    assert e["admin_users"] == ["ubuntu"]
    assert e["shadow_read"] is False
    assert e["host_login_state_accessed"] is False
    assert e["pam_contents_read"] is False
    assert e["ssh_config_read"] is False
    assert e["source_read_only"] is True


def test_alpha56_unverified_or_missing_mechanism_is_unknown(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    e = _system_restricted_login_evidence(iso, ["/casper/minimal.squashfs"], _identity(False))
    assert e["capability_status"] == "UNKNOWN"
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/casper/minimal.squashfs": (123, 456)})
    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", lambda *_: (False, ""))
    e = _system_restricted_login_evidence(iso, ["/casper/minimal.squashfs"], _identity(True))
    assert e["capability_status"] == "UNKNOWN"
    assert "UNSUPPORTED" not in e["reason"]


def test_alpha56_planned_kiosk_dependency_stages_cleanly():
    status, message = _run(_payload())
    assert status == ChangeStatus.PASS, message
    assert "password-lock scoped" in message
    assert "dependency-explicit" in message


def test_alpha56_existing_non_admin_user_can_be_targeted():
    assert _run(_payload(existing=True))[0] == ChangeStatus.PASS


def test_alpha56_unknown_blocked_and_unsupported_fail_closed():
    for capability in ("UNKNOWN", "BLOCKED", "UNSUPPORTED"):
        assert _run(_payload(capability))[0] == ChangeStatus.FAIL


def test_alpha56_root_and_verified_admin_are_blocked():
    p = _payload(username="root")
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(username="ubuntu")
    p["account_dependency"] = "verified_existing_target_user"
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha56_missing_user_requires_alpha55_dependency():
    p = _payload()
    p["account_dependency"] = "verified_existing_target_user"
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha56_secret_host_pam_and_ssh_access_are_forbidden():
    for key in ("credential_secret_read", "credential_secret_staged", "shadow_read", "host_login_state_accessed", "pam_contents_read", "ssh_config_read"):
        p = _payload()
        p[key] = True
        assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha56_other_login_mechanisms_are_preserved():
    for key in ("preserve_autologin", "preserve_session_policy", "preserve_ssh_configuration", "preserve_pam_configuration"):
        p = _payload()
        p[key] = False
        assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha56_reverification_preservation_and_staging_are_mandatory():
    for key in ("require_account_dependency_reverification_before_apply", "source_read_only", "preserve_unrelated", "stage_only"):
        p = _payload()
        p[key] = False
        assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha56_acceptance_runner_has_dedicated_gate():
    text = (Path(__file__).parents[1] / "chromapress_acceptance.py").read_text(encoding="utf-8")
    assert "P4-ALPHA56-RESTRICTED-LOGIN" in text
    assert "_add_alpha56_restricted_login_gate" in text
    assert "system_restricted_login_evidence" in text


def test_alpha56_acceptance_gate_executes_supported_and_unknown(tmp_path):
    import sys
    root = Path(__file__).parents[1]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    from chromapress_acceptance import AcceptanceRunner, PASS
    runner = AcceptanceRunner(root, 4, None, None, tmp_path)
    runner._add_alpha56_restricted_login_gate(_evidence(), "a" * 64)
    assert runner.checks[-1].status == PASS
    runner._add_alpha56_restricted_login_gate(_evidence("UNKNOWN"), "a" * 64)
    assert runner.checks[-1].status == PASS
    assert "fail-closed" in runner.checks[-1].detail


def test_alpha56_version_markers():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
