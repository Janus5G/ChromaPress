from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.system_page import SystemPage


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def test_alpha36_system_page_is_read_only_and_evidence_backed(qapp):
    page = SystemPage()
    page.set_analysis({
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_package_evidence": [
            {"area": "Networking / DNS", "package": "network-manager", "version": "1.46"},
            {"area": "Firewall", "package": "ufw", "version": "0.36"},
        ],
        "system_rootfs_verification": ["users/groups/default user + UID/GID/admin policy"],
    })
    assert page.package_format_value.text() == "deb"
    assert "Networking / DNS" in page.areas_value.text()
    assert "READ-ONLY PASS" in page.status.text()
    assert page.evidence_tree.topLevelItemCount() == 2


def test_alpha36_system_page_does_not_guess_when_manifest_has_no_match(qapp):
    page = SystemPage()
    page.set_analysis({
        "sha256": "b" * 64,
        "package_format": "deb",
        "system_package_evidence": [],
        "system_rootfs_verification": ["enabled systemd services/timers/targets/startup"],
    })
    assert "No matching" in page.areas_value.text()
    assert page.evidence_tree.topLevelItemCount() == 1
    assert "READ-ONLY PASS" in page.status.text()
