from pathlib import Path
import pytest
from chromapress.engine_cli import _system_security_key_policy_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight
from chromapress_acceptance import AcceptanceRunner

def _admin(cap="SUPPORTED_WITH_REQUIREMENTS"):
    ok=cap in {"SUPPORTED","SUPPORTED_WITH_REQUIREMENTS"}
    return {"gate_version":"alpha62","capability_status":cap,"verified":ok,"existing_admin_users":["liveadmin"] if ok else [],"autologin_user":"kiosk" if ok else "","shadow_read":False,"credential_secret_read":False,"recovery_secret_read":False,"pam_contents_read":False,"ssh_config_read":False,"rescue_boot_config_read":False,"root_account_policy_read":False,"host_accounts_touched":False,"host_login_state_accessed":False}

def _fido(cap="SUPPORTED_WITH_REQUIREMENTS"):
    ok=cap in {"SUPPORTED","SUPPORTED_WITH_REQUIREMENTS"}
    return {"gate_version":"alpha63","capability_status":cap,"verified":ok}

def _evidence(tools=True, lib=True, fido="SUPPORTED_WITH_REQUIREMENTS"):
    v={"base-files":"1"}
    if tools: v["fido2-tools"]="1.15"
    if lib: v["libfido2-1"]="1.15"
    return _system_security_key_policy_evidence("deb",v,_admin(),_fido(fido))

def _payload(e=None, username="liveadmin"):
    e=dict(e or _evidence())
    return {"config_type":"security_key_policy","gate_version":"alpha65","source_sha256":"a"*64,"analysis_scope":"target_iso_package_manifest","capability_status":e.get("capability_status"),"security_key_policy_verified":e.get("verified") is True,"operation":"allow_external_fido2_security_key_for_recovery_admin","policy_scope":"recovery_administrator_external_security_key","username":username,"current_autologin_user":"kiosk","administrator_recovery_dependency":"alpha62_administrator_recovery_policy","fido2_dependency":"alpha63_fido2_policy","alpha62_dependency_verified":e.get("alpha62_dependency_verified") is True,"alpha63_dependency_verified":e.get("alpha63_dependency_verified") is True,"security_key_tool_packages":list(e.get("security_key_tool_packages") or []),"libfido2_packages":list(e.get("libfido2_packages") or []),"physical_security_key_enumerated":False,"security_key_presence_claimed":False,"security_key_compatibility_claimed":False,"credential_ids_read":False,"credential_secret_read":False,"credential_secret_staged":False,"authenticator_enrollment_performed":False,"usb_hid_state_accessed":False,"yubikey_capability_claimed":False,"platform_authenticator_claimed":False,"tpm_capability_claimed":False,"host_authenticator_state_accessed":False,"preserve_existing_primary_authentication":True,"require_physical_key_verification_before_apply":True,"require_key_compatibility_verification_before_apply":True,"require_explicit_enrollment_before_use":True,"require_recovery_username_reverification_before_apply":True,"require_target_package_reverification_before_apply":True,"source_read_only":True,"preserve_unrelated":True,"stage_only":True}

def _run(p): return run_preflight(ChangeItem("Security-key policy plan",ChangeKind.CONFIG,"test",p))

def test_alpha65_supported_metadata_is_requirements_only():
    e=_evidence(); assert e["capability_status"]=="SUPPORTED_WITH_REQUIREMENTS" and e["verified"] is True
    assert e["security_key_tool_packages"]==["fido2-tools"] and e["libfido2_packages"]==["libfido2-1"]
    assert e["security_key_presence_claimed"] is False

def test_alpha65_missing_tools_or_fido_dependency_is_unknown():
    assert _evidence(tools=False)["capability_status"]=="UNKNOWN"
    assert _evidence(fido="UNKNOWN")["capability_status"]=="UNKNOWN"

def test_alpha65_supported_preflight_passes():
    st,msg=_run(_payload()); assert st==ChangeStatus.PASS and "physical-key/enrollment/credential claims deferred" in msg

@pytest.mark.parametrize("cap",["UNKNOWN","BLOCKED","UNSUPPORTED"])
def test_alpha65_unverified_capability_fails_closed(cap):
    e=_evidence(); e["capability_status"]=cap; e["verified"]=False
    assert _run(_payload(e))[0]==ChangeStatus.FAIL

def test_alpha65_blocks_root_autologin_and_device_claims():
    assert _run(_payload(username="root"))[0]==ChangeStatus.FAIL
    assert _run(_payload(username="kiosk"))[0]==ChangeStatus.FAIL
    for key in ("physical_security_key_enumerated","security_key_presence_claimed","security_key_compatibility_claimed","credential_ids_read","credential_secret_read","credential_secret_staged","authenticator_enrollment_performed","usb_hid_state_accessed","yubikey_capability_claimed","platform_authenticator_claimed","tpm_capability_claimed","host_authenticator_state_accessed"):
        p=_payload(); p[key]=True; assert _run(p)[0]==ChangeStatus.FAIL, key

def test_alpha65_acceptance_supported_and_unknown(tmp_path):
    r=AcceptanceRunner(tmp_path,4,None,None,tmp_path/'reports'); e=_evidence(); r._add_alpha65_security_key_gate(e,_admin(),"a"*64); assert r.checks[-1].status=="PASS"
    e["capability_status"]="UNKNOWN"; e["verified"]=False; e["security_key_tool_packages"]=[]; r._add_alpha65_security_key_gate(e,_admin(),"a"*64); assert r.checks[-1].status=="PASS"

def test_alpha65_version_and_source_guard():
    root=Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root/'pyproject.toml').read_text()
    text=(root/'src/chromapress/gui/main_window.py').read_text(); assert '"security_key_policy"' in text
