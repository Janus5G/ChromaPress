from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _selinux_evidence(capability="SUPPORTED_WITH_REQUIREMENTS"):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha52",
        "analysis_scope": "target_iso_rootfs",
        "verified": supported,
        "reason": f"{capability} — test evidence",
        "capability_status": capability,
        "installed_present": True,
        "configured_mode": "disabled",
        "policy_type": "targeted",
        "config_path": "/etc/selinux/config",
        "config_layer": "/casper/minimal.squashfs",
        "config_metadata_read": True,
        "config_creation_required": False,
        "policy_tree_present": True,
        "policy_entries": ["targeted", "local-custom"],
        "policy_contents_read": False,
        "custom_policy_preserved": True,
        "package_manager": "apt",
        "package_manager_path": "/usr/bin/apt-get",
        "repository_metadata_path": "/etc/apt/sources.list.d",
        "package_install_required": False,
        "required_packages": [],
        "kernel_support_status": "SUPPORTED",
        "kernel_config_path": "/boot/config-test",
        "kernel_images": ["/casper/vmlinuz"],
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "initramfs_mechanism": "update-initramfs",
        "part3_dependency_required": True,
        "part3_requirements": [
            {"model": "part3_kernel_initramfs", "action": "verify_and_regenerate_if_required", "initramfs_mechanism": "update-initramfs"},
            {"model": "part3_boot", "action": "verify_selinux_boot_parameters", "boot_config_files": ["/boot/grub/grub.cfg"], "forbid_parameters": ["selinux=0"]},
        ],
        "relabel_required_on_enable": True,
        "reboot_required": True,
        "supported_modes": ["enforcing", "permissive", "disabled"] if supported else [],
        "supported_operations": ["set_selinux_mode"] if supported else [],
        "host_selinux_accessed": False,
        "host_security_state_accessed": False,
        "source_read_only": True,
        "secret_read": False,
    }


def _analysis(capability="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_selinux_evidence": _selinux_evidence(capability),
    }


def _quiet(monkeypatch):
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.changes.QMessageBox.information", lambda *a, **k: None)


def test_alpha52_supported_modes_are_exposed_only_when_verified(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    values = {str(page.selinux_mode.itemData(i)) for i in range(page.selinux_mode.count())}
    assert values == {"preserve", "enforcing", "permissive", "disabled"}

    blocked = SystemPage()
    blocked.set_analysis(_analysis("UNKNOWN"))
    values = {str(blocked.selinux_mode.itemData(i)) for i in range(blocked.selinux_mode.count())}
    assert values == {"preserve"}
    assert "UNKNOWN" in blocked.selinux_capability_value.text()


def test_alpha52_selinux_changes_test_and_undo(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.selinux_mode.setCurrentIndex(page.selinux_mode.findData("permissive"))
    page.stage_selinux_btn.click()
    assert len(emitted) == 1
    payload = emitted[0].payload
    assert payload["config_type"] == "system_selinux"
    assert payload["target_mode"] == "permissive"
    assert payload["delegate_boot_kernel_to_part3"] is True
    assert payload["direct_boot_mutation"] is False
    assert payload["preserve_existing_policies"] is True
    assert payload["host_selinux_accessed"] is False

    changes = ChangesPanel()
    changes.set_changes([])
    changes.add_change(emitted[0])
    changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == []


def test_alpha52_unknown_gui_staging_fails_closed(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis("UNKNOWN"))
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.stage_selinux_btn.click()
    assert emitted == []
