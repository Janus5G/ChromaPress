from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _parse_login_defs_security_defaults, _system_security_defaults_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _identity(*, verified=True, login_defs=True, metadata=None):
    return {
        "verified": verified,
        "login_defs_present": login_defs,
        "login_defs_layer": "/casper/minimal.squashfs" if login_defs else "",
        "security_defaults": metadata or {"umask": "022", "umask_present": True, "usergroups_enab": "yes"},
    }


def _payload(umask="027", capability="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "config_type": "system_security_defaults",
        "gate_version": "alpha53",
        "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_rootfs",
        "capability_status": capability,
        "rootfs_security_defaults_verified": capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"},
        "operation": "set_default_umask",
        "target_umask": umask,
        "supported_umasks": ["022", "027", "077"],
        "backend": "shadow-utils-login.defs",
        "config_path": "/etc/login.defs",
        "config_layer": "/casper/minimal.squashfs",
        "current_umask": "022",
        "umask_directive_present": True,
        "usergroups_enab": "yes",
        "metadata_keys_read": ["UMASK", "USERGROUPS_ENAB"],
        "require_target_directive_reverification_before_apply": True,
        "require_effective_session_semantics_verification_before_apply": True,
        "preserve_login_defs_unrelated": True,
        "preserve_pam_configuration": True,
        "preserve_account_policy": True,
        "full_config_exposed": False,
        "credential_secret_read": False,
        "credential_secret_staged": False,
        "host_security_state_accessed": False,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("Security defaults plan", ChangeKind.CONFIG, "test", payload))


def test_alpha53_parses_only_allowlisted_login_security_metadata():
    parsed = _parse_login_defs_security_defaults(
        "PASS_MAX_DAYS 99999\nUMASK 027\nUSERGROUPS_ENAB yes\nSECRET_THING no\n"
    )
    assert parsed == {"umask": "027", "umask_present": True, "usergroups_enab": "yes"}


def test_alpha53_verified_login_defs_is_supported_with_requirements():
    evidence = _system_security_defaults_evidence(_identity())
    assert evidence["gate_version"] == "alpha53"
    assert evidence["analysis_scope"] == "target_iso_rootfs"
    assert evidence["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["verified"] is True
    assert evidence["backend"] == "shadow-utils-login.defs"
    assert evidence["current_umask"] == "022"
    assert evidence["supported_umasks"] == ["022", "027", "077"]
    assert evidence["credential_secret_read"] is False
    assert evidence["host_security_state_accessed"] is False
    assert evidence["source_read_only"] is True


def test_alpha53_missing_or_unverified_login_defs_is_unknown_not_unsupported():
    for identity in (_identity(verified=False), _identity(login_defs=False)):
        evidence = _system_security_defaults_evidence(identity)
        assert evidence["capability_status"] == "UNKNOWN"
        assert evidence["verified"] is False
        assert "UNSUPPORTED" not in evidence["reason"]


def test_alpha53_allowlisted_umasks_stage_cleanly():
    for value in ("022", "027", "077"):
        status, message = _run(_payload(value))
        assert status == ChangeStatus.PASS, message
        assert "UMASK-allowlisted" in message


def test_alpha53_invalid_umask_is_rejected():
    for value in ("0022", "777", "028", "abc", ""):
        assert _run(_payload(value))[0] == ChangeStatus.FAIL


def test_alpha53_unknown_blocked_unsupported_fail_closed():
    for capability in ("UNKNOWN", "BLOCKED", "UNSUPPORTED"):
        assert _run(_payload(capability=capability))[0] == ChangeStatus.FAIL


def test_alpha53_preservation_and_host_secret_isolation_are_enforced():
    payload = _payload()
    payload["preserve_pam_configuration"] = False
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload()
    payload["full_config_exposed"] = True
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload()
    payload["credential_secret_read"] = True
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload()
    payload["host_security_state_accessed"] = True
    assert _run(payload)[0] == ChangeStatus.FAIL


def test_alpha53_apply_reverification_is_mandatory():
    payload = _payload()
    payload["require_target_directive_reverification_before_apply"] = False
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload()
    payload["require_effective_session_semantics_verification_before_apply"] = False
    assert _run(payload)[0] == ChangeStatus.FAIL


def test_alpha53_metadata_scope_is_strict():
    payload = _payload()
    payload["metadata_keys_read"] = ["UMASK", "USERGROUPS_ENAB", "PASS_MAX_DAYS"]
    assert _run(payload)[0] == ChangeStatus.FAIL


def test_alpha53_acceptance_runner_has_dedicated_gate():
    text = (Path(__file__).parents[1] / "chromapress_acceptance.py").read_text(encoding="utf-8")
    assert "P4-ALPHA53-SECURITY-DEFAULTS" in text
    assert "_add_alpha53_security_defaults_gate" in text
    assert "system_security_defaults_evidence" in text


def test_alpha53_acceptance_gate_executes_supported_and_unknown(tmp_path):
    import sys
    root = Path(__file__).parents[1]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    from chromapress_acceptance import AcceptanceRunner, PASS

    runner = AcceptanceRunner(root, 4, None, None, tmp_path)
    supported = _system_security_defaults_evidence(_identity())
    runner._add_alpha53_security_defaults_gate(supported, "a" * 64)
    assert runner.checks[-1].status == PASS

    unknown = _system_security_defaults_evidence(_identity(login_defs=False))
    runner._add_alpha53_security_defaults_gate(unknown, "a" * 64)
    assert runner.checks[-1].status == PASS
    assert "fail-closed" in runner.checks[-1].detail


def test_alpha53_version_markers():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
