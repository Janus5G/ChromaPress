from pathlib import Path
import json

from chromapress.models import ProjectState, ChangeItem, ChangeKind
from chromapress.services.paths import windows_to_wsl
from chromapress.services.preflight import test_change as preflight_change


def test_windows_to_wsl():
    assert windows_to_wsl(r"E:\ISO Files\test.iso") == "/mnt/e/ISO Files/test.iso"


def test_project_never_serializes_api_key(tmp_path):
    p = ProjectState()
    p.changes.append(ChangeItem("AI app", ChangeKind.AI_APP, "test", {"code": "print(1)", "prompt": "x"}))
    target = tmp_path / "x.chromapress"
    p.save(target)
    text = target.read_text()
    assert "api_key" not in text.lower()


def test_direct_url_preflight():
    c = ChangeItem("URL", ChangeKind.DIRECT_URL, "", {"url": "https://example.com/app.deb"})
    status, _ = preflight_change(c)
    assert status.value == "PASS"


def test_local_file_preflight(tmp_path):
    f = tmp_path / "app.deb"; f.write_bytes(b"x")
    c = ChangeItem("local", ChangeKind.LOCAL_PACKAGE, str(f), {"path": str(f)})
    status, _ = preflight_change(c)
    assert status.value == "PASS"


def test_ai_catalog_defaults_to_openai_sol():
    from chromapress.services.ai_catalog import provider_by_id, normalized_model_id
    provider = provider_by_id("openai")
    assert provider.label == "OpenAI"
    assert normalized_model_id("openai", "") == "gpt-5.6-sol"


def test_old_alpha_ai_value_migrates_to_real_model():
    from chromapress.services.ai_catalog import normalize_provider_id, normalized_model_id
    provider = normalize_provider_id("OpenAI-compatible")
    assert provider == "openai"
    assert normalized_model_id(provider, "Openai") == "gpt-5.6-sol"


def test_package_remove_preflight():
    from chromapress.models import ChangeStatus
    c = ChangeItem("Remove VLC", ChangeKind.PACKAGE_REMOVE, "", {"package": "vlc"})
    status, _ = preflight_change(c)
    assert status == ChangeStatus.PASS


def test_rootfs_layer_order():
    from chromapress.engine_cli import _rootfs_layers
    files = [
        "/casper/minimal.standard.live.squashfs",
        "/casper/minimal.standard.squashfs",
        "/casper/minimal.squashfs",
    ]
    assert _rootfs_layers(files) == [
        "/casper/minimal.squashfs",
        "/casper/minimal.standard.squashfs",
        "/casper/minimal.standard.live.squashfs",
    ]


def test_desktop_entry_hides_nodisplay(tmp_path):
    from chromapress.engine_cli import _desktop_fields
    desktop = tmp_path / "x.desktop"
    desktop.write_text("[Desktop Entry]\nType=Application\nName=Test App\nComment=Hello\nNoDisplay=true\n")
    fields = _desktop_fields(desktop)
    assert fields["Name"] == "Test App"
    assert fields["NoDisplay"] == "true"


def test_project_persists_system_scenario(tmp_path):
    p = ProjectState(scenario="production")
    target = tmp_path / "scenario.chromapress"
    p.save(target)
    loaded = ProjectState.load(target)
    assert loaded.scenario == "production"


def test_scenario_relevance_prioritises_development_app():
    from chromapress.scenarios import relevance_score
    app = {
        "application": "Example IDE",
        "description": "Editor and debugger for software development",
        "package": "example-ide",
        "categories": ["Development", "IDE"],
    }
    assert relevance_score(app, "development") > relevance_score(app, "personal")


def test_custom_scenario_keeps_every_application_visible():
    from chromapress.scenarios import relevance_score
    assert relevance_score({"application": "Unknown Tool", "categories": []}, "custom") > 0


def test_home_scenario_balances_office_internet_and_games():
    from chromapress.scenarios import relevance_score
    office = {"application": "Writer", "description": "Office document editor", "package": "writer", "categories": ["Office"]}
    browser = {"application": "Browser", "description": "Internet browser", "package": "browser", "categories": ["Network", "WebBrowser"]}
    game = {"application": "Chess", "description": "Board game", "package": "chess", "categories": ["Game"]}
    assert relevance_score(office, "personal") > 0
    assert relevance_score(browser, "personal") > 0
    assert relevance_score(game, "personal") > 0


def test_catalog_cache_path_is_small_metadata_location(tmp_path):
    from chromapress.engine_cli import _catalog_cache_path
    p = _catalog_cache_path(tmp_path, "abc123")
    assert p == tmp_path / "catalog" / "abc123.json"


def test_application_sections_are_human_facing():
    from chromapress.scenarios import application_section
    assert application_section({"application": "LibreOffice Writer", "categories": ["Office"]}) == "Office & Documents"
    assert application_section({"application": "Firefox", "categories": ["Network", "WebBrowser"]}) == "Internet & Communication"
    assert application_section({"application": "Chess", "categories": ["Game"]}) == "Games"


def test_libreoffice_is_grouped_as_suite():
    from chromapress.scenarios import suite_group
    assert suite_group({"application": "LibreOffice Writer", "package": "libreoffice-writer"}) == "LibreOffice"
    assert suite_group({"application": "Firefox", "package": "firefox"}) == ""


def test_home_section_order_starts_with_everyday_categories():
    from chromapress.scenarios import section_order_for_scenario
    order = section_order_for_scenario("personal")
    assert order[:3] == ("Internet & Communication", "Office & Documents", "Games")


def test_home_personal_separates_everyday_and_specialist_apps():
    from chromapress.scenarios import personal_home_group
    browser = {"application": "Firefox", "categories": ["Network", "WebBrowser"]}
    writer = {"application": "AbiWord", "package": "abiword", "categories": ["Office", "WordProcessor"]}
    torrent = {"application": "Transmission", "categories": ["Network"], "description": "BitTorrent client"}
    audacity = {"application": "Audacity", "categories": ["AudioVideo"], "description": "Audio editor"}
    ide = {"application": "Example IDE", "categories": ["Development", "IDE"]}
    assert personal_home_group(browser) == ("Everyday essentials", "Internet, browser & email")
    assert personal_home_group(writer) == ("Everyday essentials", "Writing & office")
    assert personal_home_group(torrent) == ("Specialised / Advanced", "Torrent & file sharing")
    assert personal_home_group(audacity) == ("Specialised / Advanced", "Advanced audio & video editing")
    assert personal_home_group(ide) == ("Specialised / Advanced", "Programming & web development")


def test_home_personal_hides_generic_system_noise_from_quick_view():
    from chromapress.scenarios import personal_home_group
    generic = {"application": "Theme Manager", "categories": ["Utility"]}
    assert personal_home_group(generic) == ("", "")


def test_home_recommendations_are_limited_to_validated_ubuntu_2604_targets():
    from chromapress.scenarios import home_recommendations_supported
    assert home_recommendations_supported({"distribution": "Lubuntu", "version": "26.04.1"})
    assert home_recommendations_supported({"distribution": "Ubuntu", "version": "26.04"})
    assert not home_recommendations_supported({"distribution": "Debian", "version": "13"})
    assert not home_recommendations_supported({"distribution": "Ubuntu", "version": "24.04"})


def test_home_recommendation_catalog_uses_locked_lightweight_defaults():
    from chromapress.scenarios import HOME_RECOMMENDATIONS
    packages = {item.role: item.package for item in HOME_RECOMMENDATIONS}
    assert packages == {
        "browser": "falkon",
        "email": "evolution",
        "writing": "abiword",
        "image_editing": "kolourpaint",
        "video": "haruna",
        "music": "audacious",
        "ebooks": "foliate",
        "podcasts": "gpodder",
        "games": "aisleriot",
        "file_manager": "pcmanfm-qt",
    }


def test_home_recommendations_only_fill_missing_roles():
    from chromapress.scenarios import missing_home_recommendations
    source = {"distribution": "Lubuntu", "version": "26.04.1"}
    apps = [
        {"application": "Firefox", "package": "firefox", "categories": ["Network", "WebBrowser"]},
        {"application": "AbiWord", "package": "abiword", "categories": ["Office", "WordProcessor"]},
    ]
    packages = {item.package for item in missing_home_recommendations(apps, source)}
    assert "falkon" not in packages
    assert "abiword" not in packages
    assert "evolution" in packages
    assert "kolourpaint" in packages


def test_staged_removal_makes_role_missing_but_does_not_recommend_same_removed_package():
    from chromapress.scenarios import missing_home_recommendations
    source = {"distribution": "Lubuntu", "version": "26.04.1"}
    apps = [
        {"application": "Firefox", "package": "firefox", "categories": ["Network", "WebBrowser"]},
        {"application": "AbiWord", "package": "abiword", "categories": ["Office", "WordProcessor"]},
    ]
    packages = {item.package for item in missing_home_recommendations(apps, source, {"firefox", "abiword"})}
    assert "falkon" in packages
    assert "abiword" not in packages


def test_repository_recommendation_preflight_is_non_mutating_stage_gate():
    from chromapress.models import ChangeStatus
    c = ChangeItem(
        "Add AbiWord", ChangeKind.PACKAGE_REPOSITORY,
        "Home / Personal recommendation", {"package": "abiword", "recommended": True}
    )
    status, message = preflight_change(c)
    assert status == ChangeStatus.PASS
    assert "resolution" in message.lower()


def test_home_personal_moves_libreoffice_to_advanced_suite_group():
    from chromapress.scenarios import personal_home_group
    writer = {
        "application": "LibreOffice Writer",
        "package": "libreoffice-writer",
        "categories": ["Office", "WordProcessor"],
    }
    assert personal_home_group(writer) == ("Specialised / Advanced", "Full office suites")


def test_home_personal_libreoffice_does_not_suppress_abiword_recommendation():
    from chromapress.scenarios import missing_home_recommendations
    source = {"distribution": "Lubuntu", "version": "26.04.1"}
    apps = [
        {
            "application": "LibreOffice Writer",
            "package": "libreoffice-writer",
            "categories": ["Office", "WordProcessor"],
        }
    ]
    packages = {item.package for item in missing_home_recommendations(apps, source)}
    assert "abiword" in packages


def test_home_everyday_and_specialist_subgroups_are_disjoint():
    from chromapress.scenarios import HOME_EVERYDAY_SUBGROUPS, HOME_SPECIALIST_SUBGROUPS
    assert set(HOME_EVERYDAY_SUBGROUPS).isdisjoint(HOME_SPECIALIST_SUBGROUPS)
    assert "Torrent & file sharing" not in HOME_EVERYDAY_SUBGROUPS
    assert "Programming & web development" not in HOME_EVERYDAY_SUBGROUPS
    assert "Full office suites" in HOME_SPECIALIST_SUBGROUPS


def test_alpha13_recommendation_action_row_contains_skip_and_add_controls():
    # Static regression guard for the exact GUI omission found on-machine:
    # the buttons existed but were never inserted into the recommendation row.
    source = (Path(__file__).parents[1] / "src" / "chromapress" / "gui" / "applications_page.py").read_text()
    assert "row.addWidget(skip)" in source
    assert "row.addWidget(add)" in source


def test_alpha13_preserves_tree_expansion_across_staged_changes():
    # Qt itself is exercised on the user's Windows venv; this focused source guard
    # prevents a later refactor from dropping the expansion-state restore path.
    source = (Path(__file__).parents[1] / "src" / "chromapress" / "gui" / "applications_page.py").read_text()
    assert "_expanded_tree_paths" in source
    assert "_restore_expanded_tree_paths(expanded_paths)" in source


def test_alpha15_business_recommends_abiword_and_notepadplusplus():
    from chromapress.scenarios import missing_scenario_recommendations
    source = {"distribution": "Lubuntu", "version": "26.04.1"}
    recs = missing_scenario_recommendations([], source, "business")
    packages = {item.package for item in recs}
    assert packages == {"abiword", "notepadplusplus"}
    assert next(item for item in recs if item.package == "notepadplusplus").manager == "snap"


def test_alpha15_development_recommends_refract_notepad_and_abiword():
    from chromapress.scenarios import missing_scenario_recommendations
    source = {"distribution": "Lubuntu", "version": "26.04.1"}
    recs = missing_scenario_recommendations([], source, "development")
    packages = {item.package for item in recs}
    assert packages == {"refract-studio", "notepadplusplus", "abiword"}
    refract = next(item for item in recs if item.package == "refract-studio")
    assert refract.manager == "bundled"
    assert refract.bundle_relpath.endswith("refract-studio_0.1.0-1_all.deb")


def test_alpha15_production_recommends_refract_studio():
    from chromapress.scenarios import missing_scenario_recommendations
    source = {"distribution": "Lubuntu", "version": "26.04.1"}
    recs = missing_scenario_recommendations([], source, "production")
    assert [item.package for item in recs] == ["refract-studio"]


def test_alpha15_gaming_team_recommends_measurement_stack():
    from chromapress.scenarios import missing_scenario_recommendations
    source = {"distribution": "Lubuntu", "version": "26.04.1"}
    packages = {item.package for item in missing_scenario_recommendations([], source, "gaming_team")}
    assert packages == {"mangohud", "nvtop", "speedtest-cli", "glmark2-x11"}


def test_alpha15_scenario_recommendations_suppress_installed_exact_apps():
    from chromapress.scenarios import missing_scenario_recommendations
    source = {"distribution": "Lubuntu", "version": "26.04.1"}
    apps = [
        {"application": "AbiWord", "package": "abiword", "description": "Word processor"},
        {"application": "Notepad++ Linux", "package": "notepadplusplus", "description": "Text editor"},
        {"application": "Refract Studio", "package": "refract-studio", "description": "Engineering IDE"},
    ]
    assert missing_scenario_recommendations(apps, source, "development") == ()


def test_alpha15_bundled_refract_sha256_matches_attached_source():
    from chromapress.scenarios import SCENARIO_RECOMMENDATIONS
    import hashlib
    rec = next(item for item in SCENARIO_RECOMMENDATIONS["development"] if item.package == "refract-studio")
    path = Path(__file__).parents[1] / rec.bundle_relpath
    assert path.is_file()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == rec.bundle_sha256


def test_alpha15_preflight_understands_snap_and_bundled_sources():
    from chromapress.models import ChangeStatus
    snap = ChangeItem(
        "Add Notepad++ Linux", ChangeKind.PACKAGE_REPOSITORY, "test",
        {"package": "notepadplusplus", "manager": "snap"},
    )
    status, message = preflight_change(snap)
    assert status == ChangeStatus.PASS
    assert "snap" in message.lower()

    from chromapress.scenarios import SCENARIO_RECOMMENDATIONS
    rec = next(item for item in SCENARIO_RECOMMENDATIONS["development"] if item.package == "refract-studio")
    path = Path(__file__).parents[1] / rec.bundle_relpath
    bundled = ChangeItem(
        "Add Refract Studio", ChangeKind.PACKAGE_REPOSITORY, "test",
        {"package": rec.package, "manager": "bundled", "path": str(path), "sha256": rec.bundle_sha256},
    )
    status, message = preflight_change(bundled)
    assert status == ChangeStatus.PASS
    assert "integrity" in message.lower()


def test_current_version_markers_are_consistent():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text()
    assert '__version__ = "1.0.0a72"' in (root / "src" / "chromapress" / "__init__.py").read_text()
    main_window = (root / "src" / "chromapress" / "gui" / "main_window.py").read_text()
    assert 'from chromapress import __version__' in main_window
    assert 'QLabel(__version__)' in main_window


def test_alpha16_unresolved_launcher_removal_has_fail_closed_locator():
    from chromapress.models import ChangeStatus
    change = ChangeItem(
        "Remove ScreenGrab",
        ChangeKind.PACKAGE_REMOVE,
        "test",
        {
            "application": "ScreenGrab",
            "package": "",
            "desktop_file": "/usr/share/applications/screengrab.desktop",
            "target_ref": "desktop:/usr/share/applications/screengrab.desktop",
        },
    )
    status, message = preflight_change(change)
    assert status == ChangeStatus.PASS
    assert "ownership" in message.lower() and "fail-closed" in message.lower()


def test_alpha16_replace_preflight_is_atomic_stage_gate():
    from chromapress.models import ChangeStatus
    change = ChangeItem(
        "Replace ScreenGrab with flameshot",
        ChangeKind.PACKAGE_REPLACE,
        "test",
        {
            "application": "ScreenGrab",
            "package": "",
            "desktop_file": "/usr/share/applications/screengrab.desktop",
            "target_ref": "desktop:/usr/share/applications/screengrab.desktop",
            "replacement_package": "flameshot",
        },
    )
    status, message = preflight_change(change)
    assert status == ChangeStatus.PASS
    assert "replacement" in message.lower() and "before any apply" in message.lower()


def test_alpha17_gaming_repository_components_are_explicit():
    from chromapress.scenarios import SCENARIO_RECOMMENDATIONS
    recs = {item.package: item for item in SCENARIO_RECOMMENDATIONS["gaming_team"]}
    assert recs["mangohud"].repository_component == "universe"
    assert recs["nvtop"].repository_component == "multiverse"
    assert recs["speedtest-cli"].repository_component == "universe"
    assert recs["glmark2-x11"].repository_component == "universe"


def test_alpha24_school_profile_uses_reviewed_chromalearn_045_with_evaluation_pack():
    from chromapress.scenarios import SCENARIOS, SCENARIO_RECOMMENDATIONS, application_section
    labels = {item.id: item.label for item in SCENARIOS}
    assert labels["education"] == "School / Education"
    assert labels["gaming_team"] == "Gaming / Team"
    rec = next(item for item in SCENARIO_RECOMMENDATIONS["education"] if item.package == "chromalearn")
    assert rec.manager == "bundled"
    assert rec.bundle_relpath == "bundled_apps/chromalearn_0.4.5_all.deb"
    assert rec.bundle_sha256 == "024374666992d83df7ae6c9b0f488973e896beec80aeff18c997336d7dbe9fbc"
    root = Path(__file__).parents[1]
    path = root / rec.bundle_relpath
    assert path.exists()
    import hashlib
    assert hashlib.sha256(path.read_bytes()).hexdigest() == rec.bundle_sha256
    assert rec.documentation_label == "School Evaluation Pack v1.2.1 DA"
    assert rec.documentation_relpath == "bundled_docs/ChromaLearn_Skoleevalueringspakke_v1.2.1_DA.zip"
    assert rec.documentation_sha256 == "9fec49879412c056991e123c06d89b3ce99f64eff3ca19718891333fca6e67eb"
    documentation = root / rec.documentation_relpath
    assert documentation.exists()
    assert hashlib.sha256(documentation.read_bytes()).hexdigest() == rec.documentation_sha256
    assert not (root / "bundled_apps/chromalearn_0.3.0_all.deb").exists()
    assert not (root / "bundled_apps/chromalearn_0.4.0_all.deb").exists()
    assert not (root / "bundled_apps/chromalearn_0.4.4_all.deb").exists()
    assert application_section({"application": "Example Tutor", "categories": ["Education"]}) == "Education & Learning"


def test_alpha24_chromalearn_bundled_preflight_passes_integrity():
    from chromapress.scenarios import SCENARIO_RECOMMENDATIONS
    from chromapress.models import ChangeStatus
    rec = next(item for item in SCENARIO_RECOMMENDATIONS["education"] if item.package == "chromalearn")
    path = Path(__file__).parents[1] / rec.bundle_relpath
    bundled = ChangeItem(
        "Add ChromaLearn AI", ChangeKind.PACKAGE_REPOSITORY, "test",
        {
            "package": rec.package, "manager": "bundled", "path": str(path), "sha256": rec.bundle_sha256,
            "documentation_path": str(Path(__file__).parents[1] / rec.documentation_relpath),
            "documentation_sha256": rec.documentation_sha256,
        },
    )
    status, message = preflight_change(bundled)
    assert status == ChangeStatus.PASS
    assert "documentation" in message.lower()
    assert "integrity" in message.lower()


def test_alpha24_chromalearn_preflight_fails_closed_on_documentation_hash_mismatch(tmp_path):
    from chromapress.scenarios import SCENARIO_RECOMMENDATIONS
    from chromapress.models import ChangeStatus
    rec = next(item for item in SCENARIO_RECOMMENDATIONS["education"] if item.package == "chromalearn")
    root = Path(__file__).parents[1]
    tampered = tmp_path / "evaluation-pack.zip"
    tampered.write_bytes((root / rec.documentation_relpath).read_bytes() + b"tamper")
    change = ChangeItem(
        "Add ChromaLearn AI", ChangeKind.PACKAGE_REPOSITORY, "test",
        {
            "package": rec.package, "manager": "bundled",
            "path": str(root / rec.bundle_relpath), "sha256": rec.bundle_sha256,
            "documentation_path": str(tampered),
            "documentation_sha256": rec.documentation_sha256,
        },
    )
    status, message = preflight_change(change)
    assert status == ChangeStatus.FAIL
    assert "documentation" in message.lower() and "sha-256" in message.lower()
