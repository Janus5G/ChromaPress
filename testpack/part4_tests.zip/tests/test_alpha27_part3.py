from __future__ import annotations

from pathlib import Path

from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as preflight_change


def _boot_plan(**overrides):
    payload = {
        "config_type": "boot",
        "source_sha256": "a" * 64,
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "default_entry": {"title": "Try Lubuntu", "source": "/boot/grub/grub.cfg", "id": ""},
        "timeout_seconds": 5,
        "kernel_args_append": "nomodeset",
        "preservation_policy": "preserve-unrelated",
        "stage_only": True,
    }
    payload.update(overrides)
    return ChangeItem("Boot configuration plan", ChangeKind.CONFIG, "test", payload)


def test_alpha27_boot_plan_preflight_is_source_locked_and_stage_only():
    status, message = preflight_change(_boot_plan())
    assert status == ChangeStatus.PASS
    assert "source-hash locked" in message
    assert "staging-only" in message


def test_alpha27_boot_plan_rejects_missing_source_hash():
    status, _ = preflight_change(_boot_plan(source_sha256=""))
    assert status == ChangeStatus.FAIL


def test_alpha27_boot_plan_rejects_unsafe_kernel_argument_control_characters():
    status, _ = preflight_change(_boot_plan(kernel_args_append="quiet\nmenuentry evil"))
    assert status == ChangeStatus.FAIL


def test_alpha27_boot_plan_rejects_empty_plan():
    status, _ = preflight_change(_boot_plan(default_entry=None, timeout_seconds=None, kernel_args_append=""))
    assert status == ChangeStatus.FAIL


def test_alpha27_staging_markers_remain_present_in_later_alphas():
    root = Path(__file__).parents[1]
    page = (root / "src/chromapress/gui/boot_hardware_page.py").read_text(encoding="utf-8")
    assert "SOURCE READ-ONLY" in page
    assert "Boot configuration plan — staged only" in page
