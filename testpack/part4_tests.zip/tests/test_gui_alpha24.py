from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.applications_page import ApplicationsPage
from chromapress.settings import AppSettings


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _page(qapp, scenario: str) -> ApplicationsPage:
    page = ApplicationsPage(AppSettings())
    page._source = {"distribution": "Lubuntu", "version": "26.04.1", "path": "test.iso"}
    page._catalog = [{"application":"About LXQt","package":"lxqt-about","description":"About LXQt","categories":["System"]}]
    page._catalog_loaded = True
    page.set_scenario(scenario)
    return page


def _walk(item):
    yield item
    for i in range(item.childCount()):
        yield from _walk(item.child(i))


def _all_items(page):
    for i in range(page.tree.topLevelItemCount()):
        yield from _walk(page.tree.topLevelItem(i))


def test_school_profile_links_evaluation_pack_under_chromalearn(qapp):
    page = _page(qapp, "education")
    chromalearn = next(item for item in _all_items(page) if item.text(0) == "Recommended: ChromaLearn AI")
    assert chromalearn.isExpanded()
    docs = [chromalearn.child(i) for i in range(chromalearn.childCount())]
    assert len(docs) == 1
    assert docs[0].text(0) == "School Evaluation Pack v1.2.1 DA"
    assert docs[0].text(3) == ""
    assert docs[0].text(4) == "Included automatically"
    assert "not a compliance certificate" in docs[0].text(2).lower()
    assert docs[0].icon(0).cacheKey() == chromalearn.icon(0).cacheKey()
    assert page.tree.itemWidget(docs[0], 4) is None


def test_chromalearn_stage_payload_carries_evaluation_pack(qapp):
    page = _page(qapp, "education")
    rec = next(r for r in __import__("chromapress.scenarios", fromlist=["SCENARIO_RECOMMENDATIONS"]).SCENARIO_RECOMMENDATIONS["education"] if r.package == "chromalearn")
    captured = []
    page.change_requested.connect(captured.append)
    page._stage_recommendation(rec)
    assert len(captured) == 1
    payload = captured[0].payload
    assert payload["bundle_relpath"] == "bundled_apps/chromalearn_0.4.5_all.deb"
    assert payload["sha256"] == "024374666992d83df7ae6c9b0f488973e896beec80aeff18c997336d7dbe9fbc"
    assert payload["documentation_relpath"] == "bundled_docs/ChromaLearn_Skoleevalueringspakke_v1.2.1_DA.zip"
    assert payload["documentation_sha256"] == "9fec49879412c056991e123c06d89b3ce99f64eff3ca19718891333fca6e67eb"
