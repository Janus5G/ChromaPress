from __future__ import annotations

from pathlib import Path

from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as preflight_change


def _metadata_plan(**overrides):
    payload = {
        "config_type": "boot_metadata",
        "source_sha256": "a" * 64,
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "boot_entries": [
            {"title": "Try or Install Lubuntu", "source": "/boot/grub/grub.cfg", "id": "try"},
            {"title": "Lubuntu (safe graphics)", "source": "/boot/grub/grub.cfg", "id": "safe"},
        ],
        "selected_entry": {"title": "Try or Install Lubuntu", "source": "/boot/grub/grub.cfg", "id": "try"},
        "entry_label_new": "Try Lubuntu",
        "boot_order_operation": "move_selected_first",
        "volume_id_current": "Lubuntu 26.04 amd64",
        "volume_id_new": "LUBUNTU_TEST",
        "boot_catalog": "/boot.catalog",
        "el_torito_detected": True,
        "hybrid_detected": True,
        "preserve_boot_records": True,
        "preserve_unselected_entries": True,
        "require_boot_catalog_reverification": True,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }
    payload.update(overrides)
    return ChangeItem("Boot identity / metadata plan", ChangeKind.CONFIG, "test", payload)


def test_alpha34_boot_metadata_plan_is_evidence_bound_and_stage_only():
    status, message = preflight_change(_metadata_plan())
    assert status == ChangeStatus.PASS
    assert "source-hash locked" in message
    assert "explicit-entry bound" in message
    assert "boot-record preserving" in message
    assert "staging-only" in message


def test_alpha34_volume_id_only_plan_is_allowed():
    status, _ = preflight_change(_metadata_plan(
        selected_entry=None,
        entry_label_new="",
        boot_order_operation="preserve",
        volume_id_new="LUBUNTU_TEST",
    ))
    assert status == ChangeStatus.PASS


def test_alpha34_rejects_unbound_entry_and_unsafe_metadata():
    assert preflight_change(_metadata_plan(selected_entry={"title": "Invented", "source": "/boot/grub/grub.cfg"}))[0] == ChangeStatus.FAIL
    assert preflight_change(_metadata_plan(entry_label_new="bad\nlabel"))[0] == ChangeStatus.FAIL
    assert preflight_change(_metadata_plan(volume_id_new="x" * 33))[0] == ChangeStatus.FAIL
    assert preflight_change(_metadata_plan(boot_order_operation="replace_all"))[0] == ChangeStatus.FAIL


def test_alpha34_rejects_empty_or_weakened_metadata_plan():
    assert preflight_change(_metadata_plan(
        selected_entry=None,
        entry_label_new="",
        boot_order_operation="preserve",
        volume_id_new="",
    ))[0] == ChangeStatus.FAIL
    assert preflight_change(_metadata_plan(preserve_boot_records=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_metadata_plan(preserve_unselected_entries=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_metadata_plan(require_boot_catalog_reverification=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_metadata_plan(source_read_only=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_metadata_plan(stage_only=False))[0] == ChangeStatus.FAIL


def test_alpha34_version_markers_are_consistent():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
    main_window = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert 'from chromapress import __version__' in main_window
    assert 'QLabel(__version__)' in main_window
