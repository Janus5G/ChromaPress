from pathlib import Path

import pytest

from chromapress.engine_cli import _system_firewall_rules_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight
from chromapress_acceptance import AcceptanceRunner


def _firewall(backend="ufw", verified=True):
    return {
        "verified": verified,
        "backend": backend,
        "backend_path": "/usr/sbin/ufw" if backend == "ufw" else "/usr/sbin/firewalld",
        "backend_layer": "/casper/minimal.squashfs",
    }


def _supported(backend="ufw"):
    adapter = "ufw-additive-cli" if backend == "ufw" else "firewalld-permanent-cli"
    command = "/usr/sbin/ufw" if backend == "ufw" else "/usr/bin/firewall-cmd"
    return {
        "gate_version": "alpha60", "analysis_scope": "target_iso_rootfs",
        "capability_status": "SUPPORTED_WITH_REQUIREMENTS", "verified": True,
        "firewall_backend": backend, "backend_evidence_path": _firewall(backend)["backend_path"],
        "backend_evidence_layer": "/casper/minimal.squashfs", "rule_adapter": adapter,
        "rule_command_path": command, "rule_command_layer": "/casper/minimal.squashfs",
        "supported_operations": ["deny_inbound_tcp_port"], "rule_scope": "single_inbound_tcp_port_deny",
        "existing_rule_contents_read": False, "ports_services_policy_read": False,
        "application_profiles_read": False, "firewall_secrets_read": False, "host_firewall_accessed": False,
        "requires_apply_time_conflict_check": True, "requires_backend_state_reverification": True,
        "preserve_existing_rules": True, "source_read_only": True, "reason": "PASS",
    }


def _payload(e=None, cap=None):
    e = dict(e or _supported())
    if cap is not None:
        e["capability_status"] = cap
        e["verified"] = cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "config_type": "firewall_rule", "gate_version": "alpha60", "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_rootfs", "capability_status": e["capability_status"],
        "rootfs_firewall_rules_verified": e["verified"], "operation": "deny_inbound_tcp_port",
        "firewall_backend": e.get("firewall_backend", ""), "backend_evidence_path": e.get("backend_evidence_path", ""),
        "backend_evidence_layer": e.get("backend_evidence_layer", ""), "rule_adapter": e.get("rule_adapter", ""),
        "rule_command_path": e.get("rule_command_path", ""), "rule_command_layer": e.get("rule_command_layer", ""),
        "tcp_port": 65060, "protocol": "tcp", "direction": "in", "action": "deny",
        "rule_scope": "single_inbound_tcp_port_deny", "existing_rule_contents_read": False,
        "ports_services_policy_read": False, "application_profiles_read": False,
        "firewall_secrets_read": False, "host_firewall_accessed": False,
        "preserve_existing_rules": True, "preserve_default_policy": True,
        "preserve_unrelated_firewall_policy": True, "requires_apply_time_conflict_check": True,
        "requires_backend_state_reverification": True, "require_rule_command_reverification_before_apply": True,
        "source_read_only": True, "preserve_unrelated": True, "stage_only": True,
    }


def _run(p):
    return run_preflight(ChangeItem("Firewall rules plan", ChangeKind.CONFIG, "test", p))


def test_alpha60_detects_verified_ufw_additive_adapter(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"alpha60")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/casper/minimal.squashfs": (1, 2)})
    def presence(_iso, _layers, member, _ext):
        return (member == "/usr/sbin/ufw", "/casper/minimal.squashfs" if member == "/usr/sbin/ufw" else "")
    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", presence)
    e = _system_firewall_rules_evidence(iso, ["/casper/minimal.squashfs"], _firewall())
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert e["verified"] is True and e["rule_adapter"] == "ufw-additive-cli"
    assert e["existing_rule_contents_read"] is False and e["host_firewall_accessed"] is False


def test_alpha60_detects_verified_firewalld_additive_adapter(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"alpha60")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/x.squashfs": (1, 2)})
    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", lambda _i, _l, member, _e: (member == "/usr/bin/firewall-cmd", "/x.squashfs" if member == "/usr/bin/firewall-cmd" else ""))
    fw = _firewall("firewalld"); fw["backend_layer"] = "/x.squashfs"
    e = _system_firewall_rules_evidence(iso, ["/x.squashfs"], fw)
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert e["rule_adapter"] == "firewalld-permanent-cli"


def test_alpha60_nftables_remains_unknown_without_safe_persistent_adapter(tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"x")
    fw = _firewall("nftables"); fw["backend_path"] = "/usr/sbin/nft"
    e = _system_firewall_rules_evidence(iso, ["/casper/minimal.squashfs"], fw)
    assert e["capability_status"] == "UNKNOWN" and e["verified"] is False


def test_alpha60_missing_rule_command_is_unknown_not_unsupported(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"x")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/x.squashfs": (1, 2)})
    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", lambda *_: (False, ""))
    fw = _firewall(); fw["backend_layer"] = "/x.squashfs"
    e = _system_firewall_rules_evidence(iso, ["/x.squashfs"], fw)
    assert e["capability_status"] == "UNKNOWN"


def test_alpha60_supported_preflight_passes():
    status, msg = _run(_payload())
    assert status == ChangeStatus.PASS
    assert "single-port scoped" in msg


@pytest.mark.parametrize("cap", ["UNKNOWN", "BLOCKED", "UNSUPPORTED"])
def test_alpha60_unverified_capability_fails_closed(cap):
    assert _run(_payload(cap=cap))[0] == ChangeStatus.FAIL


@pytest.mark.parametrize("field,value", [
    ("tcp_port", 0), ("tcp_port", 65536), ("protocol", "udp"), ("direction", "out"),
    ("action", "allow"), ("rule_scope", "all_traffic"),
])
def test_alpha60_rejects_broader_or_invalid_rule(field, value):
    p = _payload(); p[field] = value
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha60_rejects_rule_or_host_state_reads():
    for key in ("existing_rule_contents_read", "ports_services_policy_read", "application_profiles_read", "firewall_secrets_read", "host_firewall_accessed"):
        p = _payload(); p[key] = True
        assert _run(p)[0] == ChangeStatus.FAIL, key


def test_alpha60_requires_preservation_and_apply_reverification():
    for key in (
        "preserve_existing_rules", "preserve_default_policy", "preserve_unrelated_firewall_policy",
        "requires_apply_time_conflict_check", "requires_backend_state_reverification",
        "require_rule_command_reverification_before_apply", "source_read_only", "preserve_unrelated", "stage_only",
    ):
        p = _payload(); p[key] = False
        assert _run(p)[0] == ChangeStatus.FAIL, key


def test_alpha60_acceptance_supported_and_unknown(tmp_path):
    runner = AcceptanceRunner(tmp_path, 4, None, None, tmp_path / "reports")
    runner._add_alpha60_firewall_rules_gate(_supported(), "a" * 64)
    assert runner.checks[-1].status == "PASS"
    e = _supported(); e.update({"capability_status": "UNKNOWN", "verified": False, "rule_adapter": "", "rule_command_path": ""})
    runner._add_alpha60_firewall_rules_gate(e, "a" * 64)
    assert runner.checks[-1].status == "PASS"


def test_alpha60_version_markers():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
