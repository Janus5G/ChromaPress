from __future__ import annotations

import hashlib
from pathlib import Path

from chromapress.engine_cli import _system_network_dns_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _evidence() -> dict:
    return {
        "gate_version": "alpha51",
        "analysis_scope": "target_iso_rootfs",
        "verified": True,
        "capability_status": "SUPPORTED_WITH_REQUIREMENTS",
        "addressing_status": "SUPPORTED_WITH_REQUIREMENTS",
        "dns_status": "SUPPORTED_WITH_REQUIREMENTS",
        "networkmanager_profile_status": "SUPPORTED_WITH_REQUIREMENTS",
        "ipv6_status": "BLOCKED",
        "ipv6_exposed": False,
        "backend": "NetworkManager",
        "backend_config_path": "/etc/NetworkManager/NetworkManager.conf",
        "backend_config_layer": "/casper/minimal.squashfs",
        "managed_config_path": "/etc/NetworkManager/system-connections/90-chromapress.nmconnection",
        "managed_config_style": "networkmanager-keyfile",
        "resolver_path": "/etc/resolv.conf",
        "resolver_layer": "/casper/minimal.squashfs",
        "supported_operations": [
            "configure_dns_servers",
            "configure_dhcp_ipv4",
            "configure_static_ipv4",
            "create_networkmanager_profile",
            "set_networkmanager_autoconnect",
        ],
        "networkmanager_profile_directory": "/etc/NetworkManager/system-connections",
        "networkmanager_profile_directory_layer": "/casper/minimal.squashfs",
        "networkmanager_profile_names": ["wired.nmconnection"],
        "connection_profiles_inspected": False,
        "connection_profile_contents_read": False,
        "profile_names_from_metadata_only": True,
        "wifi_vpn_secrets_read": False,
        "credential_secret_read": False,
        "host_network_accessed": False,
        "source_read_only": True,
    }


def _payload(operation: str = "configure_dhcp_ipv4") -> dict:
    e = _evidence()
    return {
        "config_type": "system_network_dns",
        "gate_version": "alpha51",
        "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_rootfs",
        "capability_status": e["capability_status"],
        "addressing_status": e["addressing_status"],
        "dns_status": e["dns_status"],
        "networkmanager_profile_status": e["networkmanager_profile_status"],
        "control_depth": "advanced",
        "operation": operation,
        "network_backend": e["backend"],
        "backend_config_path": e["backend_config_path"],
        "backend_config_layer": e["backend_config_layer"],
        "managed_config_path": e["managed_config_path"],
        "managed_config_style": e["managed_config_style"],
        "resolver_path": e["resolver_path"],
        "resolver_layer": e["resolver_layer"],
        "rootfs_network_dns_verified": True,
        "supported_operations": e["supported_operations"],
        "target_profile_name": "ChromaPress Ethernet",
        "existing_profile_filename": "",
        "target_interface": "enp1s0",
        "ipv4_method": "auto",
        "target_ipv4_address": "",
        "target_gateway": "",
        "target_dns_servers": [],
        "autoconnect_enabled": None,
        "profile_connection_type": "preserve",
        "require_backend_specific_apply_verification": True,
        "require_target_path_reverification_before_apply": True,
        "require_syntax_validation_before_apply": True,
        "require_profile_reverification_before_apply": False,
        "preserve_existing_profiles": True,
        "preserve_unrelated_routes": True,
        "preserve_hostname": True,
        "connection_profiles_inspected": False,
        "connection_profile_contents_read": False,
        "profile_names_from_metadata_only": True,
        "wifi_vpn_secrets_read": False,
        "credential_secret_read": False,
        "credential_secret_staged": False,
        "secret_read": False,
        "secret_staged": False,
        "host_network_accessed": False,
        "ipv6_exposed": False,
        "ipv6_supported_by_gate": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def _run(payload: dict):
    return run_preflight(ChangeItem("Networking / NetworkManager / DNS plan", ChangeKind.CONFIG, "test", payload))


def test_alpha51_detection_is_target_iso_only_and_source_read_only(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"alpha51-source-bytes")
    before = hashlib.sha256(iso.read_bytes()).hexdigest()
    layer = "/casper/minimal.squashfs"
    present = {
        "/etc/NetworkManager/NetworkManager.conf",
        "/etc/NetworkManager/system-connections",
        "/etc/resolv.conf",
    }
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: "/usr/bin/unsquashfs" if name == "unsquashfs" else None)
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layer: (4096, 100)})
    monkeypatch.setattr(
        "chromapress.engine_cli._inspect_overlay_member_presence",
        lambda _iso, _layers, member, _extents=None: (member in present, layer if member in present else ""),
    )
    monkeypatch.setattr(
        "chromapress.engine_cli._list_overlay_directory_entries",
        lambda *a, **k: (["wired.nmconnection", "notes.txt"], layer),
    )
    monkeypatch.setattr("chromapress.engine_cli._inspect_network_dns_from_readonly_mount", lambda *a, **k: {})
    evidence = _system_network_dns_rootfs_evidence(iso, [layer])
    after = hashlib.sha256(iso.read_bytes()).hexdigest()
    assert before == after
    assert evidence["gate_version"] == "alpha51"
    assert evidence["analysis_scope"] == "target_iso_rootfs"
    assert evidence["backend"] == "NetworkManager"
    assert evidence["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["addressing_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["dns_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["networkmanager_profile_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["networkmanager_profile_names"] == ["wired.nmconnection"]
    assert evidence["connection_profile_contents_read"] is False
    assert evidence["wifi_vpn_secrets_read"] is False
    assert evidence["host_network_accessed"] is False
    assert evidence["source_read_only"] is True


def test_alpha51_unknown_backend_is_truthful_and_fail_closed(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    layer = "/casper/minimal.squashfs"
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: "/usr/bin/unsquashfs" if name == "unsquashfs" else None)
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layer: (4096, 100)})
    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", lambda *a, **k: (False, ""))
    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", lambda *a, **k: ([], ""))
    monkeypatch.setattr("chromapress.engine_cli._inspect_network_dns_from_readonly_mount", lambda *a, **k: {})
    evidence = _system_network_dns_rootfs_evidence(iso, [layer])
    assert evidence["verified"] is False
    assert evidence["capability_status"] == "UNKNOWN"
    assert evidence["host_network_accessed"] is False


def test_alpha51_dhcp_staging_preflight_passes():
    status, message = _run(_payload("configure_dhcp_ipv4"))
    assert status == ChangeStatus.PASS
    assert "host-network isolated" in message


def test_alpha51_static_ipv4_gateway_staging_preflight_passes():
    payload = _payload("configure_static_ipv4")
    payload.update({
        "ipv4_method": "manual",
        "target_ipv4_address": "192.168.10.50/24",
        "target_gateway": "192.168.10.1",
        "target_dns_servers": ["1.1.1.1", "1.0.0.1"],
    })
    status, _ = _run(payload)
    assert status == ChangeStatus.PASS


def test_alpha51_dns_staging_preflight_passes():
    payload = _payload("configure_dns_servers")
    payload.update({"ipv4_method": "preserve", "target_dns_servers": ["1.1.1.1", "9.9.9.9"]})
    status, _ = _run(payload)
    assert status == ChangeStatus.PASS


def test_alpha51_networkmanager_profile_staging_passes():
    payload = _payload("create_networkmanager_profile")
    payload.update({
        "ipv4_method": "auto",
        "profile_connection_type": "802-3-ethernet",
        "autoconnect_enabled": True,
        "target_dns_servers": ["1.1.1.1"],
    })
    status, _ = _run(payload)
    assert status == ChangeStatus.PASS


def test_alpha51_existing_profile_autoconnect_staging_passes():
    payload = _payload("set_networkmanager_autoconnect")
    payload.update({
        "target_profile_name": "",
        "existing_profile_filename": "wired.nmconnection",
        "ipv4_method": "preserve",
        "target_interface": "",
        "autoconnect_enabled": False,
        "require_profile_reverification_before_apply": True,
    })
    status, _ = _run(payload)
    assert status == ChangeStatus.PASS


def test_alpha51_invalid_ip_dns_and_ipv6_are_rejected():
    bad_static = _payload("configure_static_ipv4")
    bad_static.update({"ipv4_method": "manual", "target_ipv4_address": "999.1.1.1/24", "target_gateway": "192.168.1.1"})
    assert _run(bad_static)[0] == ChangeStatus.FAIL

    bad_dns = _payload("configure_dns_servers")
    bad_dns.update({"ipv4_method": "preserve", "target_dns_servers": ["not-an-ip"]})
    assert _run(bad_dns)[0] == ChangeStatus.FAIL

    ipv6 = _payload("configure_dns_servers")
    ipv6.update({"ipv4_method": "preserve", "target_dns_servers": ["2001:4860:4860::8888"]})
    assert _run(ipv6)[0] == ChangeStatus.FAIL


def test_alpha51_unknown_capability_and_unverified_target_fail_closed():
    payload = _payload()
    payload["capability_status"] = "UNKNOWN"
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload()
    payload["rootfs_network_dns_verified"] = False
    assert _run(payload)[0] == ChangeStatus.FAIL


def test_alpha51_secret_and_host_network_substitution_are_rejected():
    payload = _payload()
    payload["password"] = "super-secret-network-password"
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload()
    payload["host_network_accessed"] = True
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload()
    payload["wifi_vpn_secrets_read"] = True
    assert _run(payload)[0] == ChangeStatus.FAIL


def test_alpha51_acceptance_runner_has_real_staged_network_gate():
    text = (Path(__file__).parents[1] / "chromapress_acceptance.py").read_text(encoding="utf-8")
    assert "P4-REAL-STAGED-NETWORK-CONFIG" in text
    assert "configure_dhcp_ipv4" in text
    assert "test_change" in text


def test_alpha51_version_markers():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
