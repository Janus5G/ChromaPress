from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.applications_page import ApplicationsPage
from chromapress.settings import AppSettings


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _page(qapp, scenario: str) -> ApplicationsPage:
    page = ApplicationsPage(AppSettings())
    page._source = {"distribution": "Lubuntu", "version": "26.04.1", "path": "test.iso"}
    page._catalog = [
        {"application": "About LXQt", "package": "lxqt-about", "description": "About LXQt", "categories": ["System"]},
    ]
    page._catalog_loaded = True
    page.set_scenario(scenario)
    return page


def _all_tree_text(page: ApplicationsPage) -> list[str]:
    result = []
    def walk(item):
        result.append(item.text(0))
        for i in range(item.childCount()):
            walk(item.child(i))
    for i in range(page.tree.topLevelItemCount()):
        walk(page.tree.topLevelItem(i))
    return result


def test_active_scenario_remains_visibly_checked(qapp):
    page = _page(qapp, "gaming_team")
    button = page.scenario_buttons["gaming_team"]
    assert button.isChecked()
    assert "QPushButton:checked" in button.styleSheet()
    assert "background-color" in button.styleSheet()


@pytest.mark.parametrize("selected,query,expected", [
    ("gaming_team", "MangoHud", "Available: MangoHud"),
    ("business", "MangoHud", "Available: MangoHud"),
    ("personal", "nvtop", "Available: nvtop"),
    ("production", "Speedtest CLI", "Available: Speedtest CLI"),
    ("development", "GLMark2", "Available: GLMark2"),
])
def test_search_is_global_across_profiles(qapp, selected, query, expected):
    page = _page(qapp, selected)
    page.search.setText(query)
    assert expected in _all_tree_text(page)


def test_installed_search_stays_global(qapp):
    page = _page(qapp, "gaming_team")
    page.search.setText("About LXQt")
    assert "About LXQt" in _all_tree_text(page)
