from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _profile_d_source_semantics, _system_config_overlay_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _evidence(capability="SUPPORTED_WITH_REQUIREMENTS", entries=None):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha54",
        "analysis_scope": "target_iso_rootfs",
        "capability_status": capability,
        "verified": supported,
        "backend": "profile.d",
        "profile_path": "/etc/profile",
        "profile_layer": "/casper/minimal.squashfs" if supported else "",
        "target_directory": "/etc/profile.d",
        "target_directory_layer": "/casper/minimal.squashfs" if supported else "",
        "profile_d_sourcing_verified": supported,
        "existing_entry_names": list(entries or []),
        "existing_dropin_contents_read": False,
        "supported_operations": ["add_managed_environment_overlay"] if supported else [],
        "managed_filename_prefix": "99-chromapress-",
        "managed_filename_suffix": ".sh",
        "host_configuration_accessed": False,
        "secret_read": False,
        "source_read_only": True,
        "reason": f"{capability} — test evidence",
    }


def _payload(capability="SUPPORTED_WITH_REQUIREMENTS", *, entries=None, name="chromatest54", variable="CHROMAPRESS_TEST", value="1"):
    e = _evidence(capability, entries)
    return {
        "config_type": "system_config_overlay",
        "gate_version": "alpha54",
        "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_rootfs",
        "capability_status": capability,
        "rootfs_overlay_verified": e["verified"],
        "operation": "add_managed_environment_overlay",
        "backend": e["backend"],
        "profile_path": e["profile_path"],
        "profile_layer": e["profile_layer"],
        "target_directory": e["target_directory"],
        "target_directory_layer": e["target_directory_layer"],
        "profile_d_sourcing_verified": e["profile_d_sourcing_verified"],
        "existing_entry_names": e["existing_entry_names"],
        "overlay_name": name,
        "target_filename": f"99-chromapress-{name}.sh",
        "environment_variable": variable,
        "public_nonsecret_value": value,
        "content_classification": "public_nonsecret",
        "generated_content_only": True,
        "arbitrary_shell_content_allowed": False,
        "require_target_file_absence_reverification_before_apply": True,
        "preserve_existing_profile": True,
        "preserve_existing_dropins": True,
        "existing_dropin_contents_read": False,
        "host_configuration_accessed": False,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("System configuration overlay plan", ChangeKind.CONFIG, "test", payload))


def test_alpha54_profile_d_semantics_are_explicitly_verified():
    good = """if [ -d /etc/profile.d ]; then\n  for i in /etc/profile.d/*.sh; do\n    if [ -r $i ]; then\n      . $i\n    fi\n  done\nfi\n"""
    assert _profile_d_source_semantics(good) is True
    assert _profile_d_source_semantics("# /etc/profile.d/*.sh only\necho hello\n") is False
    assert _profile_d_source_semantics(". $i\n") is False


def test_alpha54_target_evidence_is_supported_when_profile_and_directory_are_verified(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    layers = ["/casper/minimal.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (1, 1)})
    monkeypatch.setattr(
        "chromapress.engine_cli._read_squashfs_overlay_text",
        lambda *a, **k: ("for i in /etc/profile.d/*.sh; do\n  . $i\ndone\n", layers[0]),
    )
    monkeypatch.setattr(
        "chromapress.engine_cli._list_overlay_directory_entries",
        lambda *a, **k: (["apps-bin-path.sh", "custom.sh"], layers[0]),
    )
    evidence = _system_config_overlay_rootfs_evidence(iso, layers)
    assert evidence["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["verified"] is True
    assert evidence["profile_d_sourcing_verified"] is True
    assert evidence["existing_entry_names"] == ["apps-bin-path.sh", "custom.sh"]
    assert evidence["existing_dropin_contents_read"] is False
    assert evidence["host_configuration_accessed"] is False
    assert evidence["secret_read"] is False
    assert evidence["source_read_only"] is True


def test_alpha54_unverified_states_remain_unknown(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    assert _system_config_overlay_rootfs_evidence(iso, [])["capability_status"] == "UNKNOWN"

    layers = ["/casper/minimal.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (1, 1)})
    monkeypatch.setattr("chromapress.engine_cli._read_squashfs_overlay_text", lambda *a, **k: ("PATH=/usr/bin\n", layers[0]))
    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", lambda *a, **k: ([], layers[0]))
    assert _system_config_overlay_rootfs_evidence(iso, layers)["capability_status"] == "UNKNOWN"

    monkeypatch.setattr("chromapress.engine_cli._read_squashfs_overlay_text", lambda *a, **k: ("for i in /etc/profile.d/*.sh; do\n . $i\ndone\n", layers[0]))
    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", lambda *a, **k: ([], ""))
    assert _system_config_overlay_rootfs_evidence(iso, layers)["capability_status"] == "UNKNOWN"


def test_alpha54_valid_managed_overlay_stages_cleanly():
    status, message = _run(_payload())
    assert status == ChangeStatus.PASS, message
    assert "collision checked" in message
    assert "non-secret input validated" in message


def test_alpha54_unknown_blocked_and_unsupported_fail_closed():
    for capability in ("UNKNOWN", "BLOCKED", "UNSUPPORTED"):
        assert _run(_payload(capability))[0] == ChangeStatus.FAIL


def test_alpha54_existing_filename_is_never_overwritten():
    target = "99-chromapress-chromatest54.sh"
    assert _run(_payload(entries=[target]))[0] == ChangeStatus.FAIL


def test_alpha54_secret_like_or_unsafe_content_is_rejected():
    for variable in ("API_KEY", "LOGIN_TOKEN", "PASSWORD", "AUTH_TOKEN"):
        assert _run(_payload(variable=variable))[0] == ChangeStatus.FAIL
    for value in ("hello world", "$(id)", "x;rm", "", "a" * 129):
        assert _run(_payload(value=value))[0] == ChangeStatus.FAIL


def test_alpha54_arbitrary_shell_and_host_substitution_are_rejected():
    p = _payload()
    p["arbitrary_shell_content_allowed"] = True
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload()
    p["existing_dropin_contents_read"] = True
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload()
    p["host_configuration_accessed"] = True
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha54_preservation_and_reverification_are_mandatory():
    p = _payload()
    p["preserve_existing_dropins"] = False
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload()
    p["require_target_file_absence_reverification_before_apply"] = False
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload()
    p["source_read_only"] = False
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha54_acceptance_runner_has_dedicated_gate():
    text = (Path(__file__).parents[1] / "chromapress_acceptance.py").read_text(encoding="utf-8")
    assert "P4-ALPHA54-CONFIG-OVERLAY" in text
    assert "_add_alpha54_config_overlay_gate" in text
    assert "system_config_overlay_evidence" in text


def test_alpha54_acceptance_gate_executes_supported_and_unknown(tmp_path):
    import sys
    root = Path(__file__).parents[1]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    from chromapress_acceptance import AcceptanceRunner, PASS

    runner = AcceptanceRunner(root, 4, None, None, tmp_path)
    runner._add_alpha54_config_overlay_gate(_evidence(), "a" * 64)
    assert runner.checks[-1].status == PASS

    runner._add_alpha54_config_overlay_gate(_evidence("UNKNOWN"), "a" * 64)
    assert runner.checks[-1].status == PASS
    assert "fail-closed" in runner.checks[-1].detail


def test_alpha54_version_markers():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
