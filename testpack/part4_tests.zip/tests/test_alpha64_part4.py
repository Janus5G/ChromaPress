from pathlib import Path

import pytest

from chromapress.engine_cli import _system_webauthn_policy_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight
from chromapress_acceptance import AcceptanceRunner


def _admin(cap="SUPPORTED_WITH_REQUIREMENTS"):
    supported = cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha62",
        "analysis_scope": "target_iso_rootfs",
        "capability_status": cap,
        "verified": supported,
        "existing_admin_users": ["liveadmin"] if supported else [],
        "existing_regular_users": ["liveadmin", "student"] if supported else [],
        "autologin_user": "kiosk" if supported else "",
        "shadow_read": False,
        "credential_secret_read": False,
        "recovery_secret_read": False,
        "pam_contents_read": False,
        "ssh_config_read": False,
        "rescue_boot_config_read": False,
        "root_account_policy_read": False,
        "host_accounts_touched": False,
        "host_login_state_accessed": False,
        "source_read_only": True,
    }


def _fido2():
    return {"gate_version": "alpha63", "capability_status": "UNKNOWN", "verified": False}


def _versions(*, browser=True, lib=True):
    d = {"base-files": "1"}
    if browser:
        d["firefox"] = "140.0"
    if lib:
        d["libfido2-1"] = "1.15.0"
    return d


def _supported():
    return _system_webauthn_policy_evidence("deb", _versions(), _admin(), _fido2())


def _payload(e=None, *, username="liveadmin", browser="firefox"):
    e = dict(e or _supported())
    return {
        "config_type": "webauthn_policy",
        "gate_version": "alpha64",
        "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_package_manifest",
        "capability_status": e.get("capability_status", "UNKNOWN"),
        "webauthn_policy_verified": e.get("verified") is True,
        "operation": "allow_webauthn_for_recovery_web_workflows",
        "policy_scope": "recovery_administrator_browser_webauthn",
        "username": username,
        "current_autologin_user": "kiosk",
        "administrator_recovery_dependency": "alpha62_administrator_recovery_policy",
        "alpha62_dependency_verified": e.get("alpha62_dependency_verified") is True,
        "alpha63_evidence_observed": e.get("alpha63_evidence_observed") is True,
        "browser_package": browser,
        "browser_packages": list(e.get("browser_packages") or []),
        "libfido2_packages": list(e.get("libfido2_packages") or []),
        "browser_config_contents_read": False,
        "webauthn_runtime_verified": False,
        "relying_party_config_read": False,
        "relying_party_verified": False,
        "origin_config_read": False,
        "origin_verified": False,
        "authenticator_devices_enumerated": False,
        "usb_hid_state_accessed": False,
        "credential_ids_read": False,
        "credential_secret_read": False,
        "credential_secret_staged": False,
        "authenticator_enrollment_performed": False,
        "security_key_presence_claimed": False,
        "yubikey_capability_claimed": False,
        "platform_authenticator_claimed": False,
        "tpm_capability_claimed": False,
        "host_browser_state_accessed": False,
        "host_authenticator_state_accessed": False,
        "preserve_existing_primary_authentication": True,
        "preserve_browser_configuration_during_analysis_and_staging": True,
        "require_browser_runtime_verification_before_apply": True,
        "require_relying_party_and_origin_verification_before_use": True,
        "require_alpha62_dependency_before_apply": True,
        "require_alpha62_dependency_reverification_before_apply": True,
        "require_target_package_reverification_before_apply": True,
        "require_recovery_username_reverification_before_apply": True,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("WebAuthn policy plan", ChangeKind.CONFIG, "test", payload))


def test_alpha64_allowlisted_browser_is_requirements_only():
    e = _supported()
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert e["verified"] is True
    assert e["browser_packages"] == ["firefox"]
    assert e["supported_operations"] == ["allow_webauthn_for_recovery_web_workflows"]
    assert e["alpha62_dependency_verified"] is True
    assert e["webauthn_runtime_verified"] is False
    assert e["relying_party_verified"] is False
    assert e["origin_verified"] is False


def test_alpha64_missing_browser_is_unknown_not_guessed():
    e = _system_webauthn_policy_evidence("deb", _versions(browser=False), _admin(), _fido2())
    assert e["capability_status"] == "UNKNOWN"
    assert e["verified"] is False


def test_alpha64_libfido2_is_informational_not_runtime_proof():
    e = _system_webauthn_policy_evidence("deb", _versions(lib=False), _admin(), _fido2())
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert e["libfido2_packages"] == []
    assert e["webauthn_runtime_verified"] is False


def test_alpha64_unverified_alpha62_dependency_is_unknown():
    e = _system_webauthn_policy_evidence("deb", _versions(), _admin("UNKNOWN"), _fido2())
    assert e["capability_status"] == "UNKNOWN"
    assert e["verified"] is False


def test_alpha64_privacy_unsafe_alpha62_dependency_blocks():
    a = _admin(); a["pam_contents_read"] = True
    e = _system_webauthn_policy_evidence("deb", _versions(), a, _fido2())
    assert e["capability_status"] == "BLOCKED"


def test_alpha64_supported_preflight_passes():
    status, message = _run(_payload())
    assert status == ChangeStatus.PASS
    assert "runtime/RP/origin/authenticator claims deferred" in message


@pytest.mark.parametrize("cap", ["UNKNOWN", "BLOCKED", "UNSUPPORTED"])
def test_alpha64_unverified_capability_fails_closed(cap):
    e = _supported(); e["capability_status"] = cap; e["verified"] = False
    assert _run(_payload(e))[0] == ChangeStatus.FAIL


def test_alpha64_root_and_autologin_users_are_blocked():
    assert _run(_payload(username="root"))[0] == ChangeStatus.FAIL
    assert _run(_payload(username="kiosk"))[0] == ChangeStatus.FAIL


def test_alpha64_browser_must_be_bound_to_verified_list():
    assert _run(_payload(browser="chromium"))[0] == ChangeStatus.FAIL
    p = _payload(); p["browser_packages"] = []
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha64_rejects_runtime_rp_origin_claims():
    for key in ("webauthn_runtime_verified", "relying_party_verified", "origin_verified"):
        p = _payload(); p[key] = True
        assert _run(p)[0] == ChangeStatus.FAIL, key


def test_alpha64_rejects_browser_authenticator_secret_or_later_gate_claims():
    for key in (
        "browser_config_contents_read", "relying_party_config_read", "origin_config_read",
        "authenticator_devices_enumerated", "usb_hid_state_accessed", "credential_ids_read",
        "credential_secret_read", "credential_secret_staged", "authenticator_enrollment_performed",
        "security_key_presence_claimed", "yubikey_capability_claimed", "platform_authenticator_claimed",
        "tpm_capability_claimed", "host_browser_state_accessed", "host_authenticator_state_accessed",
    ):
        p = _payload(); p[key] = True
        assert _run(p)[0] == ChangeStatus.FAIL, key


def test_alpha64_rejects_missing_dependencies_and_preservation():
    p = _payload(); p["administrator_recovery_dependency"] = "none"
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["alpha62_dependency_verified"] = False
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["preserve_existing_primary_authentication"] = False
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["require_relying_party_and_origin_verification_before_use"] = False
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha64_acceptance_supported_and_unknown(tmp_path):
    runner = AcceptanceRunner(tmp_path, 4, None, None, tmp_path / "reports")
    e = _supported(); a = _admin()
    runner._add_alpha64_webauthn_policy_gate(e, a, "a" * 64)
    assert runner.checks[-1].status == "PASS"
    e["capability_status"] = "UNKNOWN"; e["verified"] = False; e["browser_packages"] = []
    runner._add_alpha64_webauthn_policy_gate(e, a, "a" * 64)
    assert runner.checks[-1].status == "PASS"


def test_alpha64_version_markers():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")


def test_alpha64_part4_source_guard_includes_webauthn_policy():
    root = Path(__file__).resolve().parents[1]
    text = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert '"webauthn_policy"' in text
