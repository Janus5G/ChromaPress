from pathlib import Path

import pytest

from chromapress.engine_cli import _system_network_restriction_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight
from chromapress_acceptance import AcceptanceRunner


def _network(backend="NetworkManager", verified=True):
    return {"verified": verified, "capability_status": "SUPPORTED_WITH_REQUIREMENTS" if verified else "UNKNOWN", "backend": backend}


def _supported():
    return {
        "gate_version": "alpha59", "analysis_scope": "target_iso_rootfs",
        "capability_status": "SUPPORTED_WITH_REQUIREMENTS", "verified": True,
        "backend": "NetworkManager-polkit-managed-rule", "network_backend": "NetworkManager",
        "polkit_rules_directory": "/etc/polkit-1/rules.d", "polkit_rules_directory_layer": "/casper/minimal.squashfs",
        "networkmanager_policy_path": "/usr/share/polkit-1/actions/org.freedesktop.NetworkManager.policy",
        "networkmanager_policy_layer": "/casper/minimal.squashfs",
        "managed_rule_name": "49-chromapress-kiosk-network.rules",
        "managed_rule_path": "/etc/polkit-1/rules.d/49-chromapress-kiosk-network.rules",
        "managed_target_present": False, "existing_rule_names": ["10-vendor.rules"],
        "supported_operations": ["restrict_kiosk_networkmanager_control"],
        "restricted_actions": [
            "org.freedesktop.NetworkManager.enable-disable-network",
            "org.freedesktop.NetworkManager.enable-disable-wifi",
            "org.freedesktop.NetworkManager.enable-disable-wwan",
            "org.freedesktop.NetworkManager.settings.modify.system",
        ],
        "restriction_scope": "kiosk_networkmanager_control_only",
        "traffic_blocking_claimed": False, "firewall_rules_read": False, "firewall_rules_staged": False,
        "networkmanager_profile_contents_read": False, "polkit_policy_contents_read": False,
        "existing_rule_contents_read": False, "credential_secret_read": False, "host_network_accessed": False,
        "source_read_only": True, "reason": "PASS",
    }


def _payload(e=None, capability=None):
    e = dict(e or _supported())
    if capability is not None:
        e["capability_status"] = capability
        e["verified"] = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "config_type": "network_restriction", "gate_version": "alpha59", "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_rootfs", "capability_status": e["capability_status"],
        "rootfs_network_restriction_verified": e["verified"], "operation": "restrict_kiosk_networkmanager_control",
        "backend": e.get("backend", ""), "network_backend": e.get("network_backend", ""),
        "polkit_rules_directory": e.get("polkit_rules_directory", ""), "polkit_rules_directory_layer": e.get("polkit_rules_directory_layer", ""),
        "networkmanager_policy_path": e.get("networkmanager_policy_path", ""), "networkmanager_policy_layer": e.get("networkmanager_policy_layer", ""),
        "managed_rule_name": e.get("managed_rule_name", ""), "managed_rule_path": e.get("managed_rule_path", ""),
        "managed_target_present": e.get("managed_target_present", False), "existing_rule_names": list(e.get("existing_rule_names", [])),
        "restricted_actions": list(e.get("restricted_actions", [])), "username": "chromakiosk59",
        "restriction_scope": "kiosk_networkmanager_control_only", "kiosk_user_dependency": "alpha55_dedicated_non_admin_kiosk_user_required",
        "traffic_blocking_claimed": False, "firewall_rules_read": False, "firewall_rules_staged": False,
        "networkmanager_profile_contents_read": False, "polkit_policy_contents_read": False, "existing_rule_contents_read": False,
        "credential_secret_read": False, "host_network_accessed": False,
        "preserve_existing_network_profiles": True, "preserve_existing_polkit_rules": True, "preserve_firewall_policy": True,
        "preserve_other_users_network_control": True, "require_managed_target_absence_reverification_before_apply": True,
        "require_networkmanager_polkit_reverification_before_apply": True, "require_kiosk_user_dependency_reverification_before_apply": True,
        "source_read_only": True, "preserve_unrelated": True, "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("Network restrictions plan", ChangeKind.CONFIG, "test", payload))


def test_alpha59_detects_networkmanager_polkit_without_reading_contents(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"alpha59")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/casper/minimal.squashfs": (1, 2)})
    def presence(_iso, _layers, member, _ext):
        if member in {"/etc/polkit-1/rules.d", "/usr/share/polkit-1/actions/org.freedesktop.NetworkManager.policy"}:
            return True, "/casper/minimal.squashfs"
        return False, ""
    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", presence)
    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", lambda *_: (["10-vendor.rules"], "/casper/minimal.squashfs"))
    e = _system_network_restriction_evidence(iso, ["/casper/minimal.squashfs"], _network())
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS" and e["verified"] is True
    assert e["traffic_blocking_claimed"] is False and e["polkit_policy_contents_read"] is False


def test_alpha59_non_networkmanager_or_unverified_stays_unknown(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"x")
    assert _system_network_restriction_evidence(iso, ["/x.squashfs"], _network("systemd-networkd"))["capability_status"] == "UNKNOWN"
    assert _system_network_restriction_evidence(iso, ["/x.squashfs"], _network(verified=False))["capability_status"] == "UNKNOWN"


def test_alpha59_managed_rule_collision_is_blocked(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"; iso.write_bytes(b"x")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *_: {"/x.squashfs": (1, 2)})
    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", lambda *_: (True, "/x.squashfs"))
    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", lambda *_: (["49-chromapress-kiosk-network.rules"], "/x.squashfs"))
    e = _system_network_restriction_evidence(iso, ["/x.squashfs"], _network())
    assert e["capability_status"] == "BLOCKED" and e["verified"] is False


def test_alpha59_supported_preflight_passes():
    status, msg = _run(_payload())
    assert status == ChangeStatus.PASS
    assert "non-traffic-blocking" in msg

@pytest.mark.parametrize("cap", ["UNKNOWN", "BLOCKED", "UNSUPPORTED"])
def test_alpha59_unverified_capabilities_fail_closed(cap):
    status, _ = _run(_payload(capability=cap))
    assert status == ChangeStatus.FAIL


def test_alpha59_rejects_unsafe_scope_or_firewall_claims():
    p = _payload(); p["traffic_blocking_claimed"] = True
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["firewall_rules_staged"] = True
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["restriction_scope"] = "block_all_traffic"
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha59_requires_collision_free_managed_path_and_safe_username():
    p = _payload(); p["managed_target_present"] = True
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["username"] = "BAD USER"
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha59_preservation_and_reverification_are_required():
    for key in (
        "preserve_existing_network_profiles", "preserve_existing_polkit_rules", "preserve_firewall_policy",
        "preserve_other_users_network_control", "require_managed_target_absence_reverification_before_apply",
        "require_networkmanager_polkit_reverification_before_apply", "require_kiosk_user_dependency_reverification_before_apply",
        "source_read_only", "preserve_unrelated", "stage_only",
    ):
        p = _payload(); p[key] = False
        assert _run(p)[0] == ChangeStatus.FAIL, key


def test_alpha59_acceptance_gate_supported_and_unknown(tmp_path):
    runner = AcceptanceRunner(tmp_path, 4, None, None, tmp_path / "reports")
    runner._add_alpha59_network_restriction_gate(_supported(), "a" * 64)
    assert runner.checks[-1].status == "PASS"
    e = _supported(); e.update({"capability_status": "UNKNOWN", "verified": False, "backend": "", "network_backend": "NetworkManager"})
    runner._add_alpha59_network_restriction_gate(e, "a" * 64)
    assert runner.checks[-1].status == "PASS"


def test_alpha59_version_markers():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
