from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.applications_page import ApplicationsPage
from chromapress.settings import AppSettings


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _page(qapp, scenario: str) -> ApplicationsPage:
    page = ApplicationsPage(AppSettings())
    page._source = {"distribution": "Lubuntu", "version": "26.04.1", "path": "test.iso"}
    page._catalog = [
        {"application": "About LXQt", "package": "lxqt-about", "description": "About LXQt", "categories": ["System"]},
    ]
    page._catalog_loaded = True
    page.set_scenario(scenario)
    return page


def _all_tree_text(page: ApplicationsPage) -> list[str]:
    result = []
    def walk(item):
        result.append(item.text(0))
        for i in range(item.childCount()):
            walk(item.child(i))
    for i in range(page.tree.topLevelItemCount()):
        walk(page.tree.topLevelItem(i))
    return result


def test_switching_profile_exits_global_search_and_refreshes_profile_view(qapp):
    page = _page(qapp, "education")
    page.search.setText("MangoHud")
    assert page.search.text() == "MangoHud"
    assert "Available: MangoHud" in _all_tree_text(page)

    page.set_scenario("gaming_team")

    assert page.search.text() == ""
    assert page.scenario_buttons["gaming_team"].isChecked()
    assert page.search.text() == ""
    assert any("MangoHud" in text for text in _all_tree_text(page))


def test_search_is_still_global_after_profile_switch(qapp):
    page = _page(qapp, "gaming_team")
    page.set_scenario("business")
    page.search.setText("MangoHud")
    assert "Available: MangoHud" in _all_tree_text(page)
