import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QMessageBox

from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _kiosk():
    return {
        "gate_version": "alpha55", "analysis_scope": "target_iso_rootfs",
        "capability_status": "SUPPORTED_WITH_REQUIREMENTS", "verified": True,
        "existing_regular_users": ["live"], "admin_users": ["liveadmin"],
        "shadow_read": False, "credential_secret_read": False, "host_accounts_touched": False,
        "source_read_only": True,
    }


def _evidence(cap="SUPPORTED_WITH_REQUIREMENTS"):
    supported = cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha61", "analysis_scope": "target_iso_metadata",
        "capability_status": cap, "verified": supported,
        "supported_operations": ["require_volatile_kiosk_runtime", "require_controlled_kiosk_persistence"] if supported else [],
        "policy_scope": "kiosk_session_runtime_only",
        "rootfs_layers": ["/casper/minimal.squashfs"] if supported else [],
        "boot_config_files": ["/boot/grub/grub.cfg"] if supported else [],
        "initramfs_mechanism": "update-initramfs" if supported else "",
        "part3_volatile_dependency": "immutable_runtime", "part3_controlled_dependency": "controlled_persistence",
        "existing_persistence_policy_read": False, "persistent_data_contents_read": False,
        "mount_configuration_contents_read": False, "host_storage_accessed": False,
        "host_mount_state_accessed": False, "source_read_only": True,
        "reason": "PASS" if supported else f"{cap} — blocked",
    }


def _analysis(cap="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "sha256": "a" * 64, "package_format": "deb",
        "system_kiosk_user_evidence": _kiosk(),
        "system_persistence_policy_evidence": _evidence(cap),
    }


def test_alpha61_volatile_stage_test_and_undo(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    changes = ChangesPanel(); page.stage_requested.connect(changes.add_change)
    page.persistence_policy_operation.setCurrentIndex(page.persistence_policy_operation.findData("require_volatile_kiosk_runtime"))
    page.persistence_policy_username.setText("chromakiosk61")
    page.stage_persistence_policy_btn.click()
    assert len(changes.changes) == 1
    changes.list.setCurrentRow(0); changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == [] and changes.summary.text() == "No changes staged"


def test_alpha61_controlled_stage_is_home_scoped(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    emitted=[]; page.stage_requested.connect(emitted.append)
    page.persistence_policy_operation.setCurrentIndex(page.persistence_policy_operation.findData("require_controlled_kiosk_persistence"))
    page.persistence_policy_username.setText("chromakiosk61")
    page.persistence_policy_directories.setText("/home/chromakiosk61/data;/home/chromakiosk61/.config/app")
    page.stage_persistence_policy_btn.click()
    assert len(emitted) == 1
    assert emitted[0].payload["part3_dependency"] == "controlled_persistence"
    assert emitted[0].payload["persistent_directories"] == ["/home/chromakiosk61/data", "/home/chromakiosk61/.config/app"]


def test_alpha61_unknown_gui_fails_closed(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis("UNKNOWN"))
    emitted=[]; page.stage_requested.connect(emitted.append)
    page.persistence_policy_operation.setCurrentIndex(page.persistence_policy_operation.findData("require_volatile_kiosk_runtime"))
    page.persistence_policy_username.setText("chromakiosk61")
    page.stage_persistence_policy_btn.click()
    assert emitted == []
    assert "UNKNOWN" in page.persistence_policy_plan_status.text()


def test_alpha61_gui_rejects_broad_system_path(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    emitted=[]; page.stage_requested.connect(emitted.append)
    page.persistence_policy_operation.setCurrentIndex(page.persistence_policy_operation.findData("require_controlled_kiosk_persistence"))
    page.persistence_policy_username.setText("chromakiosk61")
    page.persistence_policy_directories.setText("/var/lib")
    page.stage_persistence_policy_btn.click()
    assert emitted == []
