from pathlib import Path

import pytest

from chromapress.engine_cli import _system_persistence_policy_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight
from chromapress_acceptance import AcceptanceRunner


def _kiosk(cap="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "gate_version": "alpha55",
        "analysis_scope": "target_iso_rootfs",
        "capability_status": cap,
        "verified": cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"},
        "existing_regular_users": ["live"],
        "admin_users": ["liveadmin"],
        "shadow_read": False,
        "credential_secret_read": False,
        "host_accounts_touched": False,
        "source_read_only": True,
    }


def _supported():
    return _system_persistence_policy_evidence(
        ["/casper/minimal.squashfs"],
        {"boot_config_files": ["/boot/grub/grub.cfg"]},
        "deb",
        _kiosk(),
    )


def _payload(e=None, *, controlled=False):
    e = dict(e or _supported())
    operation = "require_controlled_kiosk_persistence" if controlled else "require_volatile_kiosk_runtime"
    dirs = ["/home/chromakiosk61/data"] if controlled else []
    return {
        "config_type": "persistence_policy",
        "gate_version": "alpha61",
        "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_metadata",
        "capability_status": e.get("capability_status", "UNKNOWN"),
        "rootfs_persistence_policy_verified": e.get("verified") is True,
        "operation": operation,
        "username": "chromakiosk61",
        "account_dependency": "alpha55_dedicated_non_admin_kiosk_user",
        "existing_regular_users": ["live"], "admin_users": ["liveadmin"],
        "policy_scope": "kiosk_session_runtime_only",
        "persistence_policy": "selected_directories" if controlled else "volatile",
        "persistent_directories": dirs,
        "runtime_changes_survive_reboot": False,
        "selected_directories_survive_reboot": controlled,
        "unlisted_runtime_changes_survive_reboot": False,
        "part3_dependency": "controlled_persistence" if controlled else "immutable_runtime",
        "rootfs_layers": list(e.get("rootfs_layers") or []),
        "boot_config_files": list(e.get("boot_config_files") or []),
        "initramfs_mechanism": str(e.get("initramfs_mechanism") or ""),
        "existing_persistence_policy_read": False,
        "persistent_data_contents_read": False,
        "mount_configuration_contents_read": False,
        "host_storage_accessed": False,
        "host_mount_state_accessed": False,
        "require_part3_dependency_before_apply": True,
        "require_part3_dependency_reverification_before_apply": True,
        "require_account_dependency_reverification_before_apply": True,
        "preserve_existing_persistence_configuration": True,
        "preserve_unselected_user_data": True,
        "do_not_stage_mount_or_volume_changes": True,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("Persistence policy plan", ChangeKind.CONFIG, "test", payload))


def test_alpha61_supported_metadata_is_requirements_only():
    e = _supported()
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert e["verified"] is True
    assert e["initramfs_mechanism"] == "update-initramfs"
    assert e["existing_persistence_policy_read"] is False
    assert e["persistent_data_contents_read"] is False
    assert e["host_storage_accessed"] is False
    assert set(e["supported_operations"]) == {
        "require_volatile_kiosk_runtime",
        "require_controlled_kiosk_persistence",
    }


@pytest.mark.parametrize("layers,boot,fmt", [
    ([], {"boot_config_files": ["/boot/grub/grub.cfg"]}, "deb"),
    (["/casper/minimal.squashfs"], {"boot_config_files": []}, "deb"),
    (["/casper/minimal.squashfs"], {"boot_config_files": ["/boot/grub/grub.cfg"]}, "unknown"),
])
def test_alpha61_incomplete_part3_evidence_is_unknown(layers, boot, fmt):
    e = _system_persistence_policy_evidence(layers, boot, fmt, _kiosk())
    assert e["capability_status"] == "UNKNOWN"
    assert e["verified"] is False



def test_alpha61_unverified_kiosk_account_scope_is_unknown():
    kiosk = _kiosk("UNKNOWN")
    e = _system_persistence_policy_evidence(["/x.squashfs"], {"boot_config_files": ["/grub.cfg"]}, "deb", kiosk)
    assert e["capability_status"] == "UNKNOWN"
    assert e["verified"] is False

def test_alpha61_privacy_unsafe_kiosk_evidence_is_blocked():
    kiosk = _kiosk(); kiosk["shadow_read"] = True
    e = _system_persistence_policy_evidence(["/x.squashfs"], {"boot_config_files": ["/grub.cfg"]}, "deb", kiosk)
    assert e["capability_status"] == "BLOCKED"


def test_alpha61_volatile_preflight_passes():
    status, message = _run(_payload())
    assert status == ChangeStatus.PASS
    assert "Part-3 delegated" in message


def test_alpha61_controlled_preflight_passes():
    status, message = _run(_payload(controlled=True))
    assert status == ChangeStatus.PASS
    assert "Part-3 delegated" in message


@pytest.mark.parametrize("cap", ["UNKNOWN", "BLOCKED", "UNSUPPORTED"])
def test_alpha61_unverified_capabilities_fail_closed(cap):
    e = _supported(); e["capability_status"] = cap; e["verified"] = False
    assert _run(_payload(e))[0] == ChangeStatus.FAIL


def test_alpha61_controlled_paths_are_kiosk_home_scoped():
    p = _payload(controlled=True); p["persistent_directories"] = ["/etc/chromapress"]
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(controlled=True); p["persistent_directories"] = ["/home/chromakiosk61/../root"]
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha61_volatile_rejects_persistent_directories():
    p = _payload(); p["persistent_directories"] = ["/home/chromakiosk61/data"]
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha61_dependency_must_match_policy():
    p = _payload(); p["part3_dependency"] = "controlled_persistence"
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha61_rejects_reads_host_state_and_direct_mount_staging():
    for key in (
        "existing_persistence_policy_read", "persistent_data_contents_read", "mount_configuration_contents_read",
        "host_storage_accessed", "host_mount_state_accessed",
    ):
        p = _payload(); p[key] = True
        assert _run(p)[0] == ChangeStatus.FAIL, key
    p = _payload(); p["do_not_stage_mount_or_volume_changes"] = False
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha61_acceptance_supported_and_unknown(tmp_path):
    runner = AcceptanceRunner(tmp_path, 4, None, None, tmp_path / "reports")
    e = _supported()
    runner._add_alpha61_persistence_policy_gate(e, _kiosk(), "a" * 64)
    assert runner.checks[-1].status == "PASS"
    e["capability_status"] = "UNKNOWN"; e["verified"] = False
    runner._add_alpha61_persistence_policy_gate(e, _kiosk(), "a" * 64)
    assert runner.checks[-1].status == "PASS"


def test_alpha61_version_markers():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")


def test_alpha61_part4_source_guard_includes_newer_part4_plan_types():
    root = Path(__file__).resolve().parents[1]
    text = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    for config_type in (
        "system_security_defaults", "system_config_overlay", "dedicated_kiosk_user",
        "restricted_login", "restricted_session", "service_lockdown", "network_restriction",
        "firewall_rule", "persistence_policy",
    ):
        assert f'"{config_type}"' in text
