from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.boot_hardware_page import BootHardwarePage
from chromapress.models import ChangeKind


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def test_alpha28_kernel_plan_stages_only_with_required_source_evidence(qapp):
    page = BootHardwarePage()
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.set_analysis({
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "kernel_images": ["/casper/vmlinuz"],
        "initramfs_images": ["/casper/initrd"],
        "rootfs": ["/casper/minimal.standard.live.squashfs"],
        "initramfs_mechanism": "update-initramfs",
    })
    assert page.stage_kernel_btn.isEnabled()
    assert page.stage_kernel_btn.minimumWidth() >= 130
    assert page.stage_kernel_btn.minimumHeight() >= 30
    assert page.reset_kernel_btn.minimumWidth() >= 70
    assert page.reset_kernel_btn.minimumHeight() >= 30
    assert page.kernel_plan_status.parentWidget() is page.stage_kernel_btn.parentWidget()
    page.regenerate_initramfs.setChecked(True)
    page.stage_kernel_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "kernel_initramfs"
    assert change.payload["stage_only"] is True
    assert change.payload["protect_last_viable_kernel"] is True
    assert change.payload["regenerate_initramfs"] is True
    assert change.payload["initramfs_mechanism"] == "update-initramfs"


def test_alpha28_kernel_plan_blocks_when_rootfs_or_kernel_evidence_missing(qapp):
    page = BootHardwarePage()
    page.set_analysis({
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "kernel_images": ["/casper/vmlinuz"],
        "rootfs": [],
        "initramfs_mechanism": "update-initramfs",
    })
    assert not page.stage_kernel_btn.isEnabled()


def test_alpha28_source_switch_blocks_stale_kernel_plan(qapp):
    from chromapress.gui.main_window import MainWindow
    from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
    window = MainWindow()
    stale = ChangeItem(
        "Kernel / initramfs plan", ChangeKind.CONFIG, "test",
        {
            "config_type": "kernel_initramfs",
            "source_sha256": "a" * 64,
            "kernel_images": ["/casper/vmlinuz"],
            "initramfs_images": ["/casper/initrd"],
            "rootfs": ["/casper/minimal.standard.live.squashfs"],
            "initramfs_mechanism": "update-initramfs",
            "regenerate_initramfs": True,
            "protect_last_viable_kernel": True,
            "stage_only": True,
        },
    )
    window.project.changes.append(stale)
    window.changes.set_changes(window.project.changes)
    window._guard_boot_plan_source("b" * 64)
    assert stale.status == ChangeStatus.BLOCKED
    assert "Source changed" in stale.detail
    window.close()


def test_alpha28_all_main_pages_have_system_wide_scroll_fallback(qapp):
    from chromapress.gui.main_window import MainWindow, NAV
    from PySide6.QtWidgets import QScrollArea
    window = MainWindow()
    assert len(window.page_hosts) == len(NAV)
    assert all(isinstance(host, QScrollArea) and host.widgetResizable() for host in window.page_hosts)
    window.close()


def test_alpha28_boot_footer_is_compact_and_keeps_full_detail_in_tooltip(qapp):
    page = BootHardwarePage()
    page.set_analysis({
        "path": r"E:\ISO\lubuntu-26.04-desktop-amd64.iso",
        "sha256": "a" * 64,
    })
    assert "SOURCE READ-ONLY" in page.footer.text()
    assert "staging only" in page.footer.text()
    assert len(page.footer.text()) < 130
    assert r"E:\ISO\lubuntu-26.04-desktop-amd64.iso" in page.footer.toolTip()


def test_alpha28_boot_page_top_bottom_splitter_is_user_resizable(qapp):
    from PySide6.QtCore import Qt
    page = BootHardwarePage()
    assert page.section_splitter.orientation() == Qt.Orientation.Vertical
    assert page.section_splitter.count() == 2
    assert page.section_splitter.childrenCollapsible() is False
    assert page.structure.minimumHeight() >= 150
