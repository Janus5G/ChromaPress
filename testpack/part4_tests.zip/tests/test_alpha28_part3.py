from __future__ import annotations

from pathlib import Path

from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as preflight_change


def _kernel_plan(**overrides):
    payload = {
        "config_type": "kernel_initramfs",
        "source_sha256": "a" * 64,
        "kernel_images": ["/casper/vmlinuz"],
        "initramfs_images": ["/casper/initrd"],
        "rootfs": ["/casper/minimal.standard.live.squashfs"],
        "initramfs_mechanism": "update-initramfs",
        "regenerate_initramfs": True,
        "protect_last_viable_kernel": True,
        "preservation_policy": "preserve-unrelated",
        "stage_only": True,
    }
    payload.update(overrides)
    return ChangeItem("Kernel / initramfs plan", ChangeKind.CONFIG, "test", payload)


def test_alpha28_kernel_plan_is_hash_locked_last_kernel_protected_and_stage_only():
    status, message = preflight_change(_kernel_plan())
    assert status == ChangeStatus.PASS
    assert "source-hash locked" in message
    assert "last-kernel protected" in message
    assert "staging-only" in message


def test_alpha28_kernel_plan_blocks_missing_kernel_or_rootfs():
    assert preflight_change(_kernel_plan(kernel_images=[]))[0] == ChangeStatus.FAIL
    assert preflight_change(_kernel_plan(rootfs=[]))[0] == ChangeStatus.FAIL


def test_alpha28_kernel_plan_blocks_unknown_mechanism_and_disabling_kernel_protection():
    assert preflight_change(_kernel_plan(initramfs_mechanism="unknown"))[0] == ChangeStatus.FAIL
    assert preflight_change(_kernel_plan(protect_last_viable_kernel=False))[0] == ChangeStatus.FAIL


def test_alpha28_kernel_plan_must_remain_stage_only():
    assert preflight_change(_kernel_plan(stage_only=False))[0] == ChangeStatus.FAIL


def test_alpha28_release_notes_remain_present_after_later_alphas():
    root = Path(__file__).parents[1]
    notes = (root / "ALPHA28_NOTES.md").read_text(encoding="utf-8")
    assert "ChromaPress v1 Alpha 28" in notes
    assert "staging-only kernel/initramfs safety plan" in notes


def test_alpha28_gui_starts_maximized_and_keeps_read_only_contract_without_redundant_banner():
    root = Path(__file__).parents[1]
    app_source = (root / "src/chromapress/app.py").read_text(encoding="utf-8")
    page_source = (root / "src/chromapress/gui/boot_hardware_page.py").read_text(encoding="utf-8")
    assert "window.showMaximized()" in app_source
    assert "self.safety_text" in page_source
    assert "layout.addWidget(self.safety)" not in page_source
    assert "controls.setContentsMargins(0, 0, 0, 0)" in page_source
    assert "kernel_controls.setContentsMargins(0, 0, 0, 0)" in page_source
    assert "self.section_splitter = QSplitter(Qt.Orientation.Vertical)" in page_source
