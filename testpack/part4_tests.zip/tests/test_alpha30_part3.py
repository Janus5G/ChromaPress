from __future__ import annotations

from pathlib import Path

from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as preflight_change


def _rootfs_plan(**overrides):
    payload = {
        "config_type": "rootfs_squashfs",
        "source_sha256": "a" * 64,
        "layer_path": "/casper/minimal.standard.live.squashfs",
        "source_compression": "xz",
        "source_block_size": 131072,
        "operation": "repack",
        "target_compression": "xz",
        "preserve_block_size": True,
        "require_unsquashfs_verification": True,
        "require_mksquashfs_verification": True,
        "preserve_unrelated": True,
        "source_read_only": True,
        "stage_only": True,
    }
    payload.update(overrides)
    return ChangeItem("Rootfs / SquashFS plan", ChangeKind.CONFIG, "test", payload)


def test_alpha30_rootfs_plan_is_hash_locked_explicit_layer_bound_and_stage_only():
    status, message = preflight_change(_rootfs_plan())
    assert status == ChangeStatus.PASS
    assert "source-hash locked" in message
    assert "explicit-layer" in message
    assert "staging-only" in message


def test_alpha30_rootfs_plan_requires_detected_squashfs_and_supported_compression():
    assert preflight_change(_rootfs_plan(layer_path="/casper/not-rootfs.img"))[0] == ChangeStatus.FAIL
    assert preflight_change(_rootfs_plan(source_compression="unknown"))[0] == ChangeStatus.FAIL
    assert preflight_change(_rootfs_plan(target_compression="brotli"))[0] == ChangeStatus.FAIL


def test_alpha30_rootfs_plan_requires_tool_and_preservation_gates():
    assert preflight_change(_rootfs_plan(require_unsquashfs_verification=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_rootfs_plan(require_mksquashfs_verification=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_rootfs_plan(preserve_unrelated=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_rootfs_plan(source_read_only=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_rootfs_plan(preserve_block_size=False))[0] == ChangeStatus.FAIL


def test_alpha30_rootfs_plan_requires_repack_and_stage_only():
    assert preflight_change(_rootfs_plan(operation="preserve"))[0] == ChangeStatus.FAIL
    assert preflight_change(_rootfs_plan(stage_only=False))[0] == ChangeStatus.FAIL


def test_alpha30_version_markers_are_consistent():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
    main_window = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert 'QLabel(__version__)' in main_window
    assert 'v1 alpha 37' not in main_window
