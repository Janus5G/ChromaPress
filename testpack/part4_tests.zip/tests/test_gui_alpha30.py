from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.boot_hardware_page import BootHardwarePage
from chromapress.models import ChangeKind, ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis():
    return {
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "rootfs": ["/casper/minimal.standard.live.squashfs"],
        "rootfs_details": [{
            "path": "/casper/minimal.standard.live.squashfs",
            "compression": "xz",
            "block_size": 131072,
        }],
    }


def test_alpha30_rootfs_plan_lists_detected_layer_and_compression(qapp):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    assert page.stage_rootfs_btn.isEnabled()
    assert page.rootfs_layer_combo.count() == 2
    page.rootfs_layer_combo.setCurrentIndex(1)
    assert "xz" in page.rootfs_current_compression_value.text()
    assert "131072" in page.rootfs_current_compression_value.text()


def test_alpha30_rootfs_plan_stages_preservation_first(qapp, monkeypatch):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.boot_hardware_page.QMessageBox.information", lambda *a, **k: None)
    page.rootfs_layer_combo.setCurrentIndex(1)
    page.rootfs_action_combo.setCurrentIndex(1)
    page.stage_rootfs_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "rootfs_squashfs"
    assert change.payload["source_read_only"] is True
    assert change.payload["preserve_unrelated"] is True
    assert change.payload["preserve_block_size"] is True
    assert change.payload["stage_only"] is True


def test_alpha30_rootfs_plan_blocks_unknown_source_compression(qapp, monkeypatch):
    page = BootHardwarePage()
    data = _analysis(); data["rootfs_details"][0]["compression"] = "unknown"
    page.set_analysis(data)
    emitted = []
    shown = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.boot_hardware_page.QMessageBox.information", lambda *a, **k: shown.append(a))
    page.rootfs_layer_combo.setCurrentIndex(1)
    page.rootfs_action_combo.setCurrentIndex(1)
    page.stage_rootfs_btn.click()
    assert emitted == []
    assert "BLOCKED" in page.rootfs_plan_status.text()
    assert shown


def test_alpha30_source_switch_blocks_stale_rootfs_plan(qapp):
    from chromapress.gui.main_window import MainWindow
    from chromapress.models import ChangeItem
    window = MainWindow()
    change = ChangeItem("Rootfs / SquashFS plan", ChangeKind.CONFIG, "test", {
        "config_type": "rootfs_squashfs",
        "source_sha256": "a" * 64,
        "layer_path": "/casper/minimal.squashfs",
        "source_compression": "xz",
        "operation": "repack",
        "target_compression": "xz",
        "preserve_block_size": True,
        "require_unsquashfs_verification": True,
        "require_mksquashfs_verification": True,
        "preserve_unrelated": True,
        "source_read_only": True,
        "stage_only": True,
    })
    window.project.changes.append(change)
    window.changes.set_changes(window.project.changes)
    window._guard_boot_plan_source("b" * 64)
    assert change.status == ChangeStatus.BLOCKED
    window.close()
