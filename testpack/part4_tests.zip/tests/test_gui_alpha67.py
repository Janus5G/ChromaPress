import os; os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
import pytest; pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication,QMessageBox
from chromapress.gui.system_page import SystemPage
@pytest.fixture(scope="module")
def qapp(): return QApplication.instance() or QApplication([])
def test_alpha67_static_iso_gui_fails_closed(qapp,monkeypatch):
    monkeypatch.setattr(QMessageBox,"information",lambda *a,**k:None)
    a={"sha256":"a"*64,"system_admin_recovery_policy_evidence":{"gate_version":"alpha62","verified":True},"system_platform_authenticator_policy_evidence":{"gate_version":"alpha67","capability_status":"UNKNOWN","verified":False,"platform_authenticator_runtime_verified":False,"platform_authenticator_hardware_verified":False,"reason":"UNKNOWN — runtime/hardware required"}}
    p=SystemPage(); p.set_analysis(a); out=[]; p.stage_requested.connect(out.append); p.platform_auth_operation.setCurrentIndex(p.platform_auth_operation.findData("allow_verified_platform_authenticator_for_recovery_workflows")); p.platform_auth_username.setText("recovery67"); p.stage_platform_auth_btn.click(); assert out==[] and "UNKNOWN" in p.platform_auth_plan_status.text()
