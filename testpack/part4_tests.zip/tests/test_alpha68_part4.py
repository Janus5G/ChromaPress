from pathlib import Path
import pytest
from chromapress.engine_cli import _system_tpm_key_protection_evidence
from chromapress.models import ChangeItem,ChangeKind,ChangeStatus,SourceState
from chromapress.services.preflight import test_change as run_preflight
from chromapress_acceptance import AcceptanceRunner

def _admin(): return {"gate_version":"alpha62","capability_status":"SUPPORTED_WITH_REQUIREMENTS","verified":True,"existing_admin_users":["liveadmin"],"autologin_user":"kiosk","shadow_read":False,"credential_secret_read":False,"recovery_secret_read":False,"pam_contents_read":False,"ssh_config_read":False,"rescue_boot_config_read":False,"root_account_policy_read":False,"host_accounts_touched":False,"host_login_state_accessed":False}
def _e(tools=True,tss=True):
    v={"base-files":"1"}
    if tools:v["tpm2-tools"]="5.7"
    if tss:v["libtss2-esys-3.0.2-0"]="4.0"
    return _system_tpm_key_protection_evidence("deb",v,_admin())
def _payload(e=None):
    e=dict(e or _e()); return {"config_type":"tpm_key_protection","gate_version":"alpha68","source_sha256":"a"*64,"analysis_scope":"target_iso_package_manifest","capability_status":e.get("capability_status"),"tpm_key_protection_verified":e.get("verified") is True,"operation":"require_tpm_backed_recovery_key_protection","policy_scope":"recovery_administrator_tpm_backed_key_protection","username":"liveadmin","current_autologin_user":"kiosk","administrator_recovery_dependency":"alpha62_administrator_recovery_policy","alpha62_dependency_verified":e.get("alpha62_dependency_verified") is True,"tpm_tool_packages":list(e.get("tpm_tool_packages") or []),"tss_packages":list(e.get("tss_packages") or []),"tpm_hardware_enumerated":False,"tpm_hardware_verified":False,"tpm_presence_claimed":False,"tpm_ownership_state_read":False,"pcr_values_read":False,"key_material_generated":False,"key_material_read":False,"key_material_staged":False,"key_material_sealed":False,"credential_secret_read":False,"credential_secret_staged":False,"biometric_capability_claimed":False,"platform_authenticator_claimed":False,"host_tpm_state_accessed":False,"preserve_existing_primary_authentication":True,"require_tpm_hardware_verification_before_apply":True,"require_tpm_ownership_verification_before_apply":True,"require_pcr_policy_review_before_sealing":True,"require_key_generation_and_sealing_only_at_verified_apply":True,"require_recovery_username_reverification_before_apply":True,"require_target_package_reverification_before_apply":True,"source_read_only":True,"preserve_unrelated":True,"stage_only":True}
def _run(p): return run_preflight(ChangeItem("TPM key-protection",ChangeKind.CONFIG,"test",p))
def test_alpha68_supported_package_stack_is_requirements_only():
    e=_e(); assert e["capability_status"]=="SUPPORTED_WITH_REQUIREMENTS" and e["verified"] is True and e["tpm_hardware_verified"] is False and e["biometric_capability_claimed"] is False
def test_alpha68_missing_tools_or_tss_unknown(): assert _e(False,True)["capability_status"]=="UNKNOWN" and _e(True,False)["capability_status"]=="UNKNOWN"
def test_alpha68_supported_preflight_passes(): assert _run(_payload())[0]==ChangeStatus.PASS
@pytest.mark.parametrize("key",["tpm_hardware_enumerated","tpm_hardware_verified","tpm_presence_claimed","tpm_ownership_state_read","pcr_values_read","key_material_generated","key_material_read","key_material_staged","key_material_sealed","credential_secret_read","credential_secret_staged","biometric_capability_claimed","platform_authenticator_claimed","host_tpm_state_accessed"])
def test_alpha68_protected_claims_fail(key):
    p=_payload(); p[key]=True; assert _run(p)[0]==ChangeStatus.FAIL, key
def test_alpha68_unknown_fails_closed():
    e=_e(); e["capability_status"]="UNKNOWN"; e["verified"]=False; assert _run(_payload(e))[0]==ChangeStatus.FAIL
def test_alpha68_acceptance(tmp_path):
    r=AcceptanceRunner(tmp_path,4,None,None,tmp_path/'r'); r._add_alpha68_tpm_gate(_e(),_admin(),"a"*64); assert r.checks[-1].status=="PASS"
def test_alpha68_source_state_persists_complete_part4_evidence():
    fields=SourceState.__dataclass_fields__
    for name in ("system_network_restriction_evidence","system_firewall_rules_evidence","system_persistence_policy_evidence","system_admin_recovery_policy_evidence","system_fido2_policy_evidence","system_webauthn_policy_evidence","system_security_key_policy_evidence","system_yubikey_policy_evidence","system_platform_authenticator_policy_evidence","system_tpm_key_protection_evidence"):
        assert name in fields
def test_alpha68_version_source_guard_and_part4_completion_markers():
    root=Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root/'pyproject.toml').read_text()
    text=(root/'src/chromapress/gui/main_window.py').read_text(); assert '"tpm_key_protection"' in text
