from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_autologin_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _good_payload() -> dict:
    return {
        "config_type": "system_autologin",
        "source_sha256": "c" * 64,
        "operation": "enable_autologin",
        "target_user": "chromatest",
        "display_manager": "sddm",
        "display_manager_layer": "/casper/minimal.standard.squashfs",
        "current_autologin_state": "no explicit autologin directive found",
        "current_autologin_user": "",
        "rootfs_autologin_verified": True,
        "credential_secret_read": False,
        "credential_secret_staged": False,
        "require_target_user_verification_before_apply": True,
        "session_policy": "preserve_current_or_default_session",
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def test_alpha39_autologin_evidence_detects_sddm_without_secrets(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"not-read-by-test")
    layers = ["/casper/minimal.standard.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (4096, 1234)})

    def fake_read(_iso: Path, _layers: list[str], member: str, _extents):
        if member == "/etc/X11/default-display-manager":
            return "/usr/bin/sddm\n", layers[0]
        if member == "/etc/sddm.conf.d/autologin.conf":
            return "[Autologin]\nUser=lubuntu\nSession=Lubuntu\n", layers[0]
        return "", ""

    monkeypatch.setattr("chromapress.engine_cli._read_squashfs_overlay_text", fake_read)
    evidence = _system_autologin_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["display_manager"] == "sddm"
    assert evidence["autologin_state"] == "enabled explicitly"
    assert evidence["autologin_user"] == "lubuntu"
    assert evidence["credential_secret_read"] is False
    assert "password" not in str(evidence).casefold()


def test_alpha39_autologin_preflight_passes_with_verified_sddm():
    status, message = run_preflight(
        ChangeItem("Autologin / display manager plan", ChangeKind.CONFIG, "test", _good_payload())
    )
    assert status == ChangeStatus.PASS
    assert "display-manager-evidence bound" in message
    assert "credential-secret free" in message


def test_alpha39_autologin_preflight_rejects_bad_user_or_secret():
    payload = _good_payload()
    payload["target_user"] = "Bad User!"
    status, _ = run_preflight(ChangeItem("Autologin", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL

    payload = _good_payload()
    payload["credential_secret_staged"] = True
    status, _ = run_preflight(ChangeItem("Autologin", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL


def test_alpha39_disable_autologin_stages_no_target_user():
    payload = _good_payload()
    payload.update({
        "operation": "disable_autologin",
        "target_user": "",
        "require_target_user_verification_before_apply": False,
    })
    status, _ = run_preflight(ChangeItem("Autologin", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.PASS
