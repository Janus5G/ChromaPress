from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _security(capability="SUPPORTED_WITH_REQUIREMENTS"):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha53",
        "analysis_scope": "target_iso_rootfs",
        "capability_status": capability,
        "verified": supported,
        "backend": "shadow-utils-login.defs" if supported else "",
        "config_path": "/etc/login.defs",
        "config_layer": "/casper/minimal.squashfs" if supported else "",
        "current_umask": "022",
        "umask_directive_present": True,
        "usergroups_enab": "yes",
        "metadata_keys_read": ["UMASK", "USERGROUPS_ENAB"],
        "supported_umasks": ["022", "027", "077"] if supported else [],
        "supported_operations": ["set_default_umask"] if supported else [],
        "full_config_exposed": False,
        "credential_secret_read": False,
        "host_security_state_accessed": False,
        "source_read_only": True,
        "reason": f"{capability} — test evidence",
    }


def _analysis(capability="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_security_defaults_evidence": _security(capability),
    }


def _quiet(monkeypatch):
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.changes.QMessageBox.information", lambda *a, **k: None)


def test_alpha53_umask_controls_are_narrow_and_allowlisted(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.security_defaults_operation.findData("set_default_umask") >= 0
    values = {str(page.security_defaults_umask.itemData(i)) for i in range(page.security_defaults_umask.count())}
    assert values == {"022", "027", "077"}


def test_alpha53_changes_test_and_undo(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.security_defaults_operation.setCurrentIndex(page.security_defaults_operation.findData("set_default_umask"))
    page.security_defaults_umask.setCurrentIndex(page.security_defaults_umask.findData("027"))
    page.stage_security_defaults_btn.click()
    assert len(emitted) == 1
    assert emitted[0].payload["target_umask"] == "027"
    assert emitted[0].payload["host_security_state_accessed"] is False
    assert emitted[0].payload["preserve_pam_configuration"] is True

    changes = ChangesPanel()
    changes.set_changes([])
    changes.add_change(emitted[0])
    changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == []


def test_alpha53_unknown_gui_staging_fails_closed(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis("UNKNOWN"))
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.security_defaults_operation.setCurrentIndex(page.security_defaults_operation.findData("set_default_umask"))
    page.stage_security_defaults_btn.click()
    assert emitted == []
