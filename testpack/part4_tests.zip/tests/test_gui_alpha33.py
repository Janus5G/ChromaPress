from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.boot_hardware_page import BootHardwarePage
from chromapress.models import ChangeKind, ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis():
    return {
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "kernel_images": ["/casper/vmlinuz"],
        "initramfs_images": ["/casper/initrd"],
        "rootfs": ["/casper/minimal.squashfs"],
        "rootfs_details": [{"path": "/casper/minimal.squashfs", "compression": "xz", "block_size": 131072}],
        "initramfs_mechanism": "update-initramfs",
    }


def test_alpha33_integration_controls_bind_detected_evidence(qapp):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    assert page.stage_integration_btn.isEnabled()
    assert page.integration_layer_combo.count() == 2
    text = page.integration_evidence_value.text().lower()
    assert "1 boot config" in text and "1 kernel" in text and "1 initramfs" in text


def test_alpha33_controlled_integration_stages(qapp, monkeypatch):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.boot_hardware_page.QMessageBox.information", lambda *a, **k: None)
    page.integration_layer_combo.setCurrentIndex(1)
    page.integration_target_combo.setCurrentIndex(2)
    page.stage_integration_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "runtime_integration"
    assert change.payload["boot_config_files"] == ["/boot/grub/grub.cfg"]
    assert change.payload["kernel_images"] == ["/casper/vmlinuz"]
    assert change.payload["initramfs_images"] == ["/casper/initrd"]
    assert change.payload["mount_policy"] == "resolve_label_or_uuid_before_persistent_binds"
    assert change.payload["source_read_only"] is True
    assert change.payload["stage_only"] is True


def test_alpha33_target_changes_mount_semantics(qapp):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    page.integration_target_combo.setCurrentIndex(1)
    assert "no persistent mount" in page.integration_mount_value.text().lower()
    page.integration_target_combo.setCurrentIndex(2)
    assert "label/uuid" in page.integration_mount_value.text().lower()


def test_alpha33_source_switch_blocks_stale_integration_plan(qapp):
    from chromapress.gui.main_window import MainWindow
    from chromapress.models import ChangeItem
    window = MainWindow()
    change = ChangeItem("Runtime integration verification plan", ChangeKind.CONFIG, "test", {
        "config_type": "runtime_integration",
        "source_sha256": "a" * 64,
    })
    window.project.changes.append(change)
    window.changes.set_changes(window.project.changes)
    window._guard_boot_plan_source("b" * 64)
    assert change.status == ChangeStatus.BLOCKED
    window.close()
