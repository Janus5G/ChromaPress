from pathlib import Path

import pytest

from chromapress.engine_cli import _system_fido2_policy_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight
from chromapress_acceptance import AcceptanceRunner


def _admin(cap="SUPPORTED_WITH_REQUIREMENTS"):
    supported = cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha62",
        "analysis_scope": "target_iso_rootfs",
        "capability_status": cap,
        "verified": supported,
        "existing_admin_users": ["liveadmin"] if supported else [],
        "existing_regular_users": ["liveadmin", "student"] if supported else [],
        "autologin_user": "kiosk" if supported else "",
        "shadow_read": False,
        "credential_secret_read": False,
        "recovery_secret_read": False,
        "pam_contents_read": False,
        "ssh_config_read": False,
        "rescue_boot_config_read": False,
        "root_account_policy_read": False,
        "host_accounts_touched": False,
        "host_login_state_accessed": False,
        "source_read_only": True,
    }


def _versions(*, pam=True, lib=True, tools=True):
    d = {"base-files": "1"}
    if pam:
        d["libpam-u2f"] = "1.3.0"
    if lib:
        d["libfido2-1"] = "1.15.0"
    if tools:
        d["fido2-tools"] = "1.15.0"
    return d


def _supported():
    return _system_fido2_policy_evidence("deb", _versions(), _admin())


def _payload(e=None, *, username="recovery63"):
    e = dict(e or _supported())
    return {
        "config_type": "fido2_policy",
        "gate_version": "alpha63",
        "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_package_manifest",
        "capability_status": e.get("capability_status", "UNKNOWN"),
        "fido2_policy_verified": e.get("verified") is True,
        "operation": "require_fido2_second_factor_for_recovery_admin",
        "policy_scope": "recovery_administrator_fido2_second_factor",
        "username": username,
        "current_autologin_user": "kiosk",
        "administrator_recovery_dependency": "alpha62_administrator_recovery_policy",
        "alpha62_dependency_verified": e.get("alpha62_dependency_verified") is True,
        "pam_fido2_packages": list(e.get("pam_fido2_packages") or []),
        "libfido2_packages": list(e.get("libfido2_packages") or []),
        "fido2_tool_packages": list(e.get("fido2_tool_packages") or []),
        "authentication_composition": "existing_primary_plus_fido2_second_factor",
        "pam_contents_read": False,
        "pam_contents_modified_during_analysis": False,
        "authenticator_devices_enumerated": False,
        "usb_hid_state_accessed": False,
        "credential_ids_read": False,
        "credential_secret_read": False,
        "credential_secret_staged": False,
        "authenticator_enrollment_performed": False,
        "webauthn_capability_claimed": False,
        "security_key_presence_claimed": False,
        "yubikey_capability_claimed": False,
        "platform_authenticator_claimed": False,
        "tpm_capability_claimed": False,
        "host_authenticator_state_accessed": False,
        "preserve_existing_primary_authentication": True,
        "preserve_pam_contents_during_analysis_and_staging": True,
        "require_pam_integration_verification_before_apply": True,
        "require_alpha62_dependency_before_apply": True,
        "require_alpha62_dependency_reverification_before_apply": True,
        "require_target_package_reverification_before_apply": True,
        "require_recovery_username_reverification_before_apply": True,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("FIDO2 policy plan", ChangeKind.CONFIG, "test", payload))


def test_alpha63_supported_manifest_evidence_is_requirements_only():
    e = _supported()
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert e["verified"] is True
    assert e["pam_fido2_packages"] == ["libpam-u2f"]
    assert e["libfido2_packages"] == ["libfido2-1"]
    assert e["fido2_tool_packages"] == ["fido2-tools"]
    assert e["supported_operations"] == ["require_fido2_second_factor_for_recovery_admin"]
    assert e["alpha62_dependency_verified"] is True


def test_alpha63_missing_pam_module_is_unknown_not_guessed():
    e = _system_fido2_policy_evidence("deb", _versions(pam=False), _admin())
    assert e["capability_status"] == "UNKNOWN"
    assert e["verified"] is False


def test_alpha63_missing_libfido2_is_unknown_not_guessed():
    e = _system_fido2_policy_evidence("deb", _versions(lib=False), _admin())
    assert e["capability_status"] == "UNKNOWN"
    assert e["verified"] is False


def test_alpha63_unverified_alpha62_dependency_is_unknown():
    e = _system_fido2_policy_evidence("deb", _versions(), _admin("UNKNOWN"))
    assert e["capability_status"] == "UNKNOWN"
    assert e["verified"] is False


def test_alpha63_privacy_unsafe_alpha62_dependency_blocks():
    a = _admin(); a["pam_contents_read"] = True
    e = _system_fido2_policy_evidence("deb", _versions(), a)
    assert e["capability_status"] == "BLOCKED"


def test_alpha63_supported_preflight_passes():
    status, message = _run(_payload())
    assert status == ChangeStatus.PASS
    assert "Alpha 62 recovery-role dependent" in message


@pytest.mark.parametrize("cap", ["UNKNOWN", "BLOCKED", "UNSUPPORTED"])
def test_alpha63_unverified_capability_fails_closed(cap):
    e = _supported(); e["capability_status"] = cap; e["verified"] = False
    assert _run(_payload(e))[0] == ChangeStatus.FAIL


def test_alpha63_root_and_autologin_users_are_blocked():
    assert _run(_payload(username="root"))[0] == ChangeStatus.FAIL
    assert _run(_payload(username="kiosk"))[0] == ChangeStatus.FAIL


def test_alpha63_missing_package_evidence_is_blocked():
    p = _payload(); p["pam_fido2_packages"] = []
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["libfido2_packages"] = []
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha63_rejects_device_secret_enrollment_or_later_gate_claims():
    for key in (
        "pam_contents_read", "pam_contents_modified_during_analysis", "authenticator_devices_enumerated",
        "usb_hid_state_accessed", "credential_ids_read", "credential_secret_read", "credential_secret_staged",
        "authenticator_enrollment_performed", "webauthn_capability_claimed", "security_key_presence_claimed",
        "yubikey_capability_claimed", "platform_authenticator_claimed", "tpm_capability_claimed",
        "host_authenticator_state_accessed",
    ):
        p = _payload(); p[key] = True
        assert _run(p)[0] == ChangeStatus.FAIL, key


def test_alpha63_rejects_missing_dependencies_and_preservation():
    p = _payload(); p["administrator_recovery_dependency"] = "none"
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["alpha62_dependency_verified"] = False
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["authentication_composition"] = "fido2_only"
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["preserve_existing_primary_authentication"] = False
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha63_acceptance_supported_and_unknown(tmp_path):
    runner = AcceptanceRunner(tmp_path, 4, None, None, tmp_path / "reports")
    e = _supported(); a = _admin()
    runner._add_alpha63_fido2_policy_gate(e, a, "a" * 64)
    assert runner.checks[-1].status == "PASS"
    e["capability_status"] = "UNKNOWN"; e["verified"] = False
    runner._add_alpha63_fido2_policy_gate(e, a, "a" * 64)
    assert runner.checks[-1].status == "PASS"


def test_alpha63_version_markers():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")


def test_alpha63_part4_source_guard_includes_fido2_policy():
    root = Path(__file__).resolve().parents[1]
    text = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert '"fido2_policy"' in text
