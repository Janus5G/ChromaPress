from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.installer_page import InstallerPage


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def test_alpha35_installer_page_shows_evidence_backed_family(qapp):
    page = InstallerPage()
    page.set_analysis({
        "sha256": "a" * 64,
        "installer": "Calamares",
        "installer_evidence": [{"kind": "package", "value": "calamares", "version": "3.3.14", "family": "Calamares"}],
        "installer_config_files": [],
        "installer_modes": ["Interactive installer", "Calamares configuration requires rootfs-level verification before editing"],
    })
    assert page.family_value.text() == "Calamares"
    assert "READ-ONLY PASS" in page.status.text()
    assert page.evidence_tree.topLevelItemCount() == 1


def test_alpha35_unknown_installer_is_visibly_blocked(qapp):
    page = InstallerPage()
    page.set_analysis({"sha256": "b" * 64, "installer": "unknown"})
    assert "BLOCKED" in page.status.text()
