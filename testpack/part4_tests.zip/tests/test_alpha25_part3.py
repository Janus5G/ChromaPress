from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _boot_source_metadata
from chromapress.models import SourceState


def test_alpha25_boot_metadata_is_conservative_and_evidence_based():
    files = [
        "/boot/grub/grub.cfg",
        "/EFI/BOOT/BOOTX64.EFI",
        "/casper/vmlinuz",
        "/casper/initrd",
        "/casper/minimal.squashfs",
        "/boot.catalog",
    ]
    data = _boot_source_metadata(
        files,
        "El Torito boot img : 1  BIOS\nEl Torito boot img : 2  UEFI",
        "System area summary: MBR isohybrid GPT",
    )
    assert data["bios_boot"] is True
    assert data["uefi_boot"] is True
    assert data["el_torito_boot"] is True
    assert data["hybrid_boot"] is True
    assert data["bootloaders"] == ["GRUB"]
    assert data["boot_catalog"] == "/boot.catalog"
    assert data["boot_config_files"] == ["/boot/grub/grub.cfg"]
    assert data["efi_images"] == ["/EFI/BOOT/BOOTX64.EFI"]
    assert data["kernel_images"] == ["/casper/vmlinuz"]
    assert data["initramfs_images"] == ["/casper/initrd"]


def test_alpha25_source_state_persists_part3_read_only_evidence():
    state = SourceState(
        path="sample.iso",
        bios_boot=True,
        uefi_boot=True,
        el_torito_boot=True,
        hybrid_boot=True,
        bootloaders=["GRUB"],
        kernel_images=["/casper/vmlinuz"],
        initramfs_images=["/casper/initrd"],
        rootfs=["/casper/minimal.squashfs"],
        rootfs_details=[{"path": "/casper/minimal.squashfs", "compression": "xz"}],
    )
    assert state.bootloaders == ["GRUB"]
    assert state.rootfs_details[0]["compression"] == "xz"


def test_alpha25_boot_hardware_page_replaces_placeholder():
    root = Path(__file__).parents[1]
    main = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert 'PlaceholderPage("Boot & Hardware"' not in main
    assert "BootHardwarePage" in main


def test_alpha25_source_read_only_safety_remains_after_later_staging_controls():
    root = Path(__file__).parents[1]
    source = (root / "src/chromapress/gui/boot_hardware_page.py").read_text(encoding="utf-8")
    assert "SOURCE READ-ONLY" in source
    assert "no source-image bytes are changed" in source
