from __future__ import annotations

import hashlib
from pathlib import Path

from chromapress.engine_cli import _classify_selinux_capability, _system_selinux_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _payload(mode: str = "permissive") -> dict:
    return {
        "config_type": "system_selinux",
        "gate_version": "alpha52",
        "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_rootfs",
        "operation": "set_selinux_mode",
        "target_mode": mode,
        "configured_mode": "disabled",
        "capability_status": "SUPPORTED_WITH_REQUIREMENTS",
        "rootfs_selinux_verified": True,
        "config_path": "/etc/selinux/config",
        "config_layer": "/casper/minimal.squashfs",
        "config_metadata_read": True,
        "config_creation_required": False,
        "policy_type": "targeted",
        "policy_tree_present": True,
        "policy_entries": ["targeted", "local-custom"],
        "policy_contents_read": False,
        "preserve_existing_policies": True,
        "custom_policy_preserved": True,
        "package_manager": "apt",
        "package_manager_path": "/usr/bin/apt-get",
        "repository_metadata_path": "/etc/apt/sources.list.d",
        "package_install_required": False,
        "required_packages": [],
        "require_signed_repository_metadata": True,
        "require_dependency_resolution": True,
        "package_requirements_staged": False,
        "kernel_support_status": "SUPPORTED",
        "kernel_config_path": "/boot/config-test",
        "kernel_images": ["/casper/vmlinuz"],
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "initramfs_mechanism": "update-initramfs",
        "part3_dependency_required": True,
        "part3_requirements": [
            {"model": "part3_kernel_initramfs", "action": "verify_and_regenerate_if_required", "initramfs_mechanism": "update-initramfs"},
            {"model": "part3_boot", "action": "verify_selinux_boot_parameters", "boot_config_files": ["/boot/grub/grub.cfg"], "forbid_parameters": ["selinux=0"]},
        ],
        "dependencies_visible": True,
        "dependencies_staged": True,
        "delegate_boot_kernel_to_part3": True,
        "direct_boot_mutation": False,
        "direct_kernel_mutation": False,
        "direct_initramfs_mutation": False,
        "relabel_required": True,
        "relabel_before_enforcing": mode == "enforcing",
        "reboot_required": True,
        "require_post_boot_verification": True,
        "host_selinux_accessed": False,
        "host_security_state_accessed": False,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def _run(payload: dict):
    return run_preflight(ChangeItem("SELinux plan", ChangeKind.CONFIG, "test", payload))


def _mock_probe(monkeypatch, present: set[str], config_text: str = "", kernel_text: str = ""):
    layer = "/casper/minimal.squashfs"
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: "/usr/bin/unsquashfs" if name == "unsquashfs" else None)
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layer: (4096, 100)})
    monkeypatch.setattr(
        "chromapress.engine_cli._inspect_overlay_member_presence",
        lambda _iso, _layers, member, _extents=None: (member in present, layer if member in present else ""),
    )

    def list_entries(_iso, _layers, directory, _extents=None):
        if directory == "/etc/selinux" and "/etc/selinux" in present:
            return ["config", "targeted", "local-custom"], layer
        if directory == "/boot" and kernel_text:
            return ["config-test"], layer
        return [], ""

    def read_text(_iso, _layers, relative_path, _extents=None):
        if relative_path == "/etc/selinux/config" and config_text:
            return config_text, layer
        if relative_path == "/boot/config-test" and kernel_text:
            return kernel_text, layer
        return "", ""

    monkeypatch.setattr("chromapress.engine_cli._list_overlay_directory_entries", list_entries)
    monkeypatch.setattr("chromapress.engine_cli._read_squashfs_overlay_text", read_text)
    return layer


def test_alpha52_selinux_present_enforcing_detection_is_target_only(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"alpha52-source")
    before = hashlib.sha256(iso.read_bytes()).hexdigest()
    present = {
        "/etc/selinux/config", "/etc/selinux", "/usr/sbin/getenforce", "/usr/sbin/setenforce",
        "/usr/sbin/load_policy", "/usr/sbin/restorecon", "/usr/bin/apt-get", "/etc/apt/sources.list.d",
    }
    _mock_probe(monkeypatch, present, "SELINUX=enforcing\nSELINUXTYPE=targeted\n", "CONFIG_SECURITY_SELINUX=y\n")
    evidence = _system_selinux_rootfs_evidence(
        iso, ["/casper/minimal.squashfs"], package_format="deb",
        manifest_versions={"selinux-basics": "1", "policycoreutils": "1"},
        iso_files=[], kernel_images=["/casper/vmlinuz"], boot_config_files=["/boot/grub/grub.cfg"],
        initramfs_mechanism="update-initramfs",
    )
    assert hashlib.sha256(iso.read_bytes()).hexdigest() == before
    assert evidence["gate_version"] == "alpha52"
    assert evidence["analysis_scope"] == "target_iso_rootfs"
    assert evidence["capability_status"] == "SUPPORTED"
    assert evidence["configured_mode"] == "enforcing"
    assert evidence["policy_type"] == "targeted"
    assert evidence["kernel_support_status"] == "SUPPORTED"
    assert evidence["host_selinux_accessed"] is False
    assert evidence["policy_contents_read"] is False
    assert evidence["custom_policy_preserved"] is True
    assert "local-custom" in evidence["policy_entries"]
    assert evidence["source_read_only"] is True


def test_alpha52_installed_but_disabled_is_supported_with_requirements(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    present = {"/etc/selinux/config", "/etc/selinux", "/usr/sbin/setenforce", "/usr/sbin/restorecon"}
    _mock_probe(monkeypatch, present, "SELINUX=disabled\nSELINUXTYPE=targeted\n", "CONFIG_SECURITY_SELINUX=y\n")
    evidence = _system_selinux_rootfs_evidence(
        iso, ["/casper/minimal.squashfs"], package_format="deb",
        manifest_versions={"selinux-basics": "1"}, initramfs_mechanism="update-initramfs",
    )
    assert evidence["installed_present"] is True
    assert evidence["configured_mode"] == "disabled"
    assert evidence["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["relabel_required_on_enable"] is True
    assert evidence["reboot_required"] is True


def test_alpha52_missing_but_iso_packages_and_target_manager_are_addable(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    present = {"/usr/bin/apt-get", "/etc/apt/sources.list.d"}
    _mock_probe(monkeypatch, present, kernel_text="CONFIG_SECURITY_SELINUX=y\n")
    evidence = _system_selinux_rootfs_evidence(
        iso, ["/casper/minimal.squashfs"], package_format="deb", manifest_versions={},
        iso_files=["/pool/s/selinux-basics_1.0_all.deb", "/pool/p/policycoreutils_3.0_amd64.deb"],
        kernel_images=["/casper/vmlinuz"], boot_config_files=["/boot/grub/grub.cfg"],
        initramfs_mechanism="update-initramfs",
    )
    assert evidence["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert evidence["package_mechanism_verified"] is True
    assert evidence["package_install_required"] is True
    assert len(evidence["required_packages"]) == 2
    assert any(x.get("model") == "part2_packages" for x in evidence["part3_requirements"])


def test_alpha52_unknown_state_is_unknown_not_unsupported(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    _mock_probe(monkeypatch, set())
    evidence = _system_selinux_rootfs_evidence(iso, ["/casper/minimal.squashfs"], package_format="unknown")
    assert evidence["capability_status"] == "UNKNOWN"
    assert evidence["verified"] is False
    assert evidence["host_security_state_accessed"] is False


def test_alpha52_genuinely_unsupported_requires_positive_negative_evidence():
    assert _classify_selinux_capability(
        components_present=False, config_mode="", package_mechanism_verified=False,
        packages_available_on_iso=False, kernel_support_status="UNSUPPORTED",
    ) == "UNSUPPORTED"
    assert _classify_selinux_capability(
        components_present=False, config_mode="", package_mechanism_verified=False,
        packages_available_on_iso=False, kernel_support_status="UNKNOWN",
    ) == "UNKNOWN"


def test_alpha52_enforcing_and_permissive_staging_pass():
    for mode in ("enforcing", "permissive"):
        status, message = _run(_payload(mode))
        assert status == ChangeStatus.PASS, message
        assert "Part-3 delegated" in message


def test_alpha52_dependencies_are_explicit_and_boot_changes_are_part3_delegated():
    payload = _payload("permissive")
    assert payload["dependencies_visible"] is True
    assert payload["dependencies_staged"] is True
    assert payload["delegate_boot_kernel_to_part3"] is True
    assert payload["direct_boot_mutation"] is False
    assert payload["direct_kernel_mutation"] is False
    assert any(x["model"] == "part3_boot" for x in payload["part3_requirements"])
    assert _run(payload)[0] == ChangeStatus.PASS


def test_alpha52_direct_boot_manipulation_is_rejected():
    payload = _payload()
    payload["kernel_args_append"] = "selinux=1"
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload()
    payload["direct_boot_mutation"] = True
    assert _run(payload)[0] == ChangeStatus.FAIL


def test_alpha52_unknown_blocked_and_unsupported_fail_closed():
    for capability in ("UNKNOWN", "BLOCKED", "UNSUPPORTED"):
        payload = _payload()
        payload["capability_status"] = capability
        assert _run(payload)[0] == ChangeStatus.FAIL


def test_alpha52_custom_policy_and_host_isolation_are_enforced():
    payload = _payload()
    payload["preserve_existing_policies"] = False
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload()
    payload["policy_contents_read"] = True
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload()
    payload["host_selinux_accessed"] = True
    assert _run(payload)[0] == ChangeStatus.FAIL


def test_alpha52_relabel_and_reboot_requirements_are_enforced():
    payload = _payload("permissive")
    payload["relabel_required"] = False
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload("enforcing")
    payload["relabel_before_enforcing"] = False
    assert _run(payload)[0] == ChangeStatus.FAIL
    payload = _payload("permissive")
    payload["reboot_required"] = False
    assert _run(payload)[0] == ChangeStatus.FAIL


def test_alpha52_acceptance_runner_has_dedicated_gate():
    text = (Path(__file__).parents[1] / "chromapress_acceptance.py").read_text(encoding="utf-8")
    assert "P4-ALPHA52-SELINUX" in text
    assert "_add_alpha52_selinux_gate" in text
    assert "system_selinux_evidence" in text


def test_alpha52_version_markers():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")


def test_alpha52_missing_addable_package_dependencies_stage_cleanly():
    payload = _payload("permissive")
    payload.update({
        "configured_mode": "unknown",
        "config_layer": "",
        "config_creation_required": True,
        "package_install_required": True,
        "required_packages": ["selinux-basics_1.0_all.deb", "policycoreutils_3.0_amd64.deb"],
        "package_requirements_staged": True,
        "kernel_support_status": "SUPPORTED",
        "relabel_required": True,
    })
    status, message = _run(payload)
    assert status == ChangeStatus.PASS, message


def test_alpha52_acceptance_gate_executes_supported_and_unknown(tmp_path):
    import sys
    root = Path(__file__).parents[1]
    sys.path.insert(0, str(root)) if str(root) not in sys.path else None
    from chromapress_acceptance import AcceptanceRunner, PASS

    runner = AcceptanceRunner(root, 4, None, None, tmp_path)
    supported = {
        "gate_version": "alpha52",
        "analysis_scope": "target_iso_rootfs",
        "verified": True,
        "capability_status": "SUPPORTED_WITH_REQUIREMENTS",
        "configured_mode": "disabled",
        "config_path": "/etc/selinux/config",
        "config_layer": "/casper/minimal.squashfs",
        "config_metadata_read": True,
        "config_creation_required": False,
        "policy_type": "targeted",
        "policy_tree_present": True,
        "policy_entries": ["targeted", "custom"],
        "policy_contents_read": False,
        "custom_policy_preserved": True,
        "package_manager": "apt",
        "package_manager_path": "/usr/bin/apt-get",
        "repository_metadata_path": "/etc/apt/sources.list.d",
        "package_install_required": False,
        "required_packages": [],
        "kernel_support_status": "SUPPORTED",
        "kernel_config_path": "/boot/config-test",
        "kernel_images": ["/casper/vmlinuz"],
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "initramfs_mechanism": "update-initramfs",
        "part3_dependency_required": True,
        "part3_requirements": [
            {"model": "part3_boot", "action": "verify_selinux_boot_parameters", "boot_config_files": ["/boot/grub/grub.cfg"], "forbid_parameters": ["selinux=0"]}
        ],
        "relabel_required_on_enable": True,
        "reboot_required": True,
        "supported_modes": ["enforcing", "permissive", "disabled"],
        "supported_operations": ["set_selinux_mode"],
        "host_selinux_accessed": False,
        "host_security_state_accessed": False,
        "source_read_only": True,
    }
    runner._add_alpha52_selinux_gate(supported, "a" * 64)
    assert runner.checks[-1].status == PASS

    unknown = dict(supported)
    unknown.update({
        "verified": False,
        "capability_status": "UNKNOWN",
        "supported_modes": [],
        "supported_operations": [],
        "relabel_required_on_enable": False,
        "reboot_required": False,
    })
    runner._add_alpha52_selinux_gate(unknown, "a" * 64)
    assert runner.checks[-1].status == PASS
    assert "fail-closed" in runner.checks[-1].detail
