from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.boot_hardware_page import BootHardwarePage
from chromapress.models import ChangeKind


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def test_alpha27_stages_one_explicit_boot_plan_without_modifying_source(qapp):
    page = BootHardwarePage()
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.set_analysis({
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "bios_boot": True,
        "uefi_boot": True,
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "boot_entries": [
            {"source": "/boot/grub/grub.cfg", "title": "Try Lubuntu", "id": ""},
            {"source": "/boot/grub/grub.cfg", "title": "Safe graphics", "id": ""},
        ],
    })
    assert page.stage_btn.isEnabled()
    page.default_combo.setCurrentIndex(1)
    page.timeout_spin.setValue(5)
    page.kernel_args_edit.setText("nomodeset")
    page.stage_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "boot"
    assert change.payload["stage_only"] is True
    assert change.payload["source_sha256"] == "a" * 64
    assert change.payload["default_entry"]["title"] == "Try Lubuntu"
    assert change.payload["timeout_seconds"] == 5
    assert change.payload["kernel_args_append"] == "nomodeset"
    assert "staged" in page.plan_status.text().lower()


def test_alpha27_blocks_staging_when_no_explicit_boot_config_exists(qapp):
    page = BootHardwarePage()
    page.set_analysis({"path": r"E:\\test.iso", "sha256": "a" * 64})
    assert not page.stage_btn.isEnabled()


def test_alpha27_source_switch_blocks_stale_boot_plan(qapp):
    from chromapress.gui.main_window import MainWindow
    from chromapress.models import ChangeItem, ChangeKind, ChangeStatus

    window = MainWindow()
    stale = ChangeItem(
        "Boot configuration plan",
        ChangeKind.CONFIG,
        "test",
        {
            "config_type": "boot",
            "source_sha256": "a" * 64,
            "boot_config_files": ["/boot/grub/grub.cfg"],
            "default_entry": {"title": "Try Lubuntu", "source": "/boot/grub/grub.cfg", "id": ""},
            "timeout_seconds": None,
            "kernel_args_append": "",
            "stage_only": True,
        },
    )
    window.project.changes.append(stale)
    window.changes.set_changes(window.project.changes)
    window._guard_boot_plan_source("b" * 64)
    assert stale.status == ChangeStatus.BLOCKED
    assert "Source changed" in stale.detail
    window.close()
