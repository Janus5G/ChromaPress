from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _kiosk(capability="SUPPORTED_WITH_REQUIREMENTS"):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha55", "analysis_scope": "target_iso_rootfs", "capability_status": capability,
        "verified": supported, "backend": "passwd-group",
        "passwd_layer": "/casper/minimal.squashfs" if supported else "",
        "group_layer": "/casper/minimal.squashfs" if supported else "",
        "uid_min": 1000, "existing_regular_users": ["ubuntu"] if supported else [], "existing_user_uids": [1000] if supported else [],
        "available_groups": ["users", "sudo"], "admin_groups": ["sudo"],
        "supported_operations": ["create_dedicated_non_admin_kiosk_user"] if supported else [],
        "shadow_read": False, "credential_secret_read": False, "host_accounts_touched": False,
        "login_policy_inspected": False, "session_policy_inspected": False, "source_read_only": True,
        "reason": f"{capability} — test evidence",
    }


def _analysis(capability="SUPPORTED_WITH_REQUIREMENTS"):
    return {"sha256": "a" * 64, "package_format": "deb", "system_kiosk_user_evidence": _kiosk(capability)}


def _quiet(monkeypatch):
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.changes.QMessageBox.information", lambda *a, **k: None)


def _fill(page):
    page.kiosk_user_operation.setCurrentIndex(page.kiosk_user_operation.findData("create_dedicated_non_admin_kiosk_user"))
    page.kiosk_username.setText("chromakiosk55")
    page.kiosk_display_name.setText("Chroma Kiosk")


def test_alpha55_controls_are_narrow_and_non_admin(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.kiosk_user_operation.findData("create_dedicated_non_admin_kiosk_user") >= 0
    assert page.kiosk_user_capability_value.text() == "SUPPORTED_WITH_REQUIREMENTS"
    assert "non-admin" in page.kiosk_role_value.text().casefold()


def test_alpha55_changes_test_and_undo(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    _fill(page)
    page.stage_kiosk_user_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.payload["account_role"] == "dedicated_non_admin_kiosk"
    assert change.payload["administrative_groups"] == []
    assert change.payload["credential_secret_staged"] is False
    assert change.payload["login_policy_deferred_to_later_gate"] is True

    changes = ChangesPanel()
    changes.set_changes([])
    changes.add_change(change)
    changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == []


def test_alpha55_unknown_gui_staging_fails_closed(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis("UNKNOWN"))
    emitted = []
    page.stage_requested.connect(emitted.append)
    _fill(page)
    page.stage_kiosk_user_btn.click()
    assert emitted == []


def test_alpha55_existing_username_is_blocked(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    page.kiosk_user_operation.setCurrentIndex(page.kiosk_user_operation.findData("create_dedicated_non_admin_kiosk_user"))
    page.kiosk_username.setText("ubuntu")
    page.kiosk_display_name.setText("Existing")
    page.stage_kiosk_user_btn.click()
    assert emitted == []
