from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_machine_identity_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _good_payload() -> dict:
    return {
        "config_type": "system_machine_identity",
        "source_sha256": "b" * 64,
        "operation": "configure_hostname",
        "target_hostname": "chromalinux-test",
        "current_hostname": "lubuntu",
        "hostname_layer": "/casper/minimal.squashfs",
        "machine_id_policy": "regenerate_on_first_boot",
        "machine_id_state": "present",
        "machine_id_layer": "/casper/minimal.squashfs",
        "rootfs_machine_identity_verified": True,
        "machine_id_value_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def test_alpha38_machine_identity_evidence_never_exposes_machine_id_value(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"not-read-by-test")
    layers = ["/casper/minimal.squashfs"]

    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (4096, 1234)})

    def fake_read(_iso: Path, _layers: list[str], member: str, _extents):
        if member == "/etc/hostname":
            return "lubuntu\n", layers[0]
        if member == "/etc/machine-id":
            return "0123456789abcdef0123456789abcdef\n", layers[0]
        return "", ""

    monkeypatch.setattr("chromapress.engine_cli._read_squashfs_overlay_text", fake_read)
    evidence = _system_machine_identity_rootfs_evidence(iso, layers)

    assert evidence["verified"] is True
    assert evidence["hostname"] == "lubuntu"
    assert evidence["machine_id_state"] == "present"
    assert evidence["machine_id_value_exposed"] is False
    assert "machine_id" not in evidence


def test_alpha38_machine_identity_preflight_passes_without_machine_id_value():
    status, message = run_preflight(
        ChangeItem("Hostname / machine identity plan", ChangeKind.CONFIG, "test", _good_payload())
    )
    assert status == ChangeStatus.PASS
    assert "machine-id-value free" in message


def test_alpha38_machine_identity_preflight_rejects_unsafe_hostname_or_id_value():
    payload = _good_payload()
    payload["target_hostname"] = "Bad Hostname!"
    status, _ = run_preflight(ChangeItem("Machine identity", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL

    payload = _good_payload()
    payload["machine_id_value_staged"] = True
    status, _ = run_preflight(ChangeItem("Machine identity", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL
