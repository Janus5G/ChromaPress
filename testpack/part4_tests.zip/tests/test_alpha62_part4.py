from pathlib import Path

import pytest

from chromapress.engine_cli import _system_admin_recovery_policy_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight
from chromapress_acceptance import AcceptanceRunner


def _identity(*, with_admin_group=True):
    groups = ["users"] + (["sudo"] if with_admin_group else [])
    return {
        "gate_version": "alpha50",
        "analysis_scope": "target_iso_rootfs",
        "capability_status": "SUPPORTED_WITH_REQUIREMENTS",
        "users_groups_status": "SUPPORTED_WITH_REQUIREMENTS",
        "verified": True,
        "passwd_layer": "/casper/minimal.squashfs",
        "group_layer": "/casper/minimal.squashfs",
        "regular_users": ["liveadmin", "student"],
        "admin_groups": ["sudo"] if with_admin_group else [],
        "user_records": [
            {"username": "liveadmin", "uid": 1000, "gid": 1000, "groups": ["sudo"] if with_admin_group else []},
            {"username": "student", "uid": 1001, "gid": 1001, "groups": ["users"]},
        ],
        "groups": groups,
        "shadow_read": False,
        "credential_secret_read": False,
        "host_accounts_touched": False,
        "source_read_only": True,
    }


def _autologin(*, verified=True, user="kiosk"):
    return {
        "verified": verified,
        "display_manager": "sddm" if verified else "",
        "autologin_state": "enabled explicitly" if verified and user else "no explicit autologin directive found",
        "autologin_user": user if verified else "",
        "credential_secret_read": False,
    }


def _kiosk(cap="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "gate_version": "alpha55",
        "analysis_scope": "target_iso_rootfs",
        "capability_status": cap,
        "verified": cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"},
        "existing_regular_users": ["liveadmin", "student"],
        "admin_groups": ["sudo"],
        "shadow_read": False,
        "credential_secret_read": False,
        "host_accounts_touched": False,
        "source_read_only": True,
    }


def _supported():
    return _system_admin_recovery_policy_evidence(_identity(), _autologin(), _kiosk())


def _payload(e=None, *, username="recovery62", dependency="alpha50_create_administrator"):
    e = dict(e or _supported())
    return {
        "config_type": "administrator_recovery_policy",
        "gate_version": "alpha62",
        "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_rootfs",
        "capability_status": e.get("capability_status", "UNKNOWN"),
        "rootfs_admin_recovery_verified": e.get("verified") is True,
        "operation": "require_dedicated_recovery_administrator",
        "policy_scope": "separate_non_autologin_recovery_administrator",
        "username": username,
        "admin_group": "sudo",
        "account_dependency": dependency,
        "existing_regular_users": list(e.get("existing_regular_users") or []),
        "existing_admin_users": list(e.get("existing_admin_users") or []),
        "verified_admin_groups": list(e.get("admin_groups") or []),
        "current_autologin_user": str(e.get("autologin_user") or ""),
        "recovery_account_must_be_distinct_from_kiosk": True,
        "recovery_account_must_not_autologin": True,
        "allow_root_as_recovery_administrator": False,
        "credential_policy": "deferred_secure_verified_apply",
        "authentication_factor_policy": "deferred_to_fido2_webauthn_security_key_tpm_gates",
        "shadow_read": False,
        "credential_secret_read": False,
        "credential_secret_staged": False,
        "recovery_secret_read": False,
        "recovery_secret_staged": False,
        "pam_contents_read": False,
        "ssh_config_read": False,
        "rescue_boot_config_read": False,
        "root_account_policy_read": False,
        "host_accounts_touched": False,
        "host_login_state_accessed": False,
        "preserve_existing_administrators": True,
        "preserve_root_account_policy": True,
        "preserve_rescue_boot_configuration": True,
        "preserve_pam_configuration": True,
        "preserve_ssh_configuration": True,
        "do_not_stage_authenticator_changes": True,
        "require_admin_membership_reverification_before_apply": True,
        "require_autologin_reverification_before_apply": True,
        "require_recovery_kiosk_separation_reverification_before_apply": True,
        "require_account_dependency_before_apply": True,
        "require_account_dependency_reverification_before_apply": True,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("Administrator/recovery policy plan", ChangeKind.CONFIG, "test", payload))


def test_alpha62_supported_evidence_is_requirements_only_and_secret_free():
    e = _supported()
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert e["verified"] is True
    assert e["admin_groups"] == ["sudo"]
    assert e["existing_admin_users"] == ["liveadmin"]
    assert e["autologin_user"] == "kiosk"
    assert e["supported_operations"] == ["require_dedicated_recovery_administrator"]
    for key in (
        "shadow_read", "credential_secret_read", "recovery_secret_read", "pam_contents_read",
        "ssh_config_read", "rescue_boot_config_read", "root_account_policy_read",
        "host_accounts_touched", "host_login_state_accessed",
    ):
        assert e[key] is False


def test_alpha62_unverified_autologin_is_unknown():
    e = _system_admin_recovery_policy_evidence(_identity(), _autologin(verified=False), _kiosk())
    assert e["capability_status"] == "UNKNOWN"
    assert e["verified"] is False


def test_alpha62_missing_admin_group_is_unknown_not_guessed():
    e = _system_admin_recovery_policy_evidence(_identity(with_admin_group=False), _autologin(), _kiosk())
    assert e["capability_status"] == "UNKNOWN"
    assert e["verified"] is False


def test_alpha62_privacy_unsafe_kiosk_evidence_blocks():
    k = _kiosk(); k["shadow_read"] = True
    e = _system_admin_recovery_policy_evidence(_identity(), _autologin(), k)
    assert e["capability_status"] == "BLOCKED"


def test_alpha62_new_recovery_admin_dependency_preflight_passes():
    status, message = _run(_payload())
    assert status == ChangeStatus.PASS
    assert "recovery-role separated" in message


def test_alpha62_existing_verified_admin_dependency_passes():
    status, _ = _run(_payload(username="liveadmin", dependency="verified_existing_admin_user"))
    assert status == ChangeStatus.PASS


def test_alpha62_existing_non_admin_cannot_be_silently_promoted():
    assert _run(_payload(username="student", dependency="alpha50_create_administrator"))[0] == ChangeStatus.FAIL


def test_alpha62_autologin_user_cannot_be_recovery_admin():
    p = _payload(username="kiosk")
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha62_root_cannot_be_recovery_admin():
    assert _run(_payload(username="root"))[0] == ChangeStatus.FAIL


@pytest.mark.parametrize("cap", ["UNKNOWN", "BLOCKED", "UNSUPPORTED"])
def test_alpha62_unverified_capability_fails_closed(cap):
    e = _supported(); e["capability_status"] = cap; e["verified"] = False
    assert _run(_payload(e))[0] == ChangeStatus.FAIL


def test_alpha62_rejects_secret_or_protected_state_access():
    for key in (
        "shadow_read", "credential_secret_read", "credential_secret_staged", "recovery_secret_read",
        "recovery_secret_staged", "pam_contents_read", "ssh_config_read", "rescue_boot_config_read",
        "root_account_policy_read", "host_accounts_touched", "host_login_state_accessed",
    ):
        p = _payload(); p[key] = True
        assert _run(p)[0] == ChangeStatus.FAIL, key


def test_alpha62_rejects_authenticator_preemption_and_missing_preservation():
    p = _payload(); p["authentication_factor_policy"] = "fido2_required"
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["do_not_stage_authenticator_changes"] = False
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload(); p["preserve_root_account_policy"] = False
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha62_acceptance_supported_and_unknown(tmp_path):
    runner = AcceptanceRunner(tmp_path, 4, None, None, tmp_path / "reports")
    e = _supported()
    runner._add_alpha62_admin_recovery_policy_gate(e, "a" * 64)
    assert runner.checks[-1].status == "PASS"
    e["capability_status"] = "UNKNOWN"; e["verified"] = False
    runner._add_alpha62_admin_recovery_policy_gate(e, "a" * 64)
    assert runner.checks[-1].status == "PASS"


def test_alpha62_version_markers():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")


def test_alpha62_part4_source_guard_includes_recovery_plan():
    root = Path(__file__).resolve().parents[1]
    text = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert '"administrator_recovery_policy"' in text
