from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.boot_hardware_page import BootHardwarePage


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def test_alpha25_boot_hardware_page_renders_read_only_analysis(qapp):
    page = BootHardwarePage()
    page.set_analysis({
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "volume_id": "TEST",
        "bios_boot": True,
        "uefi_boot": True,
        "el_torito_boot": True,
        "hybrid_boot": True,
        "bootloaders": ["GRUB"],
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "efi_images": ["/EFI/BOOT/BOOTX64.EFI"],
        "kernel_images": ["/casper/vmlinuz"],
        "initramfs_images": ["/casper/initrd"],
        "rootfs_details": [{"path": "/casper/minimal.squashfs", "compression": "xz", "block_size": 1048576}],
    })
    assert page.boot_fields["modes"].text() == "BIOS, UEFI"
    assert page.boot_fields["loaders"].text() == "GRUB"
    assert page.boot_fields["el_torito"].text() == "Detected"
    assert page.boot_fields["hybrid"].text() == "Detected"
    names = {page.structure.topLevelItem(i).text(0) for i in range(page.structure.topLevelItemCount())}
    assert {
        "Boot configuration",
        "EFI images",
        "Kernel images",
        "Initramfs / initrd",
        "Root filesystem layers",
        "Firmware / driver media hints",
    } <= names
    assert "read-only" in page.footer.text().lower()
