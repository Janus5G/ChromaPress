from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QPushButton
from chromapress.gui.applications_page import ApplicationsPage
from chromapress.settings import AppSettings


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _page(qapp, scenario: str) -> ApplicationsPage:
    page = ApplicationsPage(AppSettings())
    page._source = {"distribution": "Lubuntu", "version": "26.04.1", "path": "test.iso"}
    page._catalog = []
    page._catalog_loaded = True
    page._scenario_id = scenario
    page._populate([])
    return page


def _find_top(page, prefix):
    for i in range(page.tree.topLevelItemCount()):
        item = page.tree.topLevelItem(i)
        if item.text(0).startswith(prefix):
            return item
    return None


def _find_desc(parent, prefix):
    for i in range(parent.childCount()):
        child = parent.child(i)
        if child.text(0).startswith(prefix):
            return child
        found = _find_desc(child, prefix)
        if found:
            return found
    return None


def test_business_shows_abiword_and_notepadplusplus(qapp):
    page = _page(qapp, "business")
    top = _find_top(page, "Recommended for Office / Business")
    assert top is not None
    assert _find_desc(top, "Recommended: AbiWord") is not None
    notepad = _find_desc(top, "Recommended: Notepad++ Linux")
    assert notepad is not None
    assert "Snap" in notepad.text(3)


def test_development_shows_refract_studio_and_office_documents(qapp):
    page = _page(qapp, "development")
    top = _find_top(page, "Recommended for Development / Engineering")
    assert top is not None
    refract = _find_desc(top, "Recommended: Refract Studio")
    abiword = _find_desc(top, "Recommended: AbiWord")
    notepad = _find_desc(top, "Recommended: Notepad++ Linux")
    assert refract is not None and "Bundled" in refract.text(3)
    assert abiword is not None and notepad is not None


def test_gaming_measurement_rows_have_skip_add(qapp):
    page = _page(qapp, "gaming_team")
    top = _find_top(page, "Recommended for Gaming / Team")
    assert top is not None
    for name in ("MangoHud", "nvtop", "Speedtest CLI", "GLMark2"):
        item = _find_desc(top, f"Recommended: {name}")
        assert item is not None
        widget = page.tree.itemWidget(item, 4)
        labels = [button.text() for button in widget.findChildren(QPushButton)]
        assert labels == ["Skip", "Add"]
