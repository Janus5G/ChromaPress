from __future__ import annotations

from pathlib import Path

from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as preflight_change


def _immutable_plan(**overrides):
    payload = {
        "config_type": "immutable_runtime",
        "source_sha256": "a" * 64,
        "base_layer": "/casper/minimal.squashfs",
        "runtime_mode": "volatile_overlay",
        "writable_layer": "tmpfs",
        "persistence_policy": "volatile",
        "runtime_changes_survive_reboot": False,
        "initramfs_mechanism": "update-initramfs",
        "require_initramfs_integration": True,
        "require_boot_integration": True,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }
    payload.update(overrides)
    return ChangeItem("Immutable / volatile runtime plan", ChangeKind.CONFIG, "test", payload)


def test_alpha31_immutable_runtime_plan_is_explicit_and_stage_only():
    status, message = preflight_change(_immutable_plan())
    assert status == ChangeStatus.PASS
    assert "source-hash locked" in message
    assert "OverlayFS/tmpfs" in message
    assert "reboot-survival explicit" in message
    assert "staging-only" in message


def test_alpha31_requires_explicit_squashfs_base_and_volatile_overlay():
    assert preflight_change(_immutable_plan(base_layer="/casper/root.img"))[0] == ChangeStatus.FAIL
    assert preflight_change(_immutable_plan(runtime_mode="persistent_overlay"))[0] == ChangeStatus.FAIL
    assert preflight_change(_immutable_plan(writable_layer="disk"))[0] == ChangeStatus.FAIL


def test_alpha31_requires_explicit_volatile_reboot_semantics():
    assert preflight_change(_immutable_plan(persistence_policy="persistent"))[0] == ChangeStatus.FAIL
    assert preflight_change(_immutable_plan(runtime_changes_survive_reboot=True))[0] == ChangeStatus.FAIL


def test_alpha31_requires_native_initramfs_and_boot_integration():
    assert preflight_change(_immutable_plan(initramfs_mechanism="unknown"))[0] == ChangeStatus.FAIL
    assert preflight_change(_immutable_plan(require_initramfs_integration=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_immutable_plan(require_boot_integration=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_immutable_plan(source_read_only=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_immutable_plan(preserve_unrelated=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_immutable_plan(stage_only=False))[0] == ChangeStatus.FAIL


def test_alpha31_version_markers_are_consistent():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
    main_window = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert 'from chromapress import __version__' in main_window
    assert 'QLabel(__version__)' in main_window
