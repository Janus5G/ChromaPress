from pathlib import Path


def test_alpha21_withdrawn_legacy_bundle_stays_absent():
    root = Path(__file__).parents[1]
    assert not (root / "bundled_apps/chromalearn_0.3.0_all.deb").exists()
    assert not (root / "bundled_apps/chromalearn_0.4.0_all.deb").exists()
