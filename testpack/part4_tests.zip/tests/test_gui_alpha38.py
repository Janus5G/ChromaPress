from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.system_page import SystemPage


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis() -> dict:
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_package_evidence": [],
        "system_rootfs_verification": ["network profiles remain gated"],
        "system_identity_evidence": {
            "verified": True,
            "reason": "PASS — identity",
            "passwd_layer": "/casper/minimal.squashfs",
            "group_layer": "/casper/minimal.squashfs",
            "uid_min": 1000,
            "regular_users": [],
            "admin_groups": ["sudo"],
            "shadow_read": False,
        },
        "system_machine_identity_evidence": {
            "verified": True,
            "reason": "PASS — /etc/hostname verified read-only",
            "hostname": "lubuntu",
            "hostname_layer": "/casper/minimal.squashfs",
            "machine_id_state": "present",
            "machine_id_layer": "/casper/minimal.squashfs",
            "machine_id_value_exposed": False,
        },
    }


def test_alpha38_system_page_shows_machine_identity_evidence(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert "PASS" in page.machine_status_value.text()
    assert page.machine_hostname_value.text() == "lubuntu"
    assert page.machine_id_state_value.text() == "present"
    assert "ROOTFS IDENTITY + MACHINE ID PASS" in page.status.text()


def test_alpha38_machine_identity_controls_default_to_preserve(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.machine_operation.currentData() == "preserve"
    assert not page.machine_hostname.isEnabled()
    assert not page.machine_id_policy.isEnabled()
    assert "never displayed or stored" in page.machine_id_safety_value.text()
