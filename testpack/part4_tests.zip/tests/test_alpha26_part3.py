from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import (
    _boot_source_metadata,
    _catalog_from_el_torito_report,
    _hardware_package_hints,
    _parse_boot_config_text,
)
from chromapress.models import SourceState


def test_alpha26_parses_grub_explicit_evidence_only():
    parsed = _parse_boot_config_text(
        "/boot/grub/grub.cfg",
        """
set default=0
set timeout=10
menuentry 'Try Lubuntu' --class lubuntu {
    linux /casper/vmlinuz boot=casper quiet splash ---
}
""",
    )
    assert parsed["boot_entries"][0]["title"] == "Try Lubuntu"
    assert parsed["boot_defaults"] == ["0 (/boot/grub/grub.cfg)"]
    assert parsed["boot_timeouts"] == ["10 s (/boot/grub/grub.cfg)"]
    assert parsed["kernel_arguments"][0]["args"] == "boot=casper quiet splash ---"


def test_alpha26_parses_syslinux_timeout_units_and_menu_label():
    parsed = _parse_boot_config_text(
        "/isolinux/isolinux.cfg",
        """
DEFAULT live
TIMEOUT 50
LABEL live
  MENU LABEL ^Start live system
  KERNEL /casper/vmlinuz
  APPEND boot=casper quiet
""",
    )
    assert parsed["boot_defaults"] == ["live (/isolinux/isolinux.cfg)"]
    assert "5 s" in parsed["boot_timeouts"][0]
    assert parsed["boot_entries"][0]["title"] == "Start live system"
    assert parsed["kernel_arguments"][0]["args"] == "boot=casper quiet"


def test_alpha26_catalog_uses_xorriso_report_when_catalog_is_hidden():
    report = "El Torito catalog  : 1267  1\nEl Torito cat path : /boot.catalog\n"
    assert _catalog_from_el_torito_report(report) == "/boot.catalog"
    data = _boot_source_metadata(["/EFI/BOOT/BOOTX64.EFI"], report, "System area summary: GPT MBR")
    assert data["el_torito_boot"] is True
    assert data["boot_catalog"] == "/boot.catalog"


def test_alpha26_hardware_package_hints_are_manifest_backed_and_conservative():
    hints = _hardware_package_hints({
        "linux-image-generic": "6.17.0",
        "linux-firmware": "20260901",
        "intel-microcode": "3.0",
        "nvidia-driver-580": "580.1",
        "broadcom-sta-dkms": "6.30",
        "firefox": "150",
    })
    packages = {item["package"] for item in hints}
    assert "linux-image-generic" in packages
    assert "linux-firmware" in packages
    assert "intel-microcode" in packages
    assert "nvidia-driver-580" in packages
    assert "broadcom-sta-dkms" in packages
    assert "firefox" not in packages


def test_alpha26_source_state_persists_deep_part3_evidence():
    state = SourceState(
        boot_entries=[{"source": "/boot/grub/grub.cfg", "title": "Live"}],
        boot_defaults=["0 (/boot/grub/grub.cfg)"],
        boot_timeouts=["10 s (/boot/grub/grub.cfg)"],
        kernel_arguments=[{"source": "/boot/grub/grub.cfg", "args": "quiet"}],
        hardware_package_hints=[{"package": "linux-firmware", "version": "1", "kind": "Firmware / microcode"}],
    )
    assert state.boot_entries[0]["title"] == "Live"
    assert state.hardware_package_hints[0]["package"] == "linux-firmware"


def test_alpha26_verified_evidence_remains_available_after_staging_is_added():
    root = Path(__file__).parents[1]
    page = (root / "src/chromapress/gui/boot_hardware_page.py").read_text(encoding="utf-8")
    assert "Boot configuration evidence" in page
    assert "Manifest-backed kernel / firmware / driver packages" in page
    assert "Source remains read-only" in page
