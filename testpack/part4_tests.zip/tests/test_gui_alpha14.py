from __future__ import annotations

import os

import pytest

# The Windows project venv has PySide6.  The CI/container used to assemble this
# update may not, so keep this as an on-machine GUI smoke suite rather than
# turning a missing GUI runtime into a false core failure.
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QPushButton

from chromapress.gui.applications_page import ApplicationsPage
from chromapress.models import ChangeItem, ChangeKind
from chromapress.settings import AppSettings


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _catalog() -> list[dict]:
    return [
        {
            "application": "LibreOffice Writer",
            "package": "libreoffice-writer",
            "categories": ["Office", "WordProcessor"],
            "description": "Word processor",
            "state": "Installed",
            "removable": True,
        },
        {
            "application": "qpdfview",
            "package": "qpdfview",
            "categories": ["Office"],
            "description": "PDF document viewer",
            "state": "Installed",
            "removable": True,
        },
        {
            "application": "Transmission",
            "package": "transmission-qt",
            "categories": ["Network"],
            "description": "BitTorrent client",
            "state": "Installed",
            "removable": True,
        },
        {
            "application": "Example IDE",
            "package": "example-ide",
            "categories": ["Development", "IDE"],
            "description": "Programming and web development",
            "state": "Installed",
            "removable": True,
        },
    ]


def _page(qapp) -> ApplicationsPage:
    page = ApplicationsPage(AppSettings())
    page._source = {
        "distribution": "Lubuntu",
        "version": "26.04.1",
        "path": "test.iso",
    }
    page._catalog = _catalog()
    page._catalog_loaded = True
    page._scenario_id = "personal"
    page._populate_personal(page._catalog)
    return page


def _find_child(parent, prefix: str):
    for i in range(parent.childCount()):
        child = parent.child(i)
        if child.text(0).startswith(prefix):
            return child
    return None


def _find_top(page: ApplicationsPage, prefix: str):
    for i in range(page.tree.topLevelItemCount()):
        item = page.tree.topLevelItem(i)
        if item.text(0).startswith(prefix):
            return item
    return None


def test_home_personal_gui_places_libreoffice_advanced_and_abiword_everyday(qapp):
    page = _page(qapp)
    everyday = _find_top(page, "Everyday essentials")
    advanced = _find_top(page, "Specialised / Advanced")
    assert everyday is not None and advanced is not None

    writing = _find_child(everyday, "Writing & office")
    full_office = _find_child(advanced, "Full office suites")
    assert writing is not None and full_office is not None
    assert _find_child(writing, "Recommended: AbiWord") is not None
    assert _find_child(full_office, "LibreOffice") is not None

    everyday_labels = {everyday.child(i).text(0).split(" (")[0] for i in range(everyday.childCount())}
    assert "Torrent & file sharing" not in everyday_labels
    assert "Programming & web development" not in everyday_labels


def test_recommendation_gui_has_visible_skip_and_add_buttons(qapp):
    page = _page(qapp)
    everyday = _find_top(page, "Everyday essentials")
    writing = _find_child(everyday, "Writing & office")
    abiword = _find_child(writing, "Recommended: AbiWord")
    widget = page.tree.itemWidget(abiword, 4)
    labels = [button.text() for button in widget.findChildren(QPushButton)]
    assert labels == ["Skip", "Add"]


def test_remove_rebuild_preserves_open_home_groups(qapp):
    page = _page(qapp)
    everyday = _find_top(page, "Everyday essentials")
    writing = _find_child(everyday, "Writing & office")
    everyday.setExpanded(True)
    writing.setExpanded(True)

    page.set_staged_changes([
        ChangeItem(
            "Remove qpdfview",
            ChangeKind.PACKAGE_REMOVE,
            "test",
            {"package": "qpdfview", "application": "qpdfview"},
        )
    ])

    everyday_after = _find_top(page, "Everyday essentials")
    writing_after = _find_child(everyday_after, "Writing & office")
    assert everyday_after.isExpanded()
    assert writing_after.isExpanded()
