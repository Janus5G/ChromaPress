import os; os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
import pytest; pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication,QMessageBox
from chromapress.gui.system_page import SystemPage
from chromapress.gui.changes import ChangesPanel
from chromapress.models import ChangeStatus
@pytest.fixture(scope="module")
def qapp(): return QApplication.instance() or QApplication([])
def _a(cap="SUPPORTED_WITH_REQUIREMENTS"):
    ok=cap in {"SUPPORTED","SUPPORTED_WITH_REQUIREMENTS"}; return {"sha256":"a"*64,"system_admin_recovery_policy_evidence":{"gate_version":"alpha62","capability_status":"SUPPORTED_WITH_REQUIREMENTS","verified":True,"existing_admin_users":["liveadmin"],"autologin_user":"kiosk"},"system_yubikey_policy_evidence":{"gate_version":"alpha66","capability_status":cap,"verified":ok,"yubikey_packages":["yubikey-manager"] if ok else [],"alpha62_dependency_verified":ok,"alpha65_evidence_observed":True,"reason":cap}}
def test_alpha66_stage_test_undo(qapp,monkeypatch):
    monkeypatch.setattr(QMessageBox,"information",lambda *a,**k:None); monkeypatch.setattr(QMessageBox,"warning",lambda *a,**k:None)
    p=SystemPage(); p.set_analysis(_a()); c=ChangesPanel(); p.stage_requested.connect(c.add_change); p.yubikey_operation.setCurrentIndex(p.yubikey_operation.findData("allow_yubikey_class_authenticator_for_recovery_admin")); p.yubikey_username.setText("liveadmin"); p.stage_yubikey_btn.click(); assert len(c.changes)==1
    c.list.setCurrentRow(0); c._test_selected(); assert c.changes[0].status==ChangeStatus.PASS; c._undo_selected(); assert c.changes==[]
def test_alpha66_unknown_gui_fails_closed(qapp,monkeypatch):
    monkeypatch.setattr(QMessageBox,"information",lambda *a,**k:None); p=SystemPage(); p.set_analysis(_a("UNKNOWN")); out=[]; p.stage_requested.connect(out.append); p.yubikey_operation.setCurrentIndex(p.yubikey_operation.findData("allow_yubikey_class_authenticator_for_recovery_admin")); p.yubikey_username.setText("liveadmin"); p.stage_yubikey_btn.click(); assert out==[]
