from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _parse_keyboard_assignments, _system_keyboard_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _good_payload() -> dict:
    return {
        "config_type": "system_keyboard",
        "source_sha256": "e" * 64,
        "operation": "configure_layout",
        "target_layout": "dk",
        "keyboard_config_path": "/etc/default/keyboard",
        "keyboard_config_layer": "/casper/minimal.standard.squashfs",
        "keyboard_config_style": "debian-default-keyboard",
        "current_layout": "us",
        "rootfs_keyboard_verified": True,
        "require_layout_availability_verification_before_apply": True,
        "preserve_model_variant_options": True,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def test_alpha41_keyboard_parser_limits_keys():
    values = _parse_keyboard_assignments('XKBMODEL="pc105"\nXKBLAYOUT="us"\nXKBVARIANT=""\nXKBOPTIONS="grp:alt_shift_toggle"\nPASSWORD=secret\n')
    assert values == {"XKBMODEL": "pc105", "XKBLAYOUT": "us", "XKBVARIANT": "", "XKBOPTIONS": "grp:alt_shift_toggle"}


def test_alpha41_keyboard_evidence_uses_rootfs_config(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"not-read-by-test")
    layers = ["/casper/minimal.standard.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (4096, 1234)})

    def fake_read(_iso: Path, _layers: list[str], member: str, _extents):
        if member == "/etc/default/keyboard":
            return 'XKBMODEL="pc105"\nXKBLAYOUT="us"\nXKBVARIANT=""\nXKBOPTIONS=""\n', layers[0]
        return "", ""

    monkeypatch.setattr("chromapress.engine_cli._read_squashfs_overlay_text", fake_read)
    monkeypatch.setattr("chromapress.engine_cli._read_keyboard_from_readonly_mount", lambda *a, **k: {})
    evidence = _system_keyboard_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["config_path"] == "/etc/default/keyboard"
    assert evidence["current_layout"] == "us"
    assert evidence["current_model"] == "pc105"
    assert evidence["secret_read"] is False


def test_alpha41_keyboard_preflight_passes():
    status, message = run_preflight(ChangeItem("Keyboard layout plan", ChangeKind.CONFIG, "test", _good_payload()))
    assert status == ChangeStatus.PASS
    assert "rootfs-evidence bound" in message
    assert "layout-availability gated" in message


def test_alpha41_keyboard_preflight_rejects_unsafe_or_unverified_values():
    payload = _good_payload()
    payload["target_layout"] = "dk;touch"
    status, _ = run_preflight(ChangeItem("Keyboard", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL

    payload = _good_payload()
    payload["rootfs_keyboard_verified"] = False
    status, _ = run_preflight(ChangeItem("Keyboard", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL
