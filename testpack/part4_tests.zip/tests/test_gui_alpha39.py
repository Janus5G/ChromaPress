from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeKind


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis() -> dict:
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_package_evidence": [{"area": "Display manager / autologin", "package": "sddm", "version": "0.21"}],
        "system_rootfs_verification": ["network profiles remain gated"],
        "system_identity_evidence": {
            "verified": True,
            "reason": "PASS — identity",
            "passwd_layer": "/casper/minimal.standard.squashfs",
            "group_layer": "/casper/minimal.standard.squashfs",
            "uid_min": 1000,
            "regular_users": [],
            "admin_groups": ["sudo"],
            "shadow_read": False,
        },
        "system_machine_identity_evidence": {
            "verified": True,
            "reason": "PASS — machine identity",
            "hostname": "lubuntu",
            "hostname_layer": "/casper/minimal.standard.squashfs",
            "machine_id_state": "present",
            "machine_id_layer": "/casper/minimal.squashfs",
            "machine_id_value_exposed": False,
        },
        "system_autologin_evidence": {
            "verified": True,
            "reason": "PASS — default display manager verified read-only",
            "display_manager": "sddm",
            "display_manager_layer": "/casper/minimal.standard.squashfs",
            "autologin_state": "no explicit autologin directive found",
            "autologin_user": "",
            "credential_secret_read": False,
        },
    }


def test_alpha39_system_page_shows_autologin_evidence(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert "PASS" in page.autologin_status_value.text()
    assert page.autologin_dm_value.text() == "sddm"
    assert "no explicit" in page.autologin_state_value.text()
    assert "ROOTFS PART 4 PASS" in page.status.text()


def test_alpha39_autologin_controls_default_to_preserve(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.autologin_operation.currentData() == "preserve"
    assert not page.autologin_target_user.isEnabled()
    assert "No password" in page.autologin_safety_value.text()


def test_alpha39_autologin_enable_stages(qapp, monkeypatch):
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    page.autologin_operation.setCurrentIndex(1)
    page.autologin_target_user.setText("chromatest")
    page.stage_autologin_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "system_autologin"
    assert change.payload["display_manager"] == "sddm"
    assert change.payload["target_user"] == "chromatest"
    assert change.payload["credential_secret_staged"] is False
    assert change.payload["require_target_user_verification_before_apply"] is True
