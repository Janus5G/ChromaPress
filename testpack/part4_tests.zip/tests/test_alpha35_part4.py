from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _installer_evidence


def test_alpha35_detects_calamares_from_manifest_without_guessing_distro():
    result = _installer_evidence(
        ["/casper/filesystem.squashfs", "/boot/grub/grub.cfg"],
        {"calamares": "3.3.14-0ubuntu1", "bash": "5.2"},
    )
    assert result["installer"] == "Calamares"
    assert result["installer_evidence"][0]["value"] == "calamares"
    assert "rootfs-level verification" in result["installer_modes"][1]


def test_alpha35_detects_native_config_paths_and_fails_closed_when_unknown():
    result = _installer_evidence(
        ["/nocloud/user-data", "/nocloud/meta-data", "/boot/grub/grub.cfg"],
        {},
    )
    assert result["installer"] == "unknown"
    assert "/nocloud/user-data" in result["installer_config_files"]
    assert result["installer_evidence"] == []


def test_alpha35_detects_subiquity_manifest_family():
    result = _installer_evidence([], {"subiquity": "24.04.1"})
    assert result["installer"] == "Subiquity/Autoinstall"
    assert "Autoinstall family detected" in result["installer_modes"]


def test_alpha35_version_markers_are_consistent():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
    main = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert 'from chromapress import __version__' in main
    assert 'QLabel(__version__)' in main
    assert 'PlaceholderPage("Installer"' not in main
