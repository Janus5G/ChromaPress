import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QMessageBox

from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _webauthn(cap="SUPPORTED_WITH_REQUIREMENTS"):
    supported = cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha64",
        "analysis_scope": "target_iso_package_manifest",
        "capability_status": cap,
        "verified": supported,
        "backend": "browser-webauthn-policy-intent",
        "package_format": "deb",
        "browser_packages": ["firefox"] if supported else [],
        "libfido2_packages": ["libfido2-1"] if supported else [],
        "supported_operations": ["allow_webauthn_for_recovery_web_workflows"] if supported else [],
        "policy_scope": "recovery_administrator_browser_webauthn",
        "alpha62_dependency_verified": supported,
        "alpha63_evidence_observed": True,
        "browser_config_contents_read": False,
        "webauthn_runtime_verified": False,
        "relying_party_config_read": False,
        "relying_party_verified": False,
        "origin_config_read": False,
        "origin_verified": False,
        "authenticator_devices_enumerated": False,
        "usb_hid_state_accessed": False,
        "credential_ids_read": False,
        "credential_secret_read": False,
        "credential_secret_staged": False,
        "authenticator_enrollment_performed": False,
        "security_key_presence_claimed": False,
        "yubikey_capability_claimed": False,
        "platform_authenticator_claimed": False,
        "tpm_capability_claimed": False,
        "host_browser_state_accessed": False,
        "host_authenticator_state_accessed": False,
        "source_read_only": True,
        "reason": "PASS" if supported else f"{cap} — blocked",
    }


def _admin():
    return {
        "gate_version": "alpha62",
        "capability_status": "SUPPORTED_WITH_REQUIREMENTS",
        "verified": True,
        "existing_admin_users": ["liveadmin"],
        "autologin_user": "kiosk",
    }


def _analysis(cap="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "sha256": "a" * 64,
        "system_admin_recovery_policy_evidence": _admin(),
        "system_fido2_policy_evidence": {"capability_status": "UNKNOWN"},
        "system_webauthn_policy_evidence": _webauthn(cap),
    }


def test_alpha64_stage_test_and_undo(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    changes = ChangesPanel(); page.stage_requested.connect(changes.add_change)
    page.webauthn_operation.setCurrentIndex(page.webauthn_operation.findData("allow_webauthn_for_recovery_web_workflows"))
    page.webauthn_username.setText("liveadmin")
    assert page.webauthn_browser.currentData() == "firefox"
    page.stage_webauthn_btn.click()
    assert len(changes.changes) == 1
    payload = changes.changes[0].payload
    assert payload["browser_package"] == "firefox"
    assert payload["webauthn_runtime_verified"] is False
    assert payload["relying_party_verified"] is False
    assert payload["origin_verified"] is False
    changes.list.setCurrentRow(0); changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == [] and changes.summary.text() == "No changes staged"


def test_alpha64_unknown_gui_fails_closed(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis("UNKNOWN"))
    emitted = []; page.stage_requested.connect(emitted.append)
    page.webauthn_operation.setCurrentIndex(page.webauthn_operation.findData("allow_webauthn_for_recovery_web_workflows"))
    page.webauthn_username.setText("liveadmin")
    page.stage_webauthn_btn.click()
    assert emitted == []
    assert "UNKNOWN" in page.webauthn_plan_status.text()


def test_alpha64_root_and_autologin_gui_are_blocked(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    emitted = []; page.stage_requested.connect(emitted.append)
    page.webauthn_operation.setCurrentIndex(page.webauthn_operation.findData("allow_webauthn_for_recovery_web_workflows"))
    page.webauthn_username.setText("root"); page.stage_webauthn_btn.click()
    page.webauthn_username.setText("kiosk"); page.stage_webauthn_btn.click()
    assert emitted == []
