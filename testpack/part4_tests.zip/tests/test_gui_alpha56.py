from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _login(capability="SUPPORTED_WITH_REQUIREMENTS"):
    supported = capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha56", "analysis_scope": "target_iso_rootfs", "capability_status": capability,
        "verified": supported, "backend": "shadow-utils-usermod" if supported else "",
        "management_tool_path": "/usr/sbin/usermod" if supported else "",
        "management_tool_layer": "/casper/minimal.squashfs" if supported else "",
        "passwd_layer": "/casper/minimal.squashfs" if supported else "",
        "group_layer": "/casper/minimal.squashfs" if supported else "",
        "existing_regular_users": ["ubuntu", "viewer"] if supported else [], "admin_users": ["ubuntu"] if supported else [],
        "supported_operations": ["lock_password_authentication"] if supported else [],
        "restriction_scope": "password_authentication_only", "shadow_read": False, "credential_secret_read": False,
        "host_login_state_accessed": False, "pam_contents_read": False, "ssh_config_read": False,
        "autologin_policy_read": False, "session_policy_read": False, "source_read_only": True,
        "reason": f"{capability} — test evidence",
    }


def _analysis(capability="SUPPORTED_WITH_REQUIREMENTS"):
    return {"sha256": "a" * 64, "package_format": "deb", "system_restricted_login_evidence": _login(capability)}


def _quiet(monkeypatch):
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.changes.QMessageBox.information", lambda *a, **k: None)


def _fill(page, username="chromakiosk56"):
    page.restricted_login_operation.setCurrentIndex(page.restricted_login_operation.findData("lock_password_authentication"))
    page.restricted_login_username.setText(username)


def test_alpha56_controls_are_narrow(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.restricted_login_operation.findData("lock_password_authentication") >= 0
    assert page.restricted_login_capability_value.text() == "SUPPORTED_WITH_REQUIREMENTS"
    assert "password authentication only" in page.restricted_login_scope_value.text().casefold()


def test_alpha56_changes_test_and_undo(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    _fill(page)
    page.stage_restricted_login_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.payload["account_dependency"] == "alpha55_dedicated_non_admin_kiosk_user"
    assert change.payload["password_authentication"] == "locked"
    assert change.payload["credential_secret_staged"] is False
    changes = ChangesPanel()
    changes.set_changes([])
    changes.add_change(change)
    changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == []


def test_alpha56_existing_non_admin_uses_verified_dependency(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    _fill(page, "viewer")
    page.stage_restricted_login_btn.click()
    assert emitted[0].payload["account_dependency"] == "verified_existing_target_user"


def test_alpha56_admin_user_is_blocked(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    _fill(page, "ubuntu")
    page.stage_restricted_login_btn.click()
    assert emitted == []


def test_alpha56_unknown_gui_staging_fails_closed(qapp, monkeypatch):
    _quiet(monkeypatch)
    page = SystemPage()
    page.set_analysis(_analysis("UNKNOWN"))
    emitted = []
    page.stage_requested.connect(emitted.append)
    _fill(page)
    page.stage_restricted_login_btn.click()
    assert emitted == []
