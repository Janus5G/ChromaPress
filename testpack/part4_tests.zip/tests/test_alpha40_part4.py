from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _parse_locale_assignments, _system_locale_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _good_payload() -> dict:
    return {
        "config_type": "system_locale",
        "source_sha256": "d" * 64,
        "operation": "configure_lang",
        "target_lang": "da_DK.UTF-8",
        "locale_config_path": "/etc/default/locale",
        "locale_config_layer": "/casper/minimal.standard.squashfs",
        "locale_config_style": "debian-default-locale",
        "current_lang": "en_US.UTF-8",
        "rootfs_locale_verified": True,
        "require_locale_availability_verification_before_apply": True,
        "preserve_language_and_lc_overrides": True,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def test_alpha40_locale_parser_limits_keys():
    values = _parse_locale_assignments('LANG="en_US.UTF-8"\nLANGUAGE=da:en\nLC_ALL=\nPATH=/secret/path\n')
    assert values == {"LANG": "en_US.UTF-8", "LANGUAGE": "da:en"}


def test_alpha40_locale_evidence_uses_rootfs_config(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"not-read-by-test")
    layers = ["/casper/minimal.standard.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (4096, 1234)})

    def fake_read(_iso: Path, _layers: list[str], member: str, _extents):
        if member == "/etc/default/locale":
            return 'LANG="en_US.UTF-8"\nLANGUAGE="en"\n', layers[0]
        if member == "/etc/locale.gen":
            return "en_US.UTF-8 UTF-8\n", layers[0]
        return "", ""

    monkeypatch.setattr("chromapress.engine_cli._read_squashfs_overlay_text", fake_read)
    monkeypatch.setattr("chromapress.engine_cli._read_locale_from_readonly_mount", lambda *a, **k: {})
    evidence = _system_locale_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["config_path"] == "/etc/default/locale"
    assert evidence["current_lang"] == "en_US.UTF-8"
    assert evidence["locale_gen_present"] is True
    assert evidence["secret_read"] is False


def test_alpha40_locale_preflight_passes():
    status, message = run_preflight(ChangeItem("Locale / language plan", ChangeKind.CONFIG, "test", _good_payload()))
    assert status == ChangeStatus.PASS
    assert "rootfs-evidence bound" in message
    assert "locale-availability gated" in message


def test_alpha40_locale_preflight_rejects_unsafe_or_unverified_values():
    payload = _good_payload()
    payload["target_lang"] = "da_DK.UTF-8;touch /tmp/x"
    status, _ = run_preflight(ChangeItem("Locale", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL

    payload = _good_payload()
    payload["rootfs_locale_verified"] = False
    status, _ = run_preflight(ChangeItem("Locale", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL
