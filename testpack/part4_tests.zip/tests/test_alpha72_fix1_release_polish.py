from pathlib import Path

from chromapress.engine_cli import _component_inventory


def test_alpha72_fix1_component_inventory_uses_manifest_evidence_and_protects_core():
    rows = _component_inventory({
        "linux-image-generic": "6.8.0",
        "libc6": "2.39",
        "python3": "3.12",
        "language-pack-en": "1",
        "network-manager": "1.46",
        "example-tool": "1.0",
    })
    by_name = {row["package"]: row for row in rows}
    assert by_name["linux-image-generic"]["category"] == "Kernel"
    assert by_name["linux-image-generic"]["protected"] is True
    assert by_name["libc6"]["protected"] is True
    assert by_name["python3"]["category"] == "Runtime"
    assert by_name["language-pack-en"]["category"] == "Language / locale"
    assert by_name["network-manager"]["category"] == "Service"
    assert all(row["source"] == "selected-image manifest" for row in rows)


def test_alpha72_fix1_components_placeholder_is_removed_and_license_is_present():
    root = Path(__file__).resolve().parents[1]
    main_window = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert 'PlaceholderPage("Components"' not in main_window
    assert "self.components = ComponentsPage()" in main_window
    assert (root / "src/chromapress/gui/components_page.py").is_file()
    license_text = (root / "LICENSE").read_text(encoding="utf-8")
    assert "MIT License" in license_text
    assert "Copyright (c) 2026 Janus Rokkjær" in license_text
    assert "Permission is hereby granted, free of charge" in license_text
    assert 'THE SOFTWARE IS PROVIDED "AS IS"' in license_text
    assert "ChromaPress Proprietary License" not in license_text


def test_alpha72_fix1_gui_components_about_and_icon():
    import pytest
    pytest.importorskip("PySide6")
    from PySide6.QtWidgets import QApplication
    from chromapress.gui.components_page import ComponentsPage
    from chromapress.gui.about_dialog import AboutDialog, chromapress_icon, license_text

    app = QApplication.instance() or QApplication([])
    page = ComponentsPage()
    assert page.tree.topLevelItemCount() == 0
    assert "Select and analyze" in page.status.text()
    page.set_analysis({
        "path": "E:/ISO/test.iso",
        "sha256": "abc",
        "component_inventory": [
            {"display_name": "python3", "package": "python3", "version": "3.12", "category": "Runtime", "protected": False, "protection_reason": "review"},
            {"display_name": "linux-image-generic", "package": "linux-image-generic", "version": "6.8", "category": "Kernel", "protected": True, "protection_reason": "protected"},
        ],
    })
    assert page.tree.topLevelItemCount() >= 2
    assert "INSTALLED_INVENTORY=READY" in page.status.text()
    assert not chromapress_icon().isNull()
    about = AboutDialog()
    assert about.windowTitle() == "About ChromaPress"
    assert not about.windowIcon().isNull()
    assert "MIT License" in license_text()
    assert "Permission is hereby granted, free of charge" in license_text()
    about.close()
    page.close()
    del app
