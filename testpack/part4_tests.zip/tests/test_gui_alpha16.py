from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QPushButton

from chromapress.gui.applications_page import ApplicationsPage
from chromapress.gui.changes import ChangesPanel
from chromapress.models import ChangeItem, ChangeKind
from chromapress.settings import AppSettings


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _buttons(page: ApplicationsPage, item):
    widget = page.tree.itemWidget(item, 4)
    return [button.text() for button in widget.findChildren(QPushButton)]


def test_every_installed_launcher_has_keep_remove_replace_not_preserved(qapp):
    page = ApplicationsPage(AppSettings())
    parent = page.tree.invisibleRootItem()
    unresolved = {
        "application": "ScreenGrab",
        "package": "",
        "desktop_file": "/usr/share/applications/screengrab.desktop",
        "description": "Screen capture",
        "state": "Installed",
        "ownership": "unresolved",
        "removable": False,
    }
    item = page._leaf_item(parent, unresolved)
    assert item.text(3) == "Installed"
    assert _buttons(page, item) == ["Keep", "Remove", "Replace"]
    assert "Preserved" not in [button.text() for button in page.findChildren(QPushButton)]


def test_changes_undo_still_has_selection_after_test_refresh(qapp, monkeypatch):
    panel = ChangesPanel()
    change = ChangeItem("Add AbiWord", ChangeKind.PACKAGE_REPOSITORY, "test", {"package": "abiword"})
    panel.add_change(change)
    assert panel.list.currentItem() is not None

    # Avoid opening a modal message box in the offscreen smoke test.
    monkeypatch.setattr("chromapress.gui.changes.QMessageBox.information", lambda *args, **kwargs: None)
    panel._test_selected()
    assert panel.list.currentItem() is not None
    assert panel.undo_btn.isEnabled()
    panel._undo_selected()
    assert panel.changes == []
    assert not panel.undo_btn.isEnabled()


def test_keep_can_undo_unresolved_staged_remove_by_target_ref(qapp):
    page = ApplicationsPage(AppSettings())
    page._catalog_loaded = False
    target = "/usr/share/applications/screengrab.desktop"
    page.set_staged_changes([
        ChangeItem(
            "Remove ScreenGrab", ChangeKind.PACKAGE_REMOVE, "test",
            {
                "application": "ScreenGrab", "package": "", "desktop_file": target,
                "target_ref": f"desktop:{target}",
            },
        )
    ])
    parent = page.tree.invisibleRootItem()
    item = page._leaf_item(parent, {
        "application": "ScreenGrab", "package": "", "desktop_file": target,
        "state": "Installed", "ownership": "unresolved",
    })
    assert item.text(3) == "Remove staged"
    buttons = page.tree.itemWidget(item, 4).findChildren(QPushButton)
    assert next(button for button in buttons if button.text() == "Remove").isChecked()
