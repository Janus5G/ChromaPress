from pathlib import Path
from chromapress.engine_cli import _system_platform_authenticator_policy_evidence
from chromapress.models import ChangeItem,ChangeKind,ChangeStatus
from chromapress.services.preflight import test_change as run_preflight
from chromapress_acceptance import AcceptanceRunner

def _e(): return _system_platform_authenticator_policy_evidence("deb",{"firefox":"1","libfido2-1":"1"},{"gate_version":"alpha62","capability_status":"SUPPORTED_WITH_REQUIREMENTS","verified":True,"shadow_read":False,"credential_secret_read":False,"recovery_secret_read":False,"pam_contents_read":False,"ssh_config_read":False,"rescue_boot_config_read":False,"root_account_policy_read":False,"host_accounts_touched":False,"host_login_state_accessed":False},{"gate_version":"alpha64","capability_status":"SUPPORTED_WITH_REQUIREMENTS","verified":True})
def _payload(cap="UNKNOWN",verified=False,scope="target_iso_package_manifest"):
    return {"config_type":"platform_authenticator_policy","gate_version":"alpha67","source_sha256":"a"*64,"analysis_scope":scope,"capability_status":cap,"platform_authenticator_policy_verified":verified,"operation":"allow_verified_platform_authenticator_for_recovery_workflows","policy_scope":"recovery_administrator_platform_authenticator","username":"recovery67","current_autologin_user":"","administrator_recovery_dependency":"alpha62_administrator_recovery_policy","alpha62_dependency_verified":True,"alpha64_dependency_verified":True,"platform_authenticator_runtime_verified":verified,"platform_authenticator_hardware_verified":verified,"biometric_capability_claimed":False,"tpm_capability_claimed":False,"credential_ids_read":False,"credential_secret_read":False,"credential_secret_staged":False,"authenticator_enrollment_performed":False,"host_authenticator_state_accessed":False,"preserve_existing_primary_authentication":True,"require_runtime_reverification_before_apply":True,"require_hardware_reverification_before_apply":True,"require_explicit_enrollment_before_use":True,"source_read_only":True,"preserve_unrelated":True,"stage_only":True}
def _run(p): return run_preflight(ChangeItem("Platform-authenticator policy",ChangeKind.CONFIG,"test",p))
def test_alpha67_static_analysis_truthfully_unknown():
    e=_e(); assert e["capability_status"]=="UNKNOWN" and e["verified"] is False and e["supported_operations"]==[]
    assert e["biometric_capability_claimed"] is False and e["tpm_capability_claimed"] is False
def test_alpha67_static_payload_fails_closed(): assert _run(_payload())[0]==ChangeStatus.FAIL
def test_alpha67_future_separately_verified_runtime_hardware_payload_can_pass(): assert _run(_payload("SUPPORTED_WITH_REQUIREMENTS",True,"verified_target_runtime_and_hardware"))[0]==ChangeStatus.PASS
def test_alpha67_never_accepts_biometric_or_tpm_inference():
    for key in ("biometric_capability_claimed","tpm_capability_claimed"):
        p=_payload("SUPPORTED_WITH_REQUIREMENTS",True,"verified_target_runtime_and_hardware"); p[key]=True; assert _run(p)[0]==ChangeStatus.FAIL
def test_alpha67_acceptance_unknown_is_pass(tmp_path):
    r=AcceptanceRunner(tmp_path,4,None,None,tmp_path/'r'); r._add_alpha67_platform_authenticator_gate(_e(),"a"*64); assert r.checks[-1].status=="PASS"
def test_alpha67_source_guard(): assert '"platform_authenticator_policy"' in (Path(__file__).resolve().parents[1]/'src/chromapress/gui/main_window.py').read_text()
