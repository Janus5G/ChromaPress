from __future__ import annotations

from pathlib import Path

from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as preflight_change


def _integration_plan(**overrides):
    payload = {
        "config_type": "runtime_integration",
        "source_sha256": "a" * 64,
        "base_layer": "/casper/minimal.squashfs",
        "integration_target": "controlled_persistence",
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "kernel_images": ["/casper/vmlinuz"],
        "initramfs_images": ["/casper/initrd"],
        "initramfs_mechanism": "update-initramfs",
        "boot_policy": "preserve_detected_boot_structure",
        "require_boot_config_reverification": True,
        "require_kernel_binding": True,
        "initramfs_policy": "verify_hook_then_regenerate",
        "require_initramfs_hook_verification": True,
        "require_initramfs_regeneration": True,
        "mount_policy": "resolve_label_or_uuid_before_persistent_binds",
        "require_mount_verification": True,
        "runtime_changes_survive_reboot": None,
        "selected_persistence_only": True,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }
    payload.update(overrides)
    return ChangeItem("Runtime integration verification plan", ChangeKind.CONFIG, "test", payload)


def test_alpha33_controlled_integration_is_exact_evidence_bound_and_stage_only():
    status, message = preflight_change(_integration_plan())
    assert status == ChangeStatus.PASS
    assert "source-hash locked" in message
    assert "exact-evidence bound" in message
    assert "boot-preserving" in message
    assert "staging-only" in message


def test_alpha33_volatile_integration_has_explicit_reboot_semantics():
    status, _ = preflight_change(_integration_plan(
        integration_target="volatile_overlay",
        mount_policy="none",
        require_mount_verification=False,
        runtime_changes_survive_reboot=False,
        selected_persistence_only=False,
    ))
    assert status == ChangeStatus.PASS


def test_alpha33_rejects_missing_or_unsafe_source_evidence():
    assert preflight_change(_integration_plan(boot_config_files=[]))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(kernel_images=[]))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(initramfs_images=[]))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(boot_config_files=["../grub.cfg"]))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(initramfs_mechanism="unknown"))[0] == ChangeStatus.FAIL


def test_alpha33_rejects_weakened_integration_gates():
    assert preflight_change(_integration_plan(boot_policy="replace"))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(require_boot_config_reverification=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(require_kernel_binding=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(require_initramfs_hook_verification=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(require_initramfs_regeneration=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(require_mount_verification=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(source_read_only=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_integration_plan(stage_only=False))[0] == ChangeStatus.FAIL


def test_alpha33_version_markers_are_consistent():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
    main_window = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert 'from chromapress import __version__' in main_window
    assert 'QLabel(__version__)' in main_window
