import os; os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
import pytest; pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication,QMessageBox
from chromapress.gui.system_page import SystemPage
from chromapress.gui.changes import ChangesPanel
from chromapress.models import ChangeStatus
@pytest.fixture(scope="module")
def qapp(): return QApplication.instance() or QApplication([])
def _admin(): return {"gate_version":"alpha62","capability_status":"SUPPORTED_WITH_REQUIREMENTS","verified":True,"existing_admin_users":["liveadmin"],"autologin_user":"kiosk"}
def _e(cap="SUPPORTED_WITH_REQUIREMENTS"):
    ok=cap in {"SUPPORTED","SUPPORTED_WITH_REQUIREMENTS"}; return {"gate_version":"alpha65","capability_status":cap,"verified":ok,"security_key_tool_packages":["fido2-tools"] if ok else [],"libfido2_packages":["libfido2-1"] if ok else [],"alpha62_dependency_verified":ok,"alpha63_dependency_verified":ok,"reason":cap}
def _analysis(cap="SUPPORTED_WITH_REQUIREMENTS"): return {"sha256":"a"*64,"system_admin_recovery_policy_evidence":_admin(),"system_security_key_policy_evidence":_e(cap)}
def test_alpha65_stage_test_undo(qapp,monkeypatch):
    monkeypatch.setattr(QMessageBox,"information",lambda *a,**k:None); monkeypatch.setattr(QMessageBox,"warning",lambda *a,**k:None)
    page=SystemPage(); page.set_analysis(_analysis()); changes=ChangesPanel(); page.stage_requested.connect(changes.add_change)
    page.security_key_operation.setCurrentIndex(page.security_key_operation.findData("allow_external_fido2_security_key_for_recovery_admin")); page.security_key_username.setText("liveadmin"); page.stage_security_key_btn.click()
    assert len(changes.changes)==1 and changes.changes[0].payload["security_key_presence_claimed"] is False
    changes.list.setCurrentRow(0); changes._test_selected(); assert changes.changes[0].status==ChangeStatus.PASS
    changes._undo_selected(); assert changes.changes==[]
def test_alpha65_unknown_gui_fails_closed(qapp,monkeypatch):
    monkeypatch.setattr(QMessageBox,"information",lambda *a,**k:None); monkeypatch.setattr(QMessageBox,"warning",lambda *a,**k:None)
    page=SystemPage(); page.set_analysis(_analysis("UNKNOWN")); out=[]; page.stage_requested.connect(out.append)
    page.security_key_operation.setCurrentIndex(page.security_key_operation.findData("allow_external_fido2_security_key_for_recovery_admin")); page.security_key_username.setText("liveadmin"); page.stage_security_key_btn.click()
    assert out==[] and "UNKNOWN" in page.security_key_plan_status.text()
