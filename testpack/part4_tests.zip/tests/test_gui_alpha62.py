import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QMessageBox

from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _evidence(cap="SUPPORTED_WITH_REQUIREMENTS"):
    supported = cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}
    return {
        "gate_version": "alpha62", "analysis_scope": "target_iso_rootfs",
        "capability_status": cap, "verified": supported,
        "backend": "passwd-group-policy", "passwd_layer": "/casper/minimal.squashfs" if supported else "",
        "group_layer": "/casper/minimal.squashfs" if supported else "",
        "admin_groups": ["sudo"] if supported else [],
        "existing_regular_users": ["liveadmin", "student"] if supported else [],
        "existing_admin_users": ["liveadmin"] if supported else [],
        "autologin_user": "kiosk" if supported else "",
        "supported_operations": ["require_dedicated_recovery_administrator"] if supported else [],
        "policy_scope": "separate_non_autologin_recovery_administrator",
        "shadow_read": False, "credential_secret_read": False, "recovery_secret_read": False,
        "pam_contents_read": False, "ssh_config_read": False, "rescue_boot_config_read": False,
        "root_account_policy_read": False, "host_accounts_touched": False,
        "host_login_state_accessed": False, "source_read_only": True,
        "reason": "PASS" if supported else f"{cap} — blocked",
    }


def _analysis(cap="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "sha256": "a" * 64,
        "system_admin_recovery_policy_evidence": _evidence(cap),
    }


def test_alpha62_new_recovery_admin_stage_test_and_undo(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    changes = ChangesPanel(); page.stage_requested.connect(changes.add_change)
    page.admin_recovery_operation.setCurrentIndex(page.admin_recovery_operation.findData("require_dedicated_recovery_administrator"))
    page.admin_recovery_username.setText("chromarecovery62")
    page.stage_admin_recovery_btn.click()
    assert len(changes.changes) == 1
    assert changes.changes[0].payload["account_dependency"] == "alpha50_create_administrator"
    changes.list.setCurrentRow(0); changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == [] and changes.summary.text() == "No changes staged"


def test_alpha62_existing_verified_admin_uses_existing_dependency(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    emitted = []; page.stage_requested.connect(emitted.append)
    page.admin_recovery_operation.setCurrentIndex(page.admin_recovery_operation.findData("require_dedicated_recovery_administrator"))
    page.admin_recovery_username.setText("liveadmin")
    page.stage_admin_recovery_btn.click()
    assert len(emitted) == 1
    assert emitted[0].payload["account_dependency"] == "verified_existing_admin_user"


def test_alpha62_explicit_autologin_user_is_blocked(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    emitted = []; page.stage_requested.connect(emitted.append)
    page.admin_recovery_operation.setCurrentIndex(page.admin_recovery_operation.findData("require_dedicated_recovery_administrator"))
    page.admin_recovery_username.setText("kiosk")
    page.stage_admin_recovery_btn.click()
    assert emitted == []


def test_alpha62_existing_non_admin_is_blocked(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    emitted = []; page.stage_requested.connect(emitted.append)
    page.admin_recovery_operation.setCurrentIndex(page.admin_recovery_operation.findData("require_dedicated_recovery_administrator"))
    page.admin_recovery_username.setText("student")
    page.stage_admin_recovery_btn.click()
    assert emitted == []


def test_alpha62_unknown_gui_fails_closed(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis("UNKNOWN"))
    emitted = []; page.stage_requested.connect(emitted.append)
    page.admin_recovery_operation.setCurrentIndex(page.admin_recovery_operation.findData("require_dedicated_recovery_administrator"))
    page.admin_recovery_username.setText("chromarecovery62")
    page.stage_admin_recovery_btn.click()
    assert emitted == []
    assert "UNKNOWN" in page.admin_recovery_plan_status.text()
