from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_network_dns_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _good_payload() -> dict:
    return {
        "config_type": "system_network_dns",
        "source_sha256": "a" * 64,
        "operation": "configure_dns_servers",
        "target_dns_servers": ["1.1.1.1", "1.0.0.1"],
        "network_backend": "NetworkManager",
        "backend_config_path": "/etc/NetworkManager/NetworkManager.conf",
        "backend_config_layer": "/casper/minimal.standard.squashfs",
        "resolver_path": "/etc/resolv.conf",
        "resolver_layer": "/casper/minimal.standard.squashfs",
        "rootfs_network_dns_verified": True,
        "require_backend_specific_apply_verification": True,
        "preserve_connection_profiles": True,
        "preserve_ip_dhcp_routes": True,
        "connection_profiles_inspected": False,
        "wifi_vpn_secrets_read": False,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def test_alpha43_network_evidence_uses_metadata_only(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"not-read-by-test")
    layers = ["/casper/minimal.standard.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (4096, 1234)})
    seen = []

    def fake_present(_iso: Path, _layers: list[str], member: str, _extents):
        seen.append(member)
        if member in {"/etc/NetworkManager/NetworkManager.conf", "/etc/resolv.conf"}:
            return True, layers[0]
        return False, ""

    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", fake_present)
    monkeypatch.setattr("chromapress.engine_cli._inspect_network_dns_from_readonly_mount", lambda *a, **k: {})
    evidence = _system_network_dns_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["backend"] == "NetworkManager"
    assert evidence["resolver_path"] == "/etc/resolv.conf"
    assert evidence["connection_profiles_inspected"] is False
    assert evidence["wifi_vpn_secrets_read"] is False
    assert not any("system-connections" in item or "netplan" in item for item in seen)


def test_alpha43_network_preflight_passes():
    status, message = run_preflight(ChangeItem("Networking / DNS plan", ChangeKind.CONFIG, "test", _good_payload()))
    assert status == ChangeStatus.PASS
    assert "rootfs-evidence bound" in message
    assert "connection-profile/secret preserving" in message


def test_alpha43_network_preflight_rejects_invalid_dns_or_profile_inspection():
    payload = _good_payload()
    payload["target_dns_servers"] = ["not-an-ip"]
    status, _ = run_preflight(ChangeItem("Networking / DNS plan", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL

    payload = _good_payload()
    payload["connection_profiles_inspected"] = True
    status, _ = run_preflight(ChangeItem("Networking / DNS plan", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL


def test_alpha43_version_locked():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
