import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication, QMessageBox

from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    return app


def _evidence(cap="SUPPORTED_WITH_REQUIREMENTS"):
    return {
        "gate_version": "alpha59", "analysis_scope": "target_iso_rootfs", "capability_status": cap,
        "verified": cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"},
        "backend": "NetworkManager-polkit-managed-rule" if cap in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"} else "",
        "network_backend": "NetworkManager", "polkit_rules_directory": "/etc/polkit-1/rules.d",
        "polkit_rules_directory_layer": "/casper/minimal.squashfs",
        "networkmanager_policy_path": "/usr/share/polkit-1/actions/org.freedesktop.NetworkManager.policy",
        "networkmanager_policy_layer": "/casper/minimal.squashfs",
        "managed_rule_name": "49-chromapress-kiosk-network.rules",
        "managed_rule_path": "/etc/polkit-1/rules.d/49-chromapress-kiosk-network.rules",
        "managed_target_present": False, "existing_rule_names": ["10-vendor.rules"],
        "restricted_actions": [
            "org.freedesktop.NetworkManager.enable-disable-network", "org.freedesktop.NetworkManager.enable-disable-wifi",
            "org.freedesktop.NetworkManager.enable-disable-wwan", "org.freedesktop.NetworkManager.settings.modify.system",
        ],
        "traffic_blocking_claimed": False, "firewall_rules_read": False, "firewall_rules_staged": False,
        "networkmanager_profile_contents_read": False, "polkit_policy_contents_read": False,
        "existing_rule_contents_read": False, "credential_secret_read": False, "host_network_accessed": False,
        "source_read_only": True, "reason": "PASS" if cap.startswith("SUPPORTED") else f"{cap} — blocked",
    }


def _analysis(cap="SUPPORTED_WITH_REQUIREMENTS"):
    return {"sha256": "a" * 64, "package_format": "deb", "system_network_restriction_evidence": _evidence(cap)}


def test_alpha59_changes_stage_test_and_undo(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis())
    changes = ChangesPanel(); page.stage_requested.connect(changes.add_change)
    page.network_restriction_operation.setCurrentIndex(page.network_restriction_operation.findData("restrict_kiosk_networkmanager_control"))
    page.network_restriction_username.setText("chromakiosk59")
    page.stage_network_restriction_btn.click()
    assert len(changes.changes) == 1
    changes.list.setCurrentRow(0); changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == [] and changes.summary.text() == "No changes staged"


def test_alpha59_unknown_gui_fails_closed(qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: None)
    page = SystemPage(); page.set_analysis(_analysis("UNKNOWN"))
    emitted=[]; page.stage_requested.connect(emitted.append)
    page.network_restriction_operation.setCurrentIndex(page.network_restriction_operation.findData("restrict_kiosk_networkmanager_control"))
    page.network_restriction_username.setText("chromakiosk59")
    page.stage_network_restriction_btn.click()
    assert emitted == []
    assert "UNKNOWN" in page.network_restriction_plan_status.text()
