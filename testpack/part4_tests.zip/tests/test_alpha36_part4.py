from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_config_evidence


def test_alpha36_system_evidence_is_manifest_backed_and_structured():
    result = _system_config_evidence({
        "sudo": "1.9.15",
        "network-manager": "1.46.0",
        "systemd": "255.4",
        "ufw": "0.36.2",
        "apparmor": "4.0.1",
        "procps": "2:4.0.4",
        "libfido2-1": "1.14.0",
        "tpm2-tools": "5.7",
        "unrelated-package": "1.0",
    })
    evidence = result["system_package_evidence"]
    areas = {item["area"] for item in evidence}
    assert "Identity / accounts" in areas
    assert "Networking / DNS" in areas
    assert "Services / startup" in areas
    assert "Firewall" in areas
    assert "AppArmor" in areas
    assert "sysctl / kernel settings" in areas
    assert "FIDO2 / security keys" in areas
    assert "TPM-backed credentials" in areas
    assert all(item["package"] != "unrelated-package" for item in evidence)


def test_alpha36_system_state_is_not_inferred_from_package_presence():
    result = _system_config_evidence({"systemd": "255", "network-manager": "1.46"})
    gates = result["system_rootfs_verification"]
    assert any("users/groups" in gate for gate in gates)
    assert any("NetworkManager profiles" in gate for gate in gates)
    assert any("systemd services" in gate for gate in gates)
    assert any("administrator/recovery" in gate for gate in gates)
    assert any("FIDO2/WebAuthn" in gate for gate in gates)


def test_alpha36_version_and_part_mapping_are_consistent():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
    main = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    installer = (root / "src/chromapress/gui/installer_page.py").read_text(encoding="utf-8")
    assert 'from chromapress import __version__' in main
    assert 'QLabel(__version__)' in main
    assert 'PlaceholderPage("System"' not in main
    assert "Part 5" in installer
