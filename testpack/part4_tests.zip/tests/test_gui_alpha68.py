import os; os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
import pytest; pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication,QMessageBox
from chromapress.gui.system_page import SystemPage
from chromapress.gui.changes import ChangesPanel
from chromapress.models import ChangeStatus
@pytest.fixture(scope="module")
def qapp(): return QApplication.instance() or QApplication([])
def _a(cap="SUPPORTED_WITH_REQUIREMENTS"):
    ok=cap in {"SUPPORTED","SUPPORTED_WITH_REQUIREMENTS"}; return {"sha256":"a"*64,"system_admin_recovery_policy_evidence":{"gate_version":"alpha62","capability_status":"SUPPORTED_WITH_REQUIREMENTS","verified":True,"existing_admin_users":["liveadmin"],"autologin_user":"kiosk"},"system_tpm_key_protection_evidence":{"gate_version":"alpha68","capability_status":cap,"verified":ok,"alpha62_dependency_verified":ok,"tpm_tool_packages":["tpm2-tools"] if ok else [],"tss_packages":["libtss2-esys-3.0.2-0"] if ok else [],"reason":cap}}
def test_alpha68_stage_test_undo(qapp,monkeypatch):
    monkeypatch.setattr(QMessageBox,"information",lambda *a,**k:None); monkeypatch.setattr(QMessageBox,"warning",lambda *a,**k:None)
    p=SystemPage(); p.set_analysis(_a()); c=ChangesPanel(); p.stage_requested.connect(c.add_change); p.tpm_operation.setCurrentIndex(p.tpm_operation.findData("require_tpm_backed_recovery_key_protection")); p.tpm_username.setText("liveadmin"); p.stage_tpm_btn.click(); assert len(c.changes)==1 and c.changes[0].payload["tpm_hardware_verified"] is False and c.changes[0].payload["biometric_capability_claimed"] is False
    c.list.setCurrentRow(0); c._test_selected(); assert c.changes[0].status==ChangeStatus.PASS; c._undo_selected(); assert c.changes==[]
def test_alpha68_unknown_gui_fails_closed(qapp,monkeypatch):
    monkeypatch.setattr(QMessageBox,"information",lambda *a,**k:None); p=SystemPage(); p.set_analysis(_a("UNKNOWN")); out=[]; p.stage_requested.connect(out.append); p.tpm_operation.setCurrentIndex(p.tpm_operation.findData("require_tpm_backed_recovery_key_protection")); p.tpm_username.setText("liveadmin"); p.stage_tpm_btn.click(); assert out==[] and "UNKNOWN" in p.tpm_plan_status.text()
