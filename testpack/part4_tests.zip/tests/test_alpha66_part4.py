from pathlib import Path
import pytest
from chromapress.engine_cli import _system_yubikey_policy_evidence
from chromapress.models import ChangeItem,ChangeKind,ChangeStatus
from chromapress.services.preflight import test_change as run_preflight
from chromapress_acceptance import AcceptanceRunner

def _admin(): return {"gate_version":"alpha62","capability_status":"SUPPORTED_WITH_REQUIREMENTS","verified":True,"existing_admin_users":["liveadmin"],"autologin_user":"kiosk","shadow_read":False,"credential_secret_read":False,"recovery_secret_read":False,"pam_contents_read":False,"ssh_config_read":False,"rescue_boot_config_read":False,"root_account_policy_read":False,"host_accounts_touched":False,"host_login_state_accessed":False}
def _sk(): return {"gate_version":"alpha65","capability_status":"SUPPORTED_WITH_REQUIREMENTS","verified":True}
def _e(pkg=True): return _system_yubikey_policy_evidence("deb",{"yubikey-manager":"5.1"} if pkg else {"base-files":"1"},_admin(),_sk())
def _payload(e=None):
    e=dict(e or _e()); return {"config_type":"yubikey_policy","gate_version":"alpha66","source_sha256":"a"*64,"analysis_scope":"target_iso_package_manifest","capability_status":e.get("capability_status"),"yubikey_policy_verified":e.get("verified") is True,"operation":"allow_yubikey_class_authenticator_for_recovery_admin","policy_scope":"recovery_administrator_yubikey_class","username":"liveadmin","current_autologin_user":"kiosk","administrator_recovery_dependency":"alpha62_administrator_recovery_policy","alpha62_dependency_verified":e.get("alpha62_dependency_verified") is True,"alpha65_evidence_observed":e.get("alpha65_evidence_observed") is True,"yubikey_packages":list(e.get("yubikey_packages") or []),"physical_yubikey_enumerated":False,"yubikey_presence_claimed":False,"serial_number_read":False,"otp_secret_read":False,"pin_secret_read":False,"credential_ids_read":False,"credential_secret_read":False,"credential_secret_staged":False,"authenticator_enrollment_performed":False,"usb_hid_state_accessed":False,"platform_authenticator_claimed":False,"tpm_capability_claimed":False,"host_authenticator_state_accessed":False,"preserve_existing_primary_authentication":True,"require_physical_yubikey_verification_before_apply":True,"require_vendor_mode_compatibility_verification_before_apply":True,"require_explicit_enrollment_before_use":True,"require_recovery_username_reverification_before_apply":True,"require_target_package_reverification_before_apply":True,"source_read_only":True,"preserve_unrelated":True,"stage_only":True}
def _run(p): return run_preflight(ChangeItem("YubiKey-class policy plan",ChangeKind.CONFIG,"test",p))
def test_alpha66_yubikey_package_is_requirements_only():
    e=_e(); assert e["capability_status"]=="SUPPORTED_WITH_REQUIREMENTS" and e["yubikey_packages"]==["yubikey-manager"] and e["yubikey_presence_claimed"] is False
def test_alpha66_missing_vendor_tooling_unknown(): assert _e(False)["capability_status"]=="UNKNOWN"
def test_alpha66_supported_preflight_passes(): assert _run(_payload())[0]==ChangeStatus.PASS
@pytest.mark.parametrize("key",["physical_yubikey_enumerated","yubikey_presence_claimed","serial_number_read","otp_secret_read","pin_secret_read","credential_secret_read","authenticator_enrollment_performed","usb_hid_state_accessed","platform_authenticator_claimed","tpm_capability_claimed"])
def test_alpha66_sensitive_claims_fail(key):
    p=_payload(); p[key]=True; assert _run(p)[0]==ChangeStatus.FAIL
def test_alpha66_unknown_fails_closed():
    e=_e(); e["capability_status"]="UNKNOWN"; e["verified"]=False; assert _run(_payload(e))[0]==ChangeStatus.FAIL
def test_alpha66_acceptance(tmp_path):
    r=AcceptanceRunner(tmp_path,4,None,None,tmp_path/'r'); r._add_alpha66_yubikey_gate(_e(),_admin(),"a"*64); assert r.checks[-1].status=="PASS"
def test_alpha66_source_guard(): assert '"yubikey_policy"' in (Path(__file__).resolve().parents[1]/'src/chromapress/gui/main_window.py').read_text()
