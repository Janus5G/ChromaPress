from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeKind


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis() -> dict:
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_package_evidence": [{"area": "Locale / keyboard / timezone", "package": "tzdata", "version": "2026a"}],
        "system_rootfs_verification": ["network profiles remain gated"],
        "system_identity_evidence": {"verified": True, "reason": "PASS — identity", "passwd_layer": "/casper/minimal.standard.squashfs", "group_layer": "/casper/minimal.standard.squashfs", "uid_min": 1000, "regular_users": [], "admin_groups": ["sudo"], "shadow_read": False},
        "system_machine_identity_evidence": {"verified": True, "reason": "PASS — machine", "hostname": "lubuntu", "hostname_layer": "/casper/minimal.standard.squashfs", "machine_id_state": "present", "machine_id_layer": "/casper/minimal.squashfs", "machine_id_value_exposed": False},
        "system_autologin_evidence": {"verified": True, "reason": "PASS — autologin", "display_manager": "sddm", "display_manager_layer": "/casper/minimal.standard.squashfs", "autologin_state": "no explicit autologin directive found", "autologin_user": "", "credential_secret_read": False},
        "system_locale_evidence": {"verified": True, "reason": "PASS — locale", "config_path": "/etc/default/locale", "config_layer": "/casper/minimal.standard.squashfs", "config_style": "debian-default-locale", "current_lang": "en_US.UTF-8", "current_language": "en", "current_lc_all": "", "locale_gen_present": True, "secret_read": False},
        "system_keyboard_evidence": {"verified": True, "reason": "PASS — keyboard", "config_path": "/etc/default/keyboard", "config_layer": "/casper/minimal.standard.squashfs", "config_style": "debian-default-keyboard", "current_layout": "us", "current_model": "pc105", "current_variant": "", "current_options": "", "secret_read": False},
        "system_timezone_evidence": {"verified": True, "reason": "PASS — timezone", "config_path": "/etc/timezone", "config_layer": "/casper/minimal.standard.squashfs", "config_style": "debian-timezone", "current_timezone": "Etc/UTC", "localtime_present": True, "secret_read": False},
    }


def test_alpha42_system_page_shows_timezone_evidence(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert "PASS" in page.timezone_status_value.text()
    assert page.timezone_path_value.text() == "/etc/timezone"
    assert page.timezone_current_value.text() == "Etc/UTC"
    assert "ROOTFS PART 4 PASS" in page.status.text()


def test_alpha42_timezone_controls_default_to_preserve(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.timezone_operation.currentData() == "preserve"
    assert not page.timezone_target.isEnabled()
    assert "RTC" in page.timezone_policy_value.text()


def test_alpha42_timezone_stages(qapp, monkeypatch):
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    page.timezone_operation.setCurrentIndex(1)
    page.timezone_target.setText("Europe/Copenhagen")
    page.stage_timezone_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "system_timezone"
    assert change.payload["target_timezone"] == "Europe/Copenhagen"
    assert change.payload["preserve_hwclock_rtc_policy"] is True
    assert change.payload["require_zoneinfo_verification_before_apply"] is True
