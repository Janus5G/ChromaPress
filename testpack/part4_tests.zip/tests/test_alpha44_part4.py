from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_services_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _good_payload() -> dict:
    return {
        "config_type": "system_services",
        "source_sha256": "a" * 64,
        "operation": "enable_service",
        "service_unit": "NetworkManager.service",
        "init_system": "systemd",
        "vendor_unit_path": "/usr/lib/systemd/system",
        "vendor_unit_layer": "/casper/minimal.standard.squashfs",
        "local_unit_path": "/etc/systemd/system",
        "local_unit_layer": "/casper/minimal.standard.squashfs",
        "rootfs_services_verified": True,
        "require_target_unit_verification_before_apply": True,
        "preserve_unit_file_contents": True,
        "preserve_timers_targets": True,
        "unit_contents_read": False,
        "enablement_links_read": False,
        "service_secrets_read": False,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def test_alpha44_services_evidence_is_metadata_only(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"not-read-by-test")
    layers = ["/casper/minimal.standard.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (4096, 1234)})
    seen = []

    def fake_present(_iso: Path, _layers: list[str], member: str, _extents):
        seen.append(member)
        if member in {"/usr/lib/systemd/system", "/etc/systemd/system"}:
            return True, layers[0]
        return False, ""

    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", fake_present)
    monkeypatch.setattr("chromapress.engine_cli._inspect_services_from_readonly_mount", lambda *a, **k: {})
    evidence = _system_services_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["init_system"] == "systemd"
    assert evidence["vendor_unit_path"] == "/usr/lib/systemd/system"
    assert evidence["unit_contents_read"] is False
    assert evidence["enablement_links_read"] is False
    assert all(not item.endswith(".service") for item in seen)


def test_alpha44_services_preflight_passes():
    status, message = run_preflight(ChangeItem("Services / systemd plan", ChangeKind.CONFIG, "test", _good_payload()))
    assert status == ChangeStatus.PASS
    assert "rootfs-evidence bound" in message
    assert "target-unit-verification gated" in message


def test_alpha44_services_preflight_rejects_unsafe_unit_or_content_read():
    payload = _good_payload()
    payload["service_unit"] = "../evil.service"
    status, _ = run_preflight(ChangeItem("Services / systemd plan", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL

    payload = _good_payload()
    payload["unit_contents_read"] = True
    status, _ = run_preflight(ChangeItem("Services / systemd plan", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL


def test_alpha44_version_locked():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
