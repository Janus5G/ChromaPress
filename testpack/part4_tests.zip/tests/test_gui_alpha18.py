from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.applications_page import ApplicationsPage
from chromapress.settings import AppSettings


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _page(qapp, scenario: str) -> ApplicationsPage:
    page = ApplicationsPage(AppSettings())
    page._source = {"distribution": "Lubuntu", "version": "26.04.1", "path": "test.iso"}
    page._catalog = [
        {"application": "About LXQt", "package": "lxqt-about", "description": "About LXQt", "categories": ["System"]},
    ]
    page._catalog_loaded = True
    page.set_scenario(scenario)
    return page


def _texts(page: ApplicationsPage) -> list[str]:
    out = []
    def walk(item):
        out.append(item.text(0))
        for i in range(item.childCount()):
            walk(item.child(i))
    for i in range(page.tree.topLevelItemCount()):
        walk(page.tree.topLevelItem(i))
    return out


def test_school_profile_is_a_separate_visible_choice(qapp):
    page = _page(qapp, "education")
    assert "education" in page.scenario_buttons
    assert page.scenario_buttons["education"].text() == "School / Education"
    assert page.scenario_buttons["education"].isChecked()
    assert page.scenario_buttons["gaming_team"].text() == "Gaming / Team"
