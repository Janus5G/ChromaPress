from __future__ import annotations

from pathlib import Path

from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as preflight_change


def _persistence_plan(**overrides):
    payload = {
        "config_type": "controlled_persistence",
        "source_sha256": "a" * 64,
        "base_layer": "/casper/minimal.squashfs",
        "runtime_mode": "volatile_overlay_with_controlled_persistence",
        "writable_layer": "tmpfs",
        "persistence_policy": "selected_directories",
        "persistent_directories": ["/var/lib/app", "/home/kiosk/data"],
        "selected_directories_survive_reboot": True,
        "unlisted_runtime_changes_survive_reboot": False,
        "backing_storage": "dedicated_volume",
        "volume_scope": "target_system",
        "volume_size_mib": 4096,
        "filesystem": "ext4",
        "volume_label": "CHROMAPERSIST",
        "initramfs_mechanism": "update-initramfs",
        "require_initramfs_integration": True,
        "require_boot_integration": True,
        "require_mount_verification": True,
        "do_not_repartition_source_iso": True,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }
    payload.update(overrides)
    return ChangeItem("Controlled persistence plan", ChangeKind.CONFIG, "test", payload)


def test_alpha32_controlled_persistence_is_explicit_and_stage_only():
    status, message = preflight_change(_persistence_plan())
    assert status == ChangeStatus.PASS
    assert "source-hash locked" in message
    assert "selected-directory scoped" in message
    assert "reboot-survival explicit" in message
    assert "staging-only" in message


def test_alpha32_rejects_unsafe_or_missing_persistence_paths():
    assert preflight_change(_persistence_plan(persistent_directories=[]))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(persistent_directories=["relative/path"]))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(persistent_directories=["/var/../etc"]))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(persistent_directories=["/proc/state"]))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(persistent_directories=["/var/lib/app", "/var/lib/app"]))[0] == ChangeStatus.FAIL


def test_alpha32_reboot_and_volume_semantics_are_fail_closed():
    assert preflight_change(_persistence_plan(selected_directories_survive_reboot=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(unlisted_runtime_changes_survive_reboot=True))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(backing_storage="host_folder"))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(volume_scope="source_iso"))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(volume_size_mib=128))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(filesystem="ntfs"))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(volume_label="bad label"))[0] == ChangeStatus.FAIL


def test_alpha32_requires_integration_and_source_preservation():
    assert preflight_change(_persistence_plan(initramfs_mechanism="unknown"))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(require_initramfs_integration=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(require_boot_integration=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(require_mount_verification=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(do_not_repartition_source_iso=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(source_read_only=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(preserve_unrelated=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_persistence_plan(stage_only=False))[0] == ChangeStatus.FAIL


def test_alpha32_version_markers_are_consistent():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
    main_window = (root / "src/chromapress/gui/main_window.py").read_text(encoding="utf-8")
    assert 'from chromapress import __version__' in main_window
    assert 'QLabel(__version__)' in main_window
