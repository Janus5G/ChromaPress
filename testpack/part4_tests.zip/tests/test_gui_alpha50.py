from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.changes import ChangesPanel
from chromapress.gui.system_page import SystemPage
from chromapress.models import ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis() -> dict:
    return {
        "sha256": "a" * 64,
        "package_format": "deb",
        "system_rootfs_verification": ["remaining security gates continue later"],
        "system_identity_evidence": {
            "gate_version": "alpha50",
            "analysis_scope": "target_iso_rootfs",
            "capability_status": "SUPPORTED_WITH_REQUIREMENTS",
            "users_groups_status": "SUPPORTED_WITH_REQUIREMENTS",
            "uid_gid_status": "SUPPORTED_WITH_REQUIREMENTS",
            "group_membership_status": "SUPPORTED_WITH_REQUIREMENTS",
            "password_policy_status": "SUPPORTED_WITH_REQUIREMENTS",
            "verified": True,
            "reason": "PASS — Alpha 50 target-rootfs users/groups evidence",
            "passwd_layer": "/casper/minimal.squashfs",
            "group_layer": "/casper/minimal.squashfs",
            "login_defs_layer": "/casper/minimal.squashfs",
            "uid_min": 1000,
            "regular_users": ["lubuntu"],
            "user_records": [{"username": "lubuntu", "uid": 1000, "gid": 1000, "display_name": "Lubuntu", "primary_group": "lubuntu", "groups": ["lubuntu", "sudo"]}],
            "groups": ["sudo", "users", "lubuntu"],
            "group_records": [{"name": "sudo", "gid": 27, "members": ["lubuntu"]}, {"name": "users", "gid": 100, "members": []}, {"name": "lubuntu", "gid": 1000, "members": []}],
            "admin_groups": ["sudo"],
            "default_user_candidate": "lubuntu",
            "password_policy": {"min_days": 0, "max_days": 99999, "warn_days": 7, "encrypt_method": "SHA512"},
            "host_accounts_touched": False,
            "shadow_read": False,
            "credential_secret_read": False,
            "source_read_only": True,
        },
    }


def test_alpha50_quick_mode_is_safe_and_hides_deep_controls(qapp):
    page = SystemPage()
    page.set_analysis(_analysis())
    assert page.identity_depth.currentData() == "quick"
    assert page.identity_operation.findData("create_group") == -1
    assert page.identity_advanced_box.isHidden()
    assert "SUPPORTED_WITH_REQUIREMENTS" in page.identity_capability_value.text()
    assert "lubuntu" in page.identity_users_value.text()
    assert "max=99999d" in page.identity_password_policy_value.text()


def test_alpha50_advanced_create_user_stages_uid_groups_admin_and_policy_without_secret(qapp, monkeypatch):
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)

    page.identity_depth.setCurrentIndex(page.identity_depth.findData("advanced"))
    page.identity_operation.setCurrentIndex(page.identity_operation.findData("create_user"))
    page.identity_username.setText("chromatest")
    page.identity_display_name.setText("Chroma Test")
    page.identity_role.setCurrentIndex(page.identity_role.findData("administrator"))
    page.identity_admin_group.setCurrentIndex(page.identity_admin_group.findData("sudo"))
    page.identity_uid.setText("1500")
    page.identity_gid.setText("100")
    page.identity_supplementary_groups.setText("users")
    page.identity_password_min_days.setText("1")
    page.identity_password_max_days.setText("365")
    page.identity_password_warn_days.setText("14")
    page.stage_identity_btn.click()

    assert len(emitted) == 1
    payload = emitted[0].payload
    assert payload["gate_version"] == "alpha50"
    assert payload["operation"] == "create_user"
    assert payload["uid"] == 1500
    assert payload["primary_gid"] == 100
    assert payload["supplementary_groups"] == ["users"]
    assert payload["admin_group"] == "sudo"
    assert payload["password_policy"] == {"mode": "configure", "min_days": 1, "max_days": 365, "warn_days": 14}
    assert payload["preserve_autologin"] is True
    assert payload["host_accounts_touched"] is False
    assert payload["credential_secret_read"] is False
    assert payload["credential_secret_staged"] is False
    lowered_keys = {str(k).casefold() for k in payload}
    assert "password" not in lowered_keys and "password_hash" not in lowered_keys and "secret" not in lowered_keys


def test_alpha50_modify_existing_user_is_evidence_gated(qapp, monkeypatch):
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    page.identity_operation.setCurrentIndex(page.identity_operation.findData("modify_user"))
    page.identity_username.setText("lubuntu")
    page.stage_identity_btn.click()
    assert len(emitted) == 1
    assert emitted[0].payload["target_exists"] is True
    assert emitted[0].payload["group_membership_mode"] == "preserve"


def test_alpha50_unknown_capability_blocks_gui_staging(qapp, monkeypatch):
    data = _analysis()
    data["system_identity_evidence"] = dict(data["system_identity_evidence"])
    data["system_identity_evidence"]["capability_status"] = "UNKNOWN"
    data["system_identity_evidence"]["verified"] = False
    page = SystemPage()
    page.set_analysis(data)
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    page.identity_operation.setCurrentIndex(page.identity_operation.findData("create_user"))
    page.identity_username.setText("chromatest")
    page.stage_identity_btn.click()
    assert emitted == []
    assert "UNKNOWN" in page.identity_plan_status.text()


def test_alpha50_changes_test_and_undo(qapp, monkeypatch):
    page = SystemPage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.information", lambda *a, **k: None)
    monkeypatch.setattr("chromapress.gui.system_page.QMessageBox.warning", lambda *a, **k: None)
    page.identity_operation.setCurrentIndex(page.identity_operation.findData("create_user"))
    page.identity_username.setText("chromatest")
    # New users are fail-closed unless an explicit account role is selected.
    # This test exercises Changes/Test/Undo, so select the safe normal-user role
    # instead of weakening the production validation to satisfy the test.
    page.identity_role.setCurrentIndex(page.identity_role.findData("standard"))
    page.stage_identity_btn.click()
    assert len(emitted) == 1

    changes = ChangesPanel()
    changes.set_changes([])
    changes.add_change(emitted[0])
    monkeypatch.setattr("chromapress.gui.changes.QMessageBox.information", lambda *a, **k: None)
    changes._test_selected()
    assert changes.changes[0].status == ChangeStatus.PASS
    changes._undo_selected()
    assert changes.changes == []
