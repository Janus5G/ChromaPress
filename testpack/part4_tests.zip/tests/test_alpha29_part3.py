from __future__ import annotations

from pathlib import Path

from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as preflight_change


def _hardware_plan(**overrides):
    payload = {
        "config_type": "hardware_package",
        "source_sha256": "a" * 64,
        "package": "linux-firmware",
        "version": "1",
        "hardware_kind": "Firmware / microcode",
        "rootfs": ["/casper/minimal.standard.live.squashfs"],
        "initramfs_mechanism": "update-initramfs",
        "operation": "re_resolve",
        "require_signed_repository_metadata": True,
        "require_dependency_resolution": True,
        "protect_last_viable_kernel": True,
        "regenerate_initramfs": True,
        "preservation_policy": "preserve-unrelated",
        "stage_only": True,
    }
    payload.update(overrides)
    return ChangeItem("Firmware / driver plan", ChangeKind.CONFIG, "test", payload)


def test_alpha29_hardware_plan_is_hash_locked_manifest_backed_and_stage_only():
    status, message = preflight_change(_hardware_plan())
    assert status == ChangeStatus.PASS
    assert "source-hash locked" in message
    assert "manifest-backed" in message
    assert "staging-only" in message


def test_alpha29_hardware_plan_requires_supported_manifest_kind_and_package():
    assert preflight_change(_hardware_plan(package=""))[0] == ChangeStatus.FAIL
    assert preflight_change(_hardware_plan(hardware_kind="Kernel"))[0] == ChangeStatus.FAIL


def test_alpha29_hardware_plan_requires_repo_dependency_and_kernel_safety_gates():
    assert preflight_change(_hardware_plan(require_signed_repository_metadata=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_hardware_plan(require_dependency_resolution=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_hardware_plan(protect_last_viable_kernel=False))[0] == ChangeStatus.FAIL
    assert preflight_change(_hardware_plan(regenerate_initramfs=False))[0] == ChangeStatus.FAIL


def test_alpha29_hardware_plan_requires_rootfs_mechanism_and_stage_only():
    assert preflight_change(_hardware_plan(rootfs=[]))[0] == ChangeStatus.FAIL
    assert preflight_change(_hardware_plan(initramfs_mechanism="unknown"))[0] == ChangeStatus.FAIL
    assert preflight_change(_hardware_plan(stage_only=False))[0] == ChangeStatus.FAIL


def test_alpha29_release_notes_remain_present_after_later_alphas():
    root = Path(__file__).parents[1]
    notes = (root / "ALPHA29_NOTES.md").read_text(encoding="utf-8")
    assert "ChromaPress v1 Alpha 29" in notes
    assert "firmware/driver" in notes.casefold()
