from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_apparmor_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _payload(**overrides):
    data = {
        "config_type": "system_apparmor",
        "source_sha256": "a" * 64,
        "operation": "enable_apparmor",
        "backend": "apparmor",
        "evidence_path": "/usr/sbin/apparmor_parser",
        "evidence_layer": "/casper/minimal.standard.squashfs",
        "rootfs_apparmor_verified": True,
        "require_backend_apply_verification_before_apply": True,
        "preserve_profiles": True,
        "preserve_parser_config": True,
        "profile_contents_read": False,
        "parser_config_read": False,
        "abstractions_tunables_read": False,
        "apparmor_secrets_read": False,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }
    data.update(overrides)
    return data


def test_alpha48_apparmor_evidence_detects_parser_without_reading_profiles(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"iso")
    layers = ["/casper/minimal.standard.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: "/usr/bin/unsquashfs" if name == "unsquashfs" else None)
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (0, 1)})

    def presence(path, roots, member, extents=None):
        return (member == "/usr/sbin/apparmor_parser", layers[0] if member == "/usr/sbin/apparmor_parser" else "")

    monkeypatch.setattr("chromapress.engine_cli._inspect_overlay_member_presence", presence)
    monkeypatch.setattr("chromapress.engine_cli._inspect_apparmor_from_readonly_mount", lambda *a, **k: {})
    evidence = _system_apparmor_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["backend"] == "apparmor"
    assert evidence["evidence_path"] == "/usr/sbin/apparmor_parser"
    assert evidence["profile_contents_read"] is False
    assert evidence["parser_config_read"] is False
    assert evidence["apparmor_secrets_read"] is False


def test_alpha48_apparmor_preflight_passes():
    status, detail = run_preflight(ChangeItem("AppArmor plan", ChangeKind.CONFIG, "x", _payload()))
    assert status == ChangeStatus.PASS
    assert "backend-apply-verification gated" in detail
    assert "profile-content preserving" in detail


def test_alpha48_apparmor_preflight_rejects_profile_read_or_missing_reverify():
    status, _ = run_preflight(ChangeItem("AppArmor plan", ChangeKind.CONFIG, "x", _payload(profile_contents_read=True)))
    assert status == ChangeStatus.FAIL
    status, _ = run_preflight(ChangeItem("AppArmor plan", ChangeKind.CONFIG, "x", _payload(require_backend_apply_verification_before_apply=False)))
    assert status == ChangeStatus.FAIL


def test_alpha48_apparmor_preflight_supports_disable():
    status, _ = run_preflight(ChangeItem("AppArmor plan", ChangeKind.CONFIG, "x", _payload(operation="disable_apparmor")))
    assert status == ChangeStatus.PASS


def test_alpha48_version_markers():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
