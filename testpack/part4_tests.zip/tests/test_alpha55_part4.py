from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _system_kiosk_user_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _identity(verified=True):
    return {
        "verified": verified,
        "users_groups_status": "SUPPORTED_WITH_REQUIREMENTS" if verified else "UNKNOWN",
        "passwd_layer": "/casper/minimal.squashfs" if verified else "",
        "group_layer": "/casper/minimal.squashfs" if verified else "",
        "uid_min": 1000,
        "regular_users": ["ubuntu"],
        "user_records": [{"name": "ubuntu", "uid": 1000}],
        "groups": ["users", "sudo", "adm"],
        "admin_groups": ["sudo"],
    }


def _evidence(capability="SUPPORTED_WITH_REQUIREMENTS"):
    if capability in {"SUPPORTED", "SUPPORTED_WITH_REQUIREMENTS"}:
        return _system_kiosk_user_evidence(_identity(True)) | {"capability_status": capability}
    e = _system_kiosk_user_evidence(_identity(False))
    e["capability_status"] = capability
    return e


def _payload(capability="SUPPORTED_WITH_REQUIREMENTS", username="chromakiosk55"):
    e = _evidence(capability)
    return {
        "config_type": "dedicated_kiosk_user",
        "gate_version": "alpha55",
        "source_sha256": "a" * 64,
        "analysis_scope": "target_iso_rootfs",
        "capability_status": capability,
        "rootfs_account_verified": e["verified"],
        "operation": "create_dedicated_non_admin_kiosk_user",
        "backend": e["backend"],
        "passwd_layer": e["passwd_layer"],
        "group_layer": e["group_layer"],
        "uid_min": e["uid_min"],
        "existing_regular_users": list(e["existing_regular_users"]),
        "existing_user_uids": list(e["existing_user_uids"]),
        "available_groups": list(e["available_groups"]),
        "verified_admin_groups": list(e["admin_groups"]),
        "username": username,
        "display_name": "Chroma Kiosk",
        "account_role": "dedicated_non_admin_kiosk",
        "uid_mode": "automatic",
        "primary_gid_mode": "automatic",
        "supplementary_groups": [],
        "administrative_groups": [],
        "create_home": True,
        "credential_policy": "deferred_to_later_verified_gate",
        "credential_secret_read": False,
        "credential_secret_staged": False,
        "shadow_read": False,
        "host_accounts_touched": False,
        "login_policy_deferred_to_later_gate": True,
        "session_policy_deferred_to_later_gate": True,
        "autologin_policy_preserved": True,
        "require_user_absence_reverification_before_apply": True,
        "preserve_existing_users_groups": True,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def _run(payload):
    return run_preflight(ChangeItem("Dedicated non-admin kiosk user plan", ChangeKind.CONFIG, "test", payload))


def test_alpha55_capability_is_derived_only_from_verified_target_accounts():
    e = _system_kiosk_user_evidence(_identity(True))
    assert e["capability_status"] == "SUPPORTED_WITH_REQUIREMENTS"
    assert e["verified"] is True
    assert e["shadow_read"] is False
    assert e["credential_secret_read"] is False
    assert e["host_accounts_touched"] is False
    assert e["login_policy_inspected"] is False
    assert e["session_policy_inspected"] is False
    assert e["source_read_only"] is True
    assert e["supported_operations"] == ["create_dedicated_non_admin_kiosk_user"]


def test_alpha55_unverified_account_state_is_unknown_not_unsupported():
    e = _system_kiosk_user_evidence(_identity(False))
    assert e["capability_status"] == "UNKNOWN"
    assert e["verified"] is False


def test_alpha55_valid_non_admin_kiosk_user_stages_cleanly():
    status, message = _run(_payload())
    assert status == ChangeStatus.PASS, message
    assert "admin/credential free" in message
    assert "later-login/session-policy preserving" in message


def test_alpha55_unknown_blocked_and_unsupported_fail_closed():
    for capability in ("UNKNOWN", "BLOCKED", "UNSUPPORTED"):
        assert _run(_payload(capability))[0] == ChangeStatus.FAIL


def test_alpha55_existing_username_is_preserved():
    assert _run(_payload(username="ubuntu"))[0] == ChangeStatus.FAIL


def test_alpha55_admin_membership_is_impossible():
    p = _payload()
    p["administrative_groups"] = ["sudo"]
    assert _run(p)[0] == ChangeStatus.FAIL
    p = _payload()
    p["supplementary_groups"] = ["users"]
    assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha55_credentials_shadow_and_host_accounts_are_forbidden():
    for key in ("credential_secret_read", "credential_secret_staged", "shadow_read", "host_accounts_touched"):
        p = _payload()
        p[key] = True
        assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha55_login_session_and_autologin_are_deferred():
    for key in ("login_policy_deferred_to_later_gate", "session_policy_deferred_to_later_gate", "autologin_policy_preserved"):
        p = _payload()
        p[key] = False
        assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha55_reverification_preservation_and_staging_are_mandatory():
    for key in ("require_user_absence_reverification_before_apply", "preserve_existing_users_groups", "source_read_only", "preserve_unrelated", "stage_only"):
        p = _payload()
        p[key] = False
        assert _run(p)[0] == ChangeStatus.FAIL


def test_alpha55_acceptance_runner_has_dedicated_gate():
    text = (Path(__file__).parents[1] / "chromapress_acceptance.py").read_text(encoding="utf-8")
    assert "P4-ALPHA55-KIOSK-USER" in text
    assert "_add_alpha55_kiosk_user_gate" in text
    assert "system_kiosk_user_evidence" in text


def test_alpha55_acceptance_gate_executes_supported_and_unknown(tmp_path):
    import sys
    root = Path(__file__).parents[1]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    from chromapress_acceptance import AcceptanceRunner, PASS

    runner = AcceptanceRunner(root, 4, None, None, tmp_path)
    runner._add_alpha55_kiosk_user_gate(_evidence(), "a" * 64)
    assert runner.checks[-1].status == PASS

    runner._add_alpha55_kiosk_user_gate(_evidence("UNKNOWN"), "a" * 64)
    assert runner.checks[-1].status == PASS
    assert "fail-closed" in runner.checks[-1].detail


def test_alpha55_version_markers():
    root = Path(__file__).parents[1]
    assert 'version = "1.0.0a72"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert '__version__ = "1.0.0a72"' in (root / "src/chromapress/__init__.py").read_text(encoding="utf-8")
