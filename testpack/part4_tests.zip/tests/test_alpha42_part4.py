from __future__ import annotations

from pathlib import Path

from chromapress.engine_cli import _localtime_listing_info, _parse_timezone_text, _system_timezone_rootfs_evidence
from chromapress.models import ChangeItem, ChangeKind, ChangeStatus
from chromapress.services.preflight import test_change as run_preflight


def _good_payload() -> dict:
    return {
        "config_type": "system_timezone",
        "source_sha256": "f" * 64,
        "operation": "configure_timezone",
        "target_timezone": "Europe/Copenhagen",
        "timezone_config_path": "/etc/timezone",
        "timezone_config_layer": "/casper/minimal.standard.squashfs",
        "timezone_config_style": "debian-timezone",
        "current_timezone": "Etc/UTC",
        "rootfs_timezone_verified": True,
        "require_zoneinfo_verification_before_apply": True,
        "preserve_hwclock_rtc_policy": True,
        "secret_read": False,
        "secret_staged": False,
        "source_read_only": True,
        "preserve_unrelated": True,
        "stage_only": True,
    }


def test_alpha42_timezone_text_parser_is_narrow():
    assert _parse_timezone_text("# comment\nEurope/Copenhagen\nPASSWORD=secret\n") == "Europe/Copenhagen"
    assert _parse_timezone_text("../etc/passwd\n") == ""


def test_alpha42_localtime_listing_parser_handles_symlink():
    present, zone = _localtime_listing_info("lrwxrwxrwx root/root 0 squashfs-root/etc/localtime -> /usr/share/zoneinfo/Etc/UTC")
    assert present is True
    assert zone == "Etc/UTC"


def test_alpha42_timezone_evidence_uses_rootfs_config(monkeypatch, tmp_path):
    iso = tmp_path / "source.iso"
    iso.write_bytes(b"not-read-by-test")
    layers = ["/casper/minimal.standard.squashfs"]
    monkeypatch.setattr("chromapress.engine_cli.shutil.which", lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr("chromapress.engine_cli._iso_member_extents", lambda *a, **k: {layers[0]: (4096, 1234)})

    def fake_read(_iso: Path, _layers: list[str], member: str, _extents):
        if member == "/etc/timezone":
            return "Etc/UTC\n", layers[0]
        return "", ""

    monkeypatch.setattr("chromapress.engine_cli._read_squashfs_overlay_text", fake_read)
    monkeypatch.setattr("chromapress.engine_cli._inspect_localtime_overlay", lambda *a, **k: (True, "Etc/UTC", layers[0]))
    monkeypatch.setattr("chromapress.engine_cli._read_timezone_from_readonly_mount", lambda *a, **k: {})
    evidence = _system_timezone_rootfs_evidence(iso, layers)
    assert evidence["verified"] is True
    assert evidence["config_path"] == "/etc/timezone"
    assert evidence["current_timezone"] == "Etc/UTC"
    assert evidence["secret_read"] is False


def test_alpha42_timezone_preflight_passes():
    status, message = run_preflight(ChangeItem("Timezone plan", ChangeKind.CONFIG, "test", _good_payload()))
    assert status == ChangeStatus.PASS
    assert "rootfs-evidence bound" in message
    assert "RTC-policy preserving" in message


def test_alpha42_timezone_preflight_rejects_traversal_or_unverified_values():
    payload = _good_payload()
    payload["target_timezone"] = "../Europe/Copenhagen"
    status, _ = run_preflight(ChangeItem("Timezone", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL

    payload = _good_payload()
    payload["rootfs_timezone_verified"] = False
    status, _ = run_preflight(ChangeItem("Timezone", ChangeKind.CONFIG, "test", payload))
    assert status == ChangeStatus.FAIL
