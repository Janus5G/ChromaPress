from __future__ import annotations

import os
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication
from chromapress.gui.boot_hardware_page import BootHardwarePage
from chromapress.models import ChangeKind, ChangeStatus


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _analysis():
    return {
        "path": r"E:\\test.iso",
        "sha256": "a" * 64,
        "bios_boot": True,
        "uefi_boot": True,
        "el_torito_boot": True,
        "hybrid_boot": True,
        "boot_catalog": "/boot.catalog",
        "volume_id": "Lubuntu 26.04 amd64",
        "boot_config_files": ["/boot/grub/grub.cfg"],
        "boot_entries": [
            {"title": "Try or Install Lubuntu", "source": "/boot/grub/grub.cfg", "id": "try"},
            {"title": "Lubuntu (safe graphics)", "source": "/boot/grub/grub.cfg", "id": "safe"},
        ],
        "kernel_images": ["/casper/vmlinuz"],
        "initramfs_images": ["/casper/initrd"],
        "rootfs": ["/casper/minimal.squashfs"],
        "rootfs_details": [{"path": "/casper/minimal.squashfs", "compression": "xz", "block_size": 131072}],
        "initramfs_mechanism": "update-initramfs",
    }


def test_alpha34_metadata_controls_bind_detected_entries(qapp):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    assert page.stage_metadata_btn.isEnabled()
    assert page.metadata_entry_combo.count() == 3
    assert "Lubuntu 26.04 amd64" in page.metadata_volume_edit.placeholderText()


def test_alpha34_metadata_plan_stages(qapp, monkeypatch):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.boot_hardware_page.QMessageBox.information", lambda *a, **k: None)
    page.metadata_entry_combo.setCurrentIndex(1)
    page.metadata_label_edit.setText("Try Lubuntu")
    page.metadata_order_combo.setCurrentIndex(1)
    page.metadata_volume_edit.setText("LUBUNTU_TEST")
    page.stage_metadata_btn.click()
    assert len(emitted) == 1
    change = emitted[0]
    assert change.kind == ChangeKind.CONFIG
    assert change.payload["config_type"] == "boot_metadata"
    assert change.payload["selected_entry"]["title"] == "Try or Install Lubuntu"
    assert change.payload["entry_label_new"] == "Try Lubuntu"
    assert change.payload["boot_order_operation"] == "move_selected_first"
    assert change.payload["volume_id_new"] == "LUBUNTU_TEST"
    assert change.payload["preserve_boot_records"] is True
    assert change.payload["source_read_only"] is True


def test_alpha34_metadata_requires_entry_for_entry_changes(qapp, monkeypatch):
    page = BootHardwarePage()
    page.set_analysis(_analysis())
    emitted = []
    page.stage_requested.connect(emitted.append)
    monkeypatch.setattr("chromapress.gui.boot_hardware_page.QMessageBox.information", lambda *a, **k: None)
    page.metadata_label_edit.setText("Renamed")
    page.stage_metadata_btn.click()
    assert emitted == []
    assert "select a detected boot entry" in page.metadata_plan_status.text().lower()


def test_alpha34_source_switch_blocks_stale_metadata_plan(qapp):
    from chromapress.gui.main_window import MainWindow
    from chromapress.models import ChangeItem
    window = MainWindow()
    change = ChangeItem("Boot identity / metadata plan", ChangeKind.CONFIG, "test", {
        "config_type": "boot_metadata",
        "source_sha256": "a" * 64,
    })
    window.project.changes.append(change)
    window.changes.set_changes(window.project.changes)
    window._guard_boot_plan_source("b" * 64)
    assert change.status == ChangeStatus.BLOCKED
    window.close()
