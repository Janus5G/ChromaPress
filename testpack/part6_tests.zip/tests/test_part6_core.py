from pathlib import Path
import json
import pytest

from chromapress.models import ChangeItem, ChangeKind, ChangeStatus, SourceState
from chromapress.services.ai import AiRequest, prepare_request
from chromapress.services.ai_catalog import AI_PROVIDERS, provider_by_id, normalize_provider_id, normalized_model_id
from chromapress.services.part6 import (
    parse_generated_project, review_generated_project, target_context_from_source,
    ai_app_payload, dependency_change_items, validate_ai_app_payload,
)
from chromapress.services.preflight import test_change as run_preflight

SHA = "a" * 64


def target_context():
    return {
        "distribution":"Ubuntu","version":"26.04","architecture":"amd64","desktop":"LXQt",
        "package_format":"deb","package_manager":"apt/dpkg","available_libraries":["systemd","network-manager"],
        "installer_type":"Subiquity/Autoinstall","source_sha256":SHA,"scenario":"Desktop","scenario_context":""
    }


def generated_project(extra=""):
    manifest = {
        "name":"Demo App","version":"1.0","entrypoint":"app.py",
        "packages":[{"name":"python3-pyside6","reason":"Qt UI"}],
        "services":[],"permissions":[],"autostart":[],"desktop_integration":["desktop-file"],
        "security_implications":["No network service"],
        "build":{"command":"python -m compileall .","requires_network":False},
        "test":{"command":"python -m unittest","requires_network":False},
    }
    return "--- chromapress-app.json ---\n" + json.dumps(manifest) + "\n--- app.py ---\nprint('hello')\n" + extra


def test_provider_catalog_only_claims_implemented_adapters():
    ids={p.id for p in AI_PROVIDERS}
    assert ids == {"openai","caffeine","openai-compatible","local"}
    assert "anthropic" not in ids and "gemini" not in ids
    assert provider_by_id("local").requires_api_key is False
    assert provider_by_id("openai-compatible").requires_endpoint is True
    assert normalize_provider_id("OpenAI compatible") == "openai-compatible"
    assert normalized_model_id("local","my-local-model") == "my-local-model"


def test_prepare_request_keeps_generation_credential_out_of_body_and_allows_loopback_http():
    req=AiRequest("local","http://127.0.0.1:11434/v1","LOCAL_SECRET_123456","model-x","make app","Auto",target_context())
    endpoint,headers,body=prepare_request(req)
    assert endpoint.endswith("/chat/completions")
    assert b"LOCAL_SECRET_123456" not in body
    assert headers["Authorization"].endswith("LOCAL_SECRET_123456")
    req2=AiRequest("local","http://example.org/v1","","model-x","make app","Auto",target_context())
    with pytest.raises(ValueError, match="loopback"):
        prepare_request(req2)


def test_remote_compatible_requires_https_and_key():
    with pytest.raises(ValueError, match="Generation API key"):
        prepare_request(AiRequest("openai-compatible","https://example.org/v1","","m","x","Auto",target_context()))
    with pytest.raises(ValueError, match="Cleartext HTTP"):
        prepare_request(AiRequest("openai-compatible","http://example.org/v1","secret-key-123456","m","x","Auto",target_context()))


def test_generated_project_parser_requires_safe_explicit_files():
    files=parse_generated_project(generated_project())
    assert [f.path for f in files]==["chromapress-app.json","app.py"]
    with pytest.raises(ValueError, match="unsafe generated project path"):
        parse_generated_project("--- ../evil.py ---\nprint(1)\n")
    with pytest.raises(ValueError, match="no explicit project file separators"):
        parse_generated_project("print('not a project')")


def test_review_requires_manifest_and_blocks_generation_credential_leak():
    review=review_generated_project(generated_project(), generation_credential="TOP_SECRET_GENERATION_KEY_123")
    assert review["status"]=="PASS" and review["file_count"]==2
    leaked=generated_project("--- leak.py ---\nTOKEN='TOP_SECRET_GENERATION_KEY_123'\n")
    review2=review_generated_project(leaked, generation_credential="TOP_SECRET_GENERATION_KEY_123")
    assert review2["status"]=="BLOCKED"


def test_target_context_contains_required_linux_fields():
    source=SourceState(distribution="Ubuntu",version="26.04",architecture="amd64",sha256=SHA,package_format="deb",installer="Subiquity/Autoinstall",
                       part5_desktop_evidence={"active_desktop":"LXQt"},system_package_evidence=[{"package":"systemd","version":"1"},{"package":"network-manager","version":"1"}])
    c=target_context_from_source(source,"Desktop","normal desktop")
    for key in ("distribution","version","architecture","desktop","package_manager","available_libraries","installer_type"):
        assert key in c
    assert c["source_sha256"]==SHA and c["package_manager"]=="apt/dpkg"


def test_staged_payload_excludes_raw_prompt_and_credentials_and_preflight_passes():
    review=review_generated_project(generated_project(), generation_credential="GENERATION_SECRET_123456")
    payload=ai_app_payload(review,target_context(),provider="openai",model="gpt-5.6-sol",toolchain="Auto",prompt="Build a demo app",human_review_acknowledged=True)
    raw=json.dumps(payload)
    assert "GENERATION_SECRET_123456" not in raw
    assert "Build a demo app" not in raw
    assert payload["generation_credential_staged"] is False and payload["runtime_credential_staged"] is False
    assert validate_ai_app_payload(payload)[0]
    status,msg=run_preflight(ChangeItem("Demo",ChangeKind.AI_APP,"x",payload))
    assert status==ChangeStatus.PASS, msg


def test_tampered_project_file_hash_fails_preflight():
    review=review_generated_project(generated_project())
    payload=ai_app_payload(review,target_context(),provider="openai",model="gpt-5.6-sol",toolchain="Auto",prompt="demo",human_review_acknowledged=True)
    payload["project_files"][1]["content"]="print('tampered')\n"
    assert not validate_ai_app_payload(payload)[0]



def test_staging_requires_explicit_human_review_acknowledgement():
    review=review_generated_project(generated_project())
    with pytest.raises(ValueError, match="Human review"):
        ai_app_payload(review,target_context(),provider="openai",model="gpt-5.6-sol",toolchain="Auto",prompt="demo")

def test_dependency_requirements_become_normal_chromapress_package_operations():
    review=review_generated_project(generated_project())
    deps=dependency_change_items(review,target_context(),"project123")
    assert len(deps)==1
    assert deps[0].kind==ChangeKind.PACKAGE_REPOSITORY
    assert deps[0].payload["manager"]=="apt"
    assert deps[0].payload["source"]=="ai_app_dependency"


def test_apply_is_explicitly_blocked_until_review_build_test_security_dependency_gates():
    review=review_generated_project(generated_project())
    p=ai_app_payload(review,target_context(),provider="openai",model="gpt-5.6-sol",toolchain="Auto",prompt="demo",human_review_acknowledged=True)
    assert p["never_blindly_inject"] is True
    assert p["requires_human_review_before_apply"] is True
    assert p["apply_blocked_until_build_test_security_dependency_gates_pass"] is True
    assert p["build_test_execution_policy"]=="isolated_explicit_user_action_required"
