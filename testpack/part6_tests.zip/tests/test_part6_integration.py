from pathlib import Path


def root(): return Path.cwd()


def test_part6_testpack_files_exist():
    r=root()
    for name in ("part6_tests.zip","part6_tests.zip.sha256","part6_manifest.json"):
        assert (r/"testpack"/name).is_file()


def test_acceptance_runs_part6_after_part4_and_part5():
    text=(root()/"chromapress_acceptance.py").read_text()
    assert '_run_testpack(4)' in text and '_run_testpack(5)' in text and '_run_testpack(6)' in text
    assert 'PART6_TESTPACK=' in text and 'PART6_STAGED_GATES=' in text


def test_testpack_reports_part6_gui_gate():
    text=(root()/"chromapress_testpack.py").read_text()
    assert 'junit_part6_summary' in text
    assert 'part6_staged_gate_status' in text


def test_generation_key_is_not_persisted_to_qsettings():
    text=(root()/"src/chromapress/gui/main_window.py").read_text()
    assert 'ai_api_key is deliberately NOT written to QSettings' in text
    save=text[text.index('def _save_settings'):text.index('def open_settings')]
    assert '"ai_api_key"' not in save


def test_target_context_is_structured_and_source_bound():
    text=(root()/"src/chromapress/gui/main_window.py").read_text()
    assert 'target_context_from_source' in text
    assert 'self.ai.set_target_context(target_context_from_source' in text
    assert '_guard_part6_plan_source' in text


def test_part6_version_markers():
    r=root()
    assert 'version = "1.0.0a72"' in (r/"pyproject.toml").read_text()
    assert '__version__ = "1.0.0a72"' in (r/"src/chromapress/__init__.py").read_text()


def test_ai_app_studio_remains_optional_navigation_not_required_for_core():
    main=(root()/"src/chromapress/gui/main_window.py").read_text()
    assert '"AI App Studio"' in main
    ai=(root()/"src/chromapress/gui/ai_studio.py").read_text()
    assert 'Optional coding workspace' in ai
