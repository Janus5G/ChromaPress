import os; os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
import json
import pytest
pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication, QMessageBox

from chromapress.gui.ai_studio import AiStudioPage
from chromapress.gui.changes import ChangesPanel
from chromapress.settings import AppSettings
from chromapress.models import ChangeKind, ChangeStatus

SHA="a"*64

@pytest.fixture(scope="module")
def qapp(): return QApplication.instance() or QApplication([])

@pytest.fixture(autouse=True)
def no_modal(monkeypatch):
    for name in ("warning","information","critical"):
        monkeypatch.setattr(QMessageBox,name,lambda *a,**k:None)


def ctx():
    return {"distribution":"Ubuntu","version":"26.04","architecture":"amd64","desktop":"LXQt","package_format":"deb","package_manager":"apt/dpkg",
            "available_libraries":["systemd"],"installer_type":"Subiquity/Autoinstall","source_sha256":SHA,"scenario":"","scenario_context":""}


def project_text():
    m={"name":"GUI App","version":"1","entrypoint":"app.py","packages":["python3-pyside6"],"services":[],"permissions":[],"autostart":[],
       "desktop_integration":[],"security_implications":[],"build":{"command":"python -m compileall .","requires_network":False},
       "test":{"command":"python -m unittest","requires_network":False}}
    return "--- chromapress-app.json ---\n"+json.dumps(m)+"\n--- app.py ---\nprint('ok')\n"


def test_part6_gui_requires_target_and_review_before_stage(qapp):
    settings=AppSettings(); p=AiStudioPage(settings)
    assert not p.stage_btn.isEnabled()
    assert not p.human_review_check.isChecked()
    p.code.setPlainText(project_text()); p.inspect_project()
    assert not p.stage_btn.isEnabled()
    p.set_target_context(ctx()); p.inspect_project()
    assert not p.stage_btn.isEnabled()
    assert "READY" in p.target_status.text()
    p.human_review_check.setChecked(True)
    assert p.stage_btn.isEnabled()
    p.human_review_check.setChecked(False)
    assert not p.stage_btn.isEnabled()


def test_part6_gui_stage_dependencies_and_app_then_changes_test_undo(qapp):
    settings=AppSettings(); p=AiStudioPage(settings); p.set_target_context(ctx()); p.prompt.setPlainText("Build GUI app"); p.code.setPlainText(project_text()); p.inspect_project()
    assert not p.stage_btn.isEnabled()
    p.human_review_check.setChecked(True); assert p.stage_btn.isEnabled()
    c=ChangesPanel(); p.change_requested.connect(c.add_change); p.stage()
    assert len(c.changes)==2
    assert c.changes[0].kind==ChangeKind.PACKAGE_REPOSITORY
    assert c.changes[1].kind==ChangeKind.AI_APP
    assert "ai_api_key" not in json.dumps(c.changes[1].payload).lower()
    assert c.changes[1].payload["human_review_acknowledged"] is True
    c.list.setCurrentRow(1); c._test_selected(); assert c.changes[1].status==ChangeStatus.PASS
    c._undo_selected(); assert len(c.changes)==1


def test_part6_gui_provider_list_does_not_fake_unimplemented_vendors(qapp):
    p=AiStudioPage(AppSettings()); labels=[p.provider.itemData(i) for i in range(p.provider.count())]
    assert labels==["openai","caffeine","openai-compatible","local"]
    assert "anthropic" not in labels and "gemini" not in labels
