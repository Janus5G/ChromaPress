import os; os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
import pytest
pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication, QMessageBox

from chromapress.gui.production_page import ProductionWorkflowPage
from chromapress.models import ProjectState, SourceState

SHA="a"*64

@pytest.fixture(scope="module")
def qapp(): return QApplication.instance() or QApplication([])

@pytest.fixture(autouse=True)
def no_modal(monkeypatch):
    for name in ("warning","information","critical"):
        monkeypatch.setattr(QMessageBox,name,lambda *a,**k:None)


def source_project():
    p=ProjectState(name="Part8 GUI")
    p.source=SourceState(
        distribution="Ubuntu",version="26.04",architecture="amd64",sha256=SHA,package_format="deb",
        rootfs=["/casper/filesystem.squashfs"],kernel_images=["/casper/vmlinuz"],initramfs_images=["/casper/initrd"],
        initramfs_mechanism="update-initramfs",bios_boot=True,uefi_boot=True,
        os_release_evidence={"id":"ubuntu","version_id":"26.04","status":"PASS"},
        system_package_evidence=[{"name":"base-files"}],system_rootfs_verification=["manifest"],
        part5_installer_evidence={"status":"SUPPORTED","reason":"verified"},
    )
    return p


def test_part8_gui_blocks_without_source_and_never_calls_analysis_verified(qapp):
    page=ProductionWorkflowPage(); page.refresh_acceptance()
    assert not page.acceptance_export_btn.isEnabled()
    assert "BLOCKED" in page.acceptance_status.text()
    assert "VERIFIED —" not in page.acceptance_status.text()


def test_part8_gui_shows_static_ready_runtime_required_for_analyzed_source(qapp):
    page=ProductionWorkflowPage(); page.set_project(source_project())
    assert page.acceptance_export_btn.isEnabled()
    assert page.acceptance_status.text().startswith("STATIC READY")
    assert "runtime acceptance" in page.acceptance_status.text().lower()
    assert "Analysis alone never marks a distro VERIFIED" in page.acceptance_details.toPlainText()


def test_part8_gui_refresh_does_not_enable_or_stage_part7_build_plan(qapp):
    page=ProductionWorkflowPage(); page.set_project(source_project())
    assert not page.stage_btn.isEnabled()
    page.acceptance_refresh_btn.click()
    assert not page.stage_btn.isEnabled()
