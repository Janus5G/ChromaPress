from copy import deepcopy
from pathlib import Path
import json
import pytest

from chromapress.models import SourceState
from chromapress.services.part8 import (
    DISTRO_ADAPTERS, VERIFIED, STATIC_READY, STATIC_INCOMPLETE,
    distro_matrix, match_distribution_adapter, build_static_acceptance,
    validate_acceptance_record, apply_runtime_results, diagnostics_payload,
    save_diagnostics,
)

SHA="a"*64

def ubuntu_source():
    return SourceState(
        path=r"E:\\ISO\\ubuntu.iso", distribution="Ubuntu", version="26.04", architecture="amd64",
        sha256=SHA, package_format="deb", rootfs=["/casper/filesystem.squashfs"],
        kernel_images=["/casper/vmlinuz"], initramfs_images=["/casper/initrd"], initramfs_mechanism="update-initramfs",
        bios_boot=True, uefi_boot=True,
        os_release_evidence={"status":"PASS","verified":True,"id":"ubuntu","version_id":"26.04","pretty_name":"Ubuntu 26.04 LTS"},
        system_package_evidence=[{"name":"base-files"}], system_rootfs_verification=["manifest"],
        part5_installer_evidence={"status":"SUPPORTED","reason":"Autoinstall evidence verified"},
    )


def test_part8_priority_order_matches_locked_plan_and_never_claims_verified():
    rows=distro_matrix()
    assert [r["priority"] for r in rows[:2]]==["PRIMARY","PRIMARY"]
    assert [r["label"] for r in rows[:2]]==["RHEL","Ubuntu LTS"]
    assert all(r["verification_state"]=="UNVERIFIED" for r in rows)
    assert {r["label"] for r in rows} >= {"Debian Stable","Rocky Linux","AlmaLinux","Oracle Linux","Fedora","Linux Mint","CentOS Stream","Arch Linux","Manjaro","SUSE/openSUSE"}


def test_ubuntu_lts_adapter_is_evidence_backed_but_still_unverified():
    match=match_distribution_adapter(ubuntu_source())
    assert match["id"]=="ubuntu-lts" and match["priority"]=="PRIMARY"
    assert match["release_qualified"] is True
    assert match["verification_state"]=="UNVERIFIED"


def test_generic_rpm_family_does_not_fake_rhel_or_other_vendor():
    src=SourceState(distribution="RPM-family Linux",version="9",architecture="amd64",sha256=SHA,package_format="rpm",rootfs=["/LiveOS/rootfs.squashfs"])
    match=match_distribution_adapter(src)
    assert match["matched"] is False
    record=build_static_acceptance(src)
    assert record["verification_state"]==STATIC_INCOMPLETE and record["verified"] is False


def test_analysis_only_record_can_never_be_verified():
    record=build_static_acceptance(ubuntu_source())
    assert record["verification_state"]==STATIC_READY
    assert record["verified"] is False and record["analysis_only"] is True
    ok,msg=validate_acceptance_record(record); assert ok,msg
    forged=deepcopy(record); forged["verified"]=True; forged["verification_state"]=VERIFIED
    ok,msg=validate_acceptance_record(forged); assert not ok and ("fingerprint" in msg.lower() or "analysis-only" in msg.lower())


def test_runtime_verification_requires_explicit_evidence_for_every_remaining_gate():
    record=build_static_acceptance(ubuntu_source())
    results={}
    for row in record["checks"]:
        if row["status"] in {"UNKNOWN","RUNTIME_REQUIRED","MANUAL_REQUIRED"}:
            results[row["id"]]={"status":"PASS","evidence":f"explicit evidence for {row['id']}"}
    final=apply_runtime_results(record,results)
    assert final["verification_state"]==VERIFIED and final["verified"] is True and final["analysis_only"] is False
    ok,msg=validate_acceptance_record(final); assert ok,msg


def test_runtime_pass_without_evidence_is_rejected():
    record=build_static_acceptance(ubuntu_source())
    with pytest.raises(ValueError,match="requires explicit evidence"):
        apply_runtime_results(record,{"iso_rebuild_succeeds":{"status":"PASS","evidence":""}})


def test_diagnostics_are_inspectable_source_locked_and_path_free(tmp_path):
    record=build_static_acceptance(ubuntu_source())
    diag=diagnostics_payload(record)
    blob=json.dumps(diag)
    assert SHA in blob and r"E:\\ISO" not in blob and "api_key" not in blob
    path=tmp_path/"part8.json"; save_diagnostics(record,path)
    saved=json.loads(path.read_text())
    assert saved["source_sha256"]==SHA and len(saved["diagnostics_fingerprint"])==64
