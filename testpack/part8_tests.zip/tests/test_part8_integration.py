from chromapress.engine_cli import _parse_os_release
from chromapress.models import ProjectState, SourceState
from chromapress.services.part8 import build_static_acceptance, acceptance_summary


def test_os_release_parser_uses_target_metadata_only():
    parsed=_parse_os_release('ID=rocky\nID_LIKE="rhel centos fedora"\nVERSION_ID="9.6"\nPRETTY_NAME="Rocky Linux 9.6"\n')
    assert parsed["id"]=="rocky" and parsed["version_id"]=="9.6"
    assert "home_url" not in parsed


def test_part8_summary_explicitly_preserves_runtime_boundary():
    source=SourceState(distribution="Rocky Linux",version="9.6",architecture="amd64",sha256="b"*64,package_format="rpm",rootfs=["/LiveOS/rootfs.squashfs"],os_release_evidence={"id":"rocky","version_id":"9.6","status":"PASS"})
    record=build_static_acceptance(source)
    text=acceptance_summary(record)
    assert "Analysis alone never marks a distro VERIFIED" in text
    assert record["verified"] is False
