# Known deferred integration issue

The standalone Refract Studio package keeps the editor, CPL/CPA, PRISME and
optical-simulator paths available. Custom ChromaLinux wallet/canister integration
is outside the standalone package acceptance scope.

1. **Received date displays `Invalid Date` in the external receiving application**
   - The receiving application most likely interprets Unix seconds as
     milliseconds.
   - Correct the display conversion in the receiving entry-details view.

This display issue does not affect Refract Studio's local editor, compiler,
PRISME mapping or optical simulator.
