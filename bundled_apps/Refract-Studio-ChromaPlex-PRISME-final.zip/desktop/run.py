#!/usr/bin/env python3
"""
Refract Studio launcher
"""
import sys
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QSettings
from refracteditor.mainwindow import RefractEditor

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setOrganizationName("RefractEditor")
    app.setApplicationName("RefractEditor")
    window = RefractEditor()
    window.showFullScreen()
    sys.exit(app.exec())
