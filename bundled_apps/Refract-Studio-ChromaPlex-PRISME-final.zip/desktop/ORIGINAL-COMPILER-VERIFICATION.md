# Original ChromaPlex compiler verification

## Provenance result

The supplied `chromaplex_os_package.json` is the authoritative compiler package
used by this build.

- Package SHA-256:
  `fae70b9ae2bea9e6c479297a76d8db5b49d9031671f005946b00cb58eec2f134`
- Compared repository:
  `https://github.com/Janus5G/chromaplex-os-compiler`
- Compared Git commit:
  `3109cb3c04c851893a03f0980e04362c41c6bafe`
- Result: all ten `chromaplex_os/*.py` files are byte-for-byte identical.

The bundled copies are checked by:

```bash
python tests/verify_original_compiler.py
```

## Corrected ChromaPlex OS v1.0.1

The editor also contains the subsequently corrected official `chromaplex-os`
implementation. That implementation supports both documented CPL surfaces:

1. compact CPL using `var`, `store`, `load`, and `print`;
2. specification CPL using `tal`, `potens`, `skriv_voxel`, and `kanal`.

It includes the verified distinction between zero `(0,0)` and one `(0,1)`,
the documented storage roundtrip, and the corrected CPA assembler/simulator
contract. The synchronized source files are protected by:

```bash
python tests/verify_corrected_chromaplex.py
```

Refract Studio keeps the original JSON/toolchain compiler byte-for-byte for
legacy compatibility and provenance. It does not merge or rewrite that
compiler. Compatibility handling stays in `refracteditor/cpl_adapter.py`.
Semantic tests verify:

- `1234567` writes and reads through the original toolchain CPL/CPA/VM and
  prints `1234567`;
- corrected ChromaPlex OS specification CPL produces `20` and `185991`, satisfying
  `1234567 = 2^20 + 185991`;
- the specification CPA writes that pair to voxel `(5,5,5)` in the green
  channel.

Run:

```bash
python tests/test_cpl_semantics.py
```

## Original-package runtime compatibility

The original package is preserved unchanged. Its repository test
`test_store_load` currently exposes an upstream assembler issue:
`COLOUR_NAMES.get(colour, parse_immediate(...))` evaluates the numeric fallback
even when a named colour such as `GREEN` exists. The original compiler also
emits `PRINT R7` as a pseudo-operation not present in its opcode enum.

Refract Studio handles those two boundaries in `refracteditor/cpl_adapter.py`.
It does not modify `compiler.py`, `assembler.py`, `vm.py`, or the package JSON.
The supplied `examples/hello.cpl` compiles and runs through that adapter with
output `1000`, one written voxel, and one read access.
