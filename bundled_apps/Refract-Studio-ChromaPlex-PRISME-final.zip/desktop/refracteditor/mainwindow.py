import os, sys, json, time, traceback, asyncio, base64
from PyQt6.QtWidgets import (
    QMainWindow, QToolBar, QStatusBar, QSplitter, QTabWidget,
    QPlainTextEdit, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QMessageBox, QApplication, QInputDialog, QCheckBox,
    QDialog, QDialogButtonBox, QFormLayout, QLineEdit, QTextEdit, QComboBox
)
from PyQt6.QtGui import QAction, QKeySequence, QFontDatabase
from PyQt6.QtCore import Qt, QSettings, QStandardPaths, pyqtSignal, QObject, QThread

from .backend import ChromaplexBackend
from .editor import CodeEditor, CPLHighlighter
from .debugger import DebuggerPanel
from .preview import PreviewPane
from .external_runner import ExternalRunWindow
from .cpl_adapter import compile_cpl
from .optical_simulator_panel import OpticalSimulatorPanel
from .runtime_manager import RuntimeManagerDialog

# IC‑agent imports
from ic.agent import Agent
from ic.client import Client
from ic.identity import Identity
from ic.canister import Canister

# Krypteringsbiblioteker
try:
    from nacl.public import PublicKey, SealedBox
    HAS_NACL = True
except ImportError:
    HAS_NACL = False
    print("⚠️ PyNaCl ikke installeret. Kør: pip install pynacl")


class ConsoleRedirector(QObject):
    new_text = pyqtSignal(str)
    def __init__(self, console_widget):
        super().__init__()
        self.console = console_widget
        self.new_text.connect(self.console.appendPlainText)
    def write(self, text):
        if text.strip():
            self.new_text.emit(text.rstrip('\n'))
    def flush(self):
        pass


class CrystalAddressWorker(QThread):
    finished = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(self, canister_id: str):
        super().__init__()
        self.canister_id = canister_id

    def run(self):
        try:
            address = asyncio.run(self._ping_crystal())
            self.finished.emit(address)
        except Exception as e:
            self.error.emit(str(e))

    async def _ping_crystal(self):
        identity = Identity()
        client = Client(url="https://ic0.app")
        agent = Agent(identity, client)

        candid = """
        service : {
            claim_next_slot : () -> (
                variant {
                    ok : text;
                    err : variant { exhausted : null }
                }
            );
        }
        """

        canister = Canister(
            agent=agent,
            canister_id=self.canister_id,
            candid=candid,
        )

        result = canister.claim_next_slot()

        if isinstance(result, (list, tuple)) and len(result) > 0:
            result = result[0]

        if isinstance(result, dict):
            if "ok" in result:
                address = result["ok"]
                address = address.replace("blaa", "blå")
                return address
            elif "err" in result:
                if isinstance(result["err"], dict) and "exhausted" in result["err"]:
                    return None
                else:
                    raise RuntimeError(f"Fejl fra canister: {result['err']}")
            else:
                raise RuntimeError(f"Uventet svar: {result}")
        else:
            raise RuntimeError(f"Uventet resultat-type: {type(result)} - {repr(result)}")


class PublicKeyFetcher(QThread):
    finished = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(self, canister_id: str, principal: str = None):
        super().__init__()
        self.canister_id = canister_id
        self.principal = principal or "aaaaa-aa"

    def run(self):
        try:
            public_key = asyncio.run(self._fetch_public_key())
            self.finished.emit(public_key)
        except Exception as e:
            self.error.emit(str(e))

    async def _fetch_public_key(self):
        identity = Identity()
        client = Client(url="https://ic0.app")
        agent = Agent(identity, client)

        candid = """
        service : {
            get_user_public_key : (principal) -> (text);
        }
        """

        canister = Canister(
            agent=agent,
            canister_id=self.canister_id,
            candid=candid,
        )

        result = canister.get_user_public_key(self.principal)

        if isinstance(result, (list, tuple)) and len(result) > 0:
            result = result[0]

        if isinstance(result, str):
            return result
        else:
            raise RuntimeError(f"Uventet svar fra get_user_public_key: {result}")


class EncryptionSettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🔒 Krypteringsindstillinger")
        self.setModal(True)
        self.resize(620, 650)

        layout = QVBoxLayout(self)

        info_label = QLabel(
            "End-to-end kryptering af metadata (kode, filnavn, sprog).\n"
            "Krypteringen sker i din browser/editor – den private nøgle "
            "forlader aldrig din wallet."
        )
        info_label.setWordWrap(True)
        info_label.setStyleSheet("color: #2563EB; padding: 10px;")
        layout.addWidget(info_label)

        wallet_container = QWidget()
        wallet_container.setStyleSheet("""
            QWidget {
                background-color: #F5F7FB;
                border: 1px solid #D8E0EC;
                border-radius: 4px;
                padding: 10px;
            }
        """)
        wallet_layout = QVBoxLayout(wallet_container)

        wallet_title = QLabel("🔑 Hent nøgle fra wallet")
        wallet_title.setStyleSheet("font-weight: bold; font-size: 12pt; color: #2563EB;")
        wallet_layout.addWidget(wallet_title)

        wallet_info = QLabel(
            "Hvis den automatiske hentning bliver blokeret af firewall,\n"
            "kan du manuelt hente din offentlige nøgle og canister-ID fra wallet'en:"
        )
        wallet_info.setWordWrap(True)
        wallet_info.setStyleSheet("color: #64748B;")
        wallet_layout.addWidget(wallet_info)

        link_label = QLabel(
            '<a href="https://chromaplex-wallet-sgm.caffeine.xyz" style="color: #2563EB; text-decoration: underline;">'
            '🌐 Åbn Chromaplex Wallet: https://chromaplex-wallet-sgm.caffeine.xyz</a>'
        )
        link_label.setOpenExternalLinks(True)
        link_label.setTextFormat(Qt.TextFormat.RichText)
        link_label.setStyleSheet("padding: 8px 0px;")
        wallet_layout.addWidget(link_label)

        instructions = QLabel(
            "📋 Instruktioner:\n"
            "1. Åbn wallet'en i din browser\n"
            "2. Find 'Settings' eller 'Indstillinger'\n"
            "3. Kopiér din offentlige nøgle (Public Key) – en base64-streng\n"
            "4. Kopiér dit canister-ID\n"
            "5. Kopiér din wallet principal (din identitet)\n"
            "6. Indsæt dem i felterne nedenfor"
        )
        instructions.setStyleSheet("color: #64748B; background-color: #F8FAFD; padding: 8px; border-radius: 4px;")
        instructions.setWordWrap(True)
        wallet_layout.addWidget(instructions)

        layout.addWidget(wallet_container)

        activation_container = QWidget()
        activation_container.setStyleSheet("""
            QWidget {
                background-color: #F5F7FB;
                border: 1px solid #D8E0EC;
                border-radius: 4px;
                padding: 10px;
                margin-top: 10px;
            }
        """)
        activation_layout = QVBoxLayout(activation_container)

        self.encryption_enabled = QCheckBox("✅ AKTIVER KRYPTERING AF METADATA")
        self.encryption_enabled.setChecked(
            parent.settings.value("encryption_enabled", False, type=bool)
        )
        self.encryption_enabled.setStyleSheet("""
            QCheckBox {
                color: #2563EB;
                font-weight: bold;
                font-size: 11pt;
                padding: 5px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
        """)
        activation_layout.addWidget(self.encryption_enabled)

        activation_info = QLabel(
            "⚠️ Kryptering skal være AKTIVERET for at metadata (kode, filnavn, sprog) "
            "bliver krypteret før afsendelse til blockchainen."
        )
        activation_info.setWordWrap(True)
        activation_info.setStyleSheet("color: #64748B; font-size: 9pt; padding-left: 5px;")
        activation_layout.addWidget(activation_info)

        layout.addWidget(activation_container)

        form = QFormLayout()
        form.setSpacing(10)

        self.public_key_input = QLineEdit()
        self.public_key_input.setPlaceholderText("Walletens offentlige nøgle (base64)")
        self.public_key_input.setText(
            parent.settings.value("wallet_public_key", "")
        )
        self.public_key_input.setStyleSheet("""
            QLineEdit {
                background-color: #FFFFFF;
                color: #2563EB;
                border: 1px solid #D8E0EC;
                padding: 6px;
                font-family: monospace;
            }
        """)
        form.addRow("🔑 Offentlig nøgle:", self.public_key_input)

        self.canister_id_input = QLineEdit()
        self.canister_id_input.setText(
            parent.settings.value("encryption_canister_id", "")
        )
        self.canister_id_input.setPlaceholderText("Canister ID der udsteder nøgler")
        self.canister_id_input.setStyleSheet("""
            QLineEdit {
                background-color: #FFFFFF;
                color: #2563EB;
                border: 1px solid #D8E0EC;
                padding: 6px;
                font-family: monospace;
            }
        """)
        form.addRow("📦 Canister ID:", self.canister_id_input)

        self.principal_input = QLineEdit()
        self.principal_input.setText(
            parent.settings.value("wallet_principal", "")
        )
        self.principal_input.setPlaceholderText("Din wallet principal (f.eks. aaaaa-aa)")
        self.principal_input.setStyleSheet("""
            QLineEdit {
                background-color: #FFFFFF;
                color: #2563EB;
                border: 1px solid #D8E0EC;
                padding: 6px;
                font-family: monospace;
            }
        """)
        form.addRow("👤 Principal:", self.principal_input)

        layout.addLayout(form)

        btn_layout = QHBoxLayout()

        self.fetch_btn = QPushButton("📥 Hent nøgle automatisk")
        self.fetch_btn.clicked.connect(self.fetch_key_from_wallet)
        self.fetch_btn.setToolTip("Forsøg at hente nøgle via IC-netværket (kan blokeres af firewall)")
        self.fetch_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFFFFF;
                color: #2563EB;
                border: 1px solid #D8E0EC;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #2563EB;
                color: #FFFFFF;
            }
        """)
        btn_layout.addWidget(self.fetch_btn)

        btn_layout.addStretch()

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        buttons.setStyleSheet("""
            QPushButton {
                background-color: #FFFFFF;
                color: #2563EB;
                border: 1px solid #D8E0EC;
                padding: 6px 16px;
            }
            QPushButton:hover {
                background-color: #2563EB;
                color: #FFFFFF;
            }
        """)
        btn_layout.addWidget(buttons)

        layout.addLayout(btn_layout)

        self.parent_ref = parent
        self.fetcher = None

    def fetch_key_from_wallet(self):
        canister_id = self.canister_id_input.text().strip()
        principal = self.principal_input.text().strip() or "aaaaa-aa"

        if not canister_id:
            QMessageBox.warning(self, "Mangler ID", "Angiv canister ID først.")
            return

        self.fetch_btn.setEnabled(False)
        self.fetch_btn.setText("⏳ Henter...")

        self.fetcher = PublicKeyFetcher(canister_id, principal)
        self.fetcher.finished.connect(self._on_key_fetched)
        self.fetcher.error.connect(self._on_key_error)
        self.fetcher.start()

    def _on_key_fetched(self, public_key: str):
        self.public_key_input.setText(public_key)
        self.fetch_btn.setEnabled(True)
        self.fetch_btn.setText("📥 Hent nøgle automatisk")
        QMessageBox.information(
            self,
            "Nøgle hentet",
            "Offentlig nøgle er hentet fra wallet-en."
        )

    def _on_key_error(self, error: str):
        self.fetch_btn.setEnabled(True)
        self.fetch_btn.setText("📥 Hent nøgle automatisk")
        QMessageBox.critical(
            self,
            "Fejl",
            f"Kunne ikke hente offentlig nøgle:\n{error}\n\n"
            "Prøv at hente nøglen manuelt via wallet-linket ovenfor."
        )


class RefractEditor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Refract Studio — ChromaPlex")
        self.resize(1600, 950)
        self.current_file = None
        self.language = "CPL"
        self.optical_stream = None
        self.run_windows = set()
        self.backend = ChromaplexBackend()
        self.settings = QSettings()

        self.crystal_canister_id = self.settings.value("crystal_canister_id", "<DIN_CANISTER_ID>")
        self.crystal_worker = None

        self.encryption_enabled = self.settings.value("encryption_enabled", False, type=bool)
        self.wallet_public_key = self.settings.value("wallet_public_key", "")
        self.encryption_canister_id = self.settings.value("encryption_canister_id", "")
        self.wallet_principal = self.settings.value("wallet_principal", "")

        self.editor = CodeEditor()
        self.highlighter = CPLHighlighter(self.editor.document())

        self.preview_pane = PreviewPane()
        self.preview_pane.refresh_btn.clicked.connect(self.update_preview)
        self.preview_pane.run_btn.clicked.connect(self.run_external)

        self.bottom_tabs = QTabWidget()
        self.setup_bottom_tabs()

        top_split = QSplitter(Qt.Orientation.Horizontal)
        top_split.addWidget(self.editor)
        top_split.addWidget(self.preview_pane)
        top_split.setSizes([900, 600])

        self.vert_split = QSplitter(Qt.Orientation.Vertical)
        self.vert_split.addWidget(top_split)
        self.vert_split.addWidget(self.bottom_tabs)
        self.vert_split.setSizes([610, 340])
        self.setCentralWidget(self.vert_split)

        self.create_toolbar()
        self.create_menus()

        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("Klar")

        self.console_redirector = ConsoleRedirector(self.console_output)
        self.original_stdout = sys.stdout
        sys.stdout = self.console_redirector

        self.setStyleSheet(self._make_stylesheet())
        self.update_encryption_status()

    def _make_stylesheet(self):
        return """
            QMainWindow { background-color: #F5F7FB; }
            QMenuBar {
                background-color: #FFFFFF; color: #2563EB;
                border-bottom: 1px solid #D8E0EC; font-family: monospace; font-size: 10pt;
            }
            QMenuBar::item:selected { background-color: #2563EB; color: #FFFFFF; }
            QMenu {
                background-color: #FFFFFF; color: #2563EB;
                border: 1px solid #D8E0EC;
            }
            QMenu::item:selected { background-color: #2563EB; color: #FFFFFF; }
            QToolBar {
                background-color: #F5F7FB;
                border-bottom: 1px solid #D8E0EC;
                spacing: 4px; padding: 2px;
            }
            QToolButton {
                background-color: #FFFFFF; color: #2563EB;
                border: 1px solid #D8E0EC; border-radius: 4px;
                padding: 6px 10px; font-weight: bold; font-family: monospace;
            }
            QToolButton:hover {
                background-color: #2563EB; color: #FFFFFF;
                border: 1px solid #2563EB;
            }
            QSplitter::handle { background-color: #D8E0EC; width: 1px; height: 1px; }
            QSplitter::handle:horizontal, QSplitter::handle:vertical { background-color: #D8E0EC; }
            QTabWidget::pane { border: 1px solid #D8E0EC; background-color: #F5F7FB; }
            QTabBar::tab {
                background-color: #EEF2F8; color: #2563EB;
                border: 1px solid #D8E0EC; border-bottom: none;
                padding: 6px 16px; font-family: monospace;
            }
            QTabBar::tab:selected {
                background-color: #F5F7FB;
                border-bottom: 2px solid #2563EB; color: #2563EB;
            }
            QTabBar::tab:hover { background-color: #2563EB; color: #FFFFFF; }
            QPlainTextEdit, QTextBrowser, QWebEngineView {
                background-color: #F8FAFD; color: #2563EB;
                border: 1px solid #D8E0EC; font-family: monospace;
            }
            QStatusBar {
                background-color: #FFFFFF; color: #2563EB;
                border-top: 1px solid #D8E0EC;
            }
            QCheckBox {
                color: #2563EB;
                background-color: transparent;
            }
            QDialog {
                background-color: #F5F7FB;
            }
            QLabel {
                color: #2563EB;
                background-color: transparent;
            }
            QLineEdit, QComboBox {
                background-color: #FFFFFF;
                color: #172033;
                border: 1px solid #D8E0EC;
                border-radius: 6px;
                padding: 6px 9px;
            }
            QComboBox::drop-down { border: none; width: 22px; }
            QComboBox QAbstractItemView {
                background: #FFFFFF; color: #172033;
                selection-background-color: #DBEAFE;
                selection-color: #1D4ED8;
            }
            QGroupBox {
                color: #2563EB;
                border: 1px solid #D8E0EC;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            a {
                color: #2563EB;
                text-decoration: underline;
            }
            a:hover {
                color: #1D4ED8;
            }
        """

    def setup_bottom_tabs(self):
        console_tab = QWidget()
        cl = QVBoxLayout(console_tab)
        self.console_output = QPlainTextEdit()
        self.console_output.setReadOnly(True)
        self.console_output.setStyleSheet("background-color: #F8FAFD; color: #2563EB; font-family: monospace;")
        cl.addWidget(self.console_output)
        self.bottom_tabs.addTab(console_tab, "Console")

        self.debugger_panel = DebuggerPanel(self.log_to_bugtracker)
        self.bottom_tabs.addTab(self.debugger_panel, "Debugger")

        bug_tab = QWidget()
        bl = QVBoxLayout(bug_tab)
        self.bug_tracker = QPlainTextEdit()
        self.bug_tracker.setReadOnly(True)
        self.bug_tracker.setStyleSheet("background-color: #F8FAFD; color: #DC2626; font-family: monospace;")
        bl.addWidget(self.bug_tracker)
        self.bottom_tabs.addTab(bug_tab, "Bug Tracker")

        self.optical_simulator_panel = OpticalSimulatorPanel(
            self._current_source
        )
        self.optical_simulator_panel.close_requested.connect(
            self.hide_optical_simulator
        )
        self.editor.textChanged.connect(
            self.optical_simulator_panel.schedule_refresh
        )
        self.bottom_tabs.addTab(
            self.optical_simulator_panel, "Optical Simulator"
        )

    def create_toolbar(self):
        toolbar = QToolBar("Hovedværktøjslinje")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)

        new_act = QAction("📄 Ny fil", self)
        new_act.triggered.connect(self.new_file)
        toolbar.addAction(new_act)

        save_act = QAction("💾 Gem", self)
        save_act.triggered.connect(self.save_file)
        toolbar.addAction(save_act)

        open_act = QAction("📂 Åbn / Decompile", self)
        open_act.triggered.connect(self.open_file)
        toolbar.addAction(open_act)

        toolbar.addSeparator()
        toolbar.addWidget(QLabel("Sprog"))
        self.language_combo = QComboBox()
        self.language_combo.addItems([
            "CPL", "CPA", "PRISME ASM", "Spectral IR", "Python",
            "JavaScript", "TypeScript", "C", "C++", "Rust", "Go",
            "Java", "Shell/Bash", "PowerShell", "Ruby", "PHP", "Perl",
            "Lua", "R", "Batch", "HTML", "CSS", "JSON IR", "Hex"
        ])
        self.language_combo.currentTextChanged.connect(self._language_selected)
        toolbar.addWidget(self.language_combo)

        toolbar.addSeparator()

        compile_act = QAction("⚙ Kompilér CPL → CPA", self)
        compile_act.triggered.connect(self.compile_cpl_to_cpa)
        toolbar.addAction(compile_act)

        toolbar.addSeparator()

        ship_act = QAction("⚡ SHIP TO CHROMAPLEX", self)
        ship_act.triggered.connect(self.ship_to_chromaplex)
        toolbar.addAction(ship_act)
        ship_btn = toolbar.widgetForAction(ship_act)
        if ship_btn:
            ship_btn.setStyleSheet("""
                background-color: #F8FAFD; border: 1px solid #2563EB;
                color: #2563EB; font-weight: bold;
            """)

        toolbar.addSeparator()
        run_act = QAction("▶ Kør kode", self)
        run_act.setToolTip("Kør den valgte kode i et separat testvindue (Ctrl+F5)")
        run_act.triggered.connect(self.run_external)
        toolbar.addAction(run_act)

        toolbar.addSeparator()
        self.encryption_status_label = QLabel()
        self.update_encryption_status()
        toolbar.addWidget(self.encryption_status_label)

    def create_menus(self):
        menubar = self.menuBar()

        file_menu = menubar.addMenu("Fil")

        new_action = QAction("📄 Ny", self)
        new_action.setShortcut(QKeySequence.StandardKey.New)
        new_action.triggered.connect(self.new_file)
        file_menu.addAction(new_action)

        open_action = QAction("📂 Åbn...", self)
        open_action.setShortcut(QKeySequence.StandardKey.Open)
        open_action.triggered.connect(self.open_file)
        file_menu.addAction(open_action)

        save_action = QAction("💾 Gem", self)
        save_action.setShortcut(QKeySequence.StandardKey.Save)
        save_action.triggered.connect(self.save_file)
        file_menu.addAction(save_action)

        save_as_action = QAction("💾 Gem som...", self)
        save_as_action.setShortcut(QKeySequence("Ctrl+Shift+S"))
        save_as_action.triggered.connect(self.save_file_as)
        file_menu.addAction(save_as_action)

        file_menu.addSeparator()

        decomp_json_action = QAction("Decompile JSON", self)
        decomp_json_action.triggered.connect(self.decompile_json)
        file_menu.addAction(decomp_json_action)

        decomp_bin_action = QAction("Decompile BIN (CPX2)", self)
        decomp_bin_action.triggered.connect(self.decompile_bin)
        file_menu.addAction(decomp_bin_action)

        file_menu.addSeparator()

        export_action = QAction("Exportmappe vælg...", self)
        export_action.triggered.connect(self.choose_export_dir)
        file_menu.addAction(export_action)

        exit_action = QAction("Afslut", self)
        exit_action.setShortcut(QKeySequence.StandardKey.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        run_menu = menubar.addMenu("Kør")

        debug_action = QAction("Start Debug", self)
        debug_action.triggered.connect(self.debugger_panel.start_debug)
        run_menu.addAction(debug_action)

        compile_action = QAction("⚙ Kompilér CPL → CPA", self)
        compile_action.setShortcut(QKeySequence("F6"))
        compile_action.triggered.connect(self.compile_cpl_to_cpa)
        run_menu.addAction(compile_action)

        run_external_action = QAction("▶ Kør kode i eget vindue", self)
        run_external_action.setShortcut(QKeySequence("Ctrl+F5"))
        run_external_action.triggered.connect(self.run_external)
        run_menu.addAction(run_external_action)

        run_menu.addSeparator()

        ship_action = QAction("⚡ SHIP TO CHROMAPLEX", self)
        ship_action.setShortcut(QKeySequence("F5"))
        ship_action.triggered.connect(self.ship_to_chromaplex)
        run_menu.addAction(ship_action)

        view_menu = menubar.addMenu("Vis")

        fullscreen_action = QAction("Fuld skærm", self)
        fullscreen_action.setShortcut(QKeySequence("F11"))
        fullscreen_action.triggered.connect(self.toggle_fullscreen)
        view_menu.addAction(fullscreen_action)

        preview_fullscreen_action = QAction("Preview i fuld skærm", self)
        preview_fullscreen_action.setShortcut(QKeySequence("Ctrl+Shift+F11"))
        preview_fullscreen_action.triggered.connect(
            self.preview_pane.show_fullscreen
        )
        view_menu.addAction(preview_fullscreen_action)

        simulator_action = QAction("Vis Optical Routing Simulator", self)
        simulator_action.setShortcut(QKeySequence("Ctrl+Shift+O"))
        simulator_action.triggered.connect(self.show_optical_simulator)
        view_menu.addAction(simulator_action)

        settings_menu = menubar.addMenu("Indstillinger")

        crystal_id_action = QAction("Sæt krystal‑canister ID", self)
        crystal_id_action.triggered.connect(self.set_crystal_canister_id)
        settings_menu.addAction(crystal_id_action)

        settings_menu.addSeparator()

        encryption_action = QAction("🔒 Krypteringsindstillinger", self)
        encryption_action.triggered.connect(self.open_encryption_settings)
        settings_menu.addAction(encryption_action)

        runtime_action = QAction("Runtimes og installation…", self)
        runtime_action.triggered.connect(self.open_runtime_manager)
        settings_menu.addAction(runtime_action)

        help_menu = menubar.addMenu("Hjælp")
        about_action = QAction("Om Refract Studio", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

        integration_action = QAction("📖 Integration Guide", self)
        integration_action.triggered.connect(self.show_integration_guide)
        help_menu.addAction(integration_action)

    def update_encryption_status(self):
        if self.encryption_enabled and self.wallet_public_key:
            self.encryption_status_label.setText(" 🔒 Kryptering AKTIVERET")
            self.encryption_status_label.setStyleSheet("color: #2563EB; font-weight: bold;")
            self.setWindowTitle("Refract Studio — ChromaPlex 🔒")
        else:
            self.encryption_status_label.setText(" 🔓 Kryptering FRAVALGT")
            self.encryption_status_label.setStyleSheet("color: #B45309; font-weight: bold;")
            self.setWindowTitle("Refract Studio — ChromaPlex")

    def open_encryption_settings(self):
        dialog = EncryptionSettingsDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.encryption_enabled = dialog.encryption_enabled.isChecked()
            self.wallet_public_key = dialog.public_key_input.text().strip()
            self.encryption_canister_id = dialog.canister_id_input.text().strip()
            self.wallet_principal = dialog.principal_input.text().strip()

            self.settings.setValue("encryption_enabled", self.encryption_enabled)
            self.settings.setValue("wallet_public_key", self.wallet_public_key)
            self.settings.setValue("encryption_canister_id", self.encryption_canister_id)
            self.settings.setValue("wallet_principal", self.wallet_principal)

            self.update_encryption_status()
            self.status.showMessage("Krypteringsindstillinger gemt")

    def encrypt_metadata(self, metadata: dict) -> dict:
        if not self.encryption_enabled or not self.wallet_public_key:
            return metadata

        if not HAS_NACL:
            raise RuntimeError(
                "PyNaCl er ikke installeret. Kør: pip install pynacl"
            )

        try:
            metadata_json = json.dumps(metadata, ensure_ascii=False)
            public_key_bytes = base64.b64decode(self.wallet_public_key)
            public_key = PublicKey(public_key_bytes)
            sealed_box = SealedBox(public_key)

            encrypted_bytes = sealed_box.encrypt(metadata_json.encode('utf-8'))
            encrypted_base64 = base64.b64encode(encrypted_bytes).decode('ascii')

            key_id = self.encryption_canister_id or "default"

            return {
                "metadata_encrypted": encrypted_base64,
                "metadata_key_id": key_id
            }

        except Exception as e:
            raise RuntimeError(f"Krypteringsfejl: {e}")

    def show_integration_guide(self):
        guide = QDialog(self)
        guide.setWindowTitle("📖 Integration Guide – End-to-end Kryptering")
        guide.resize(700, 600)
        guide.setModal(True)

        layout = QVBoxLayout(guide)

        text = QTextEdit()
        text.setReadOnly(True)
        text.setStyleSheet("""
            QTextEdit {
                background-color: #F5F7FB;
                color: #2563EB;
                font-family: monospace;
                border: 1px solid #D8E0EC;
            }
        """)
        text.setHtml(f'''
        <h2 style="color: #2563EB;">End-to-end Kryptering af Metadata</h2>
        <p style="color: #64748B;">Sådan integrerer du kryptering i dit Python-script</p>

        <h3 style="color: #2563EB;">📋 Trin 1: Hent walletens offentlige nøgle</h3>
        <pre style="background-color: #F8FAFD; padding: 10px; border: 1px solid #D8E0EC; color: #2563EB;">
        from ic.agent import Agent
        from ic.client import Client
        from ic.identity import Identity
        from ic.canister import Canister

        async def get_user_public_key(canister_id, principal):
            identity = Identity()
            client = Client(url="https://ic0.app")
            agent = Agent(identity, client)

            candid = """
            service : {{
                get_user_public_key : (principal) -> (text);
            }}
            """

            canister = Canister(
                agent=agent,
                canister_id=canister_id,
                candid=candid,
            )

            result = canister.get_user_public_key(principal)
            if isinstance(result, (list, tuple)) and len(result) > 0:
                result = result[0]
            return result  # Base64-streng
        </pre>

        <h3 style="color: #2563EB;">🔐 Trin 2: Installer PyNaCl</h3>
        <pre style="background-color: #F8FAFD; padding: 10px; border: 1px solid #D8E0EC; color: #2563EB;">
        pip install pynacl
        </pre>

        <h3 style="color: #2563EB;">📦 Trin 3: Krypter metadata med NaCl SealedBox</h3>
        <pre style="background-color: #F8FAFD; padding: 10px; border: 1px solid #D8E0EC; color: #2563EB;">
        import base64, json
        from nacl.public import PublicKey, SealedBox

        def encrypt_metadata(metadata_json, public_key_base64):
            public_key_bytes = base64.b64decode(public_key_base64)
            public_key = PublicKey(public_key_bytes)
            sealed_box = SealedBox(public_key)

            encrypted_bytes = sealed_box.encrypt(metadata_json.encode('utf-8'))
            encrypted_base64 = base64.b64encode(encrypted_bytes).decode('ascii')
            return encrypted_base64
        </pre>

        <h3 style="color: #2563EB;">📤 Trin 4: Send payload med krypteret metadata</h3>
        <pre style="background-color: #F8FAFD; padding: 10px; border: 1px solid #D8E0EC; color: #2563EB;">
        payload = {{
            "payload_id": "abc123...",
            "source_address": "C0:F1:blå:D3",
            "value": 1234567,
            "representation": "3^12 + 703126",
            "extraction_hash": "6c8b94f3...",
            "ledger_proof": [...],
            "timestamp": 1782976927.26,
            "metadata_encrypted": encrypted,
            "metadata_key_id": "{self.encryption_canister_id or 'default'}"
        }}
        </pre>

        <h3 style="color: #B45309;">⚠️ Vigtigt</h3>
        <ul style="color: #64748B;">
            <li>Den private nøgle forlader ALDRIG din browser/wallet</li>
            <li>Krypteringen sker lokalt i editoren</li>
            <li>Regel 1 og Regel 6 verificeres stadig</li>
        </ul>
        ''')

        layout.addWidget(text)

        btn = QPushButton("Luk")
        btn.clicked.connect(guide.accept)
        btn.setStyleSheet("""
            QPushButton {
                background-color: #FFFFFF;
                color: #2563EB;
                border: 1px solid #D8E0EC;
                padding: 8px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2563EB;
                color: #FFFFFF;
            }
        """)
        layout.addWidget(btn, alignment=Qt.AlignmentFlag.AlignRight)

        guide.exec()

    def set_crystal_canister_id(self):
        current = self.crystal_canister_id
        new_id, ok = QInputDialog.getText(self, "Krystal‑canister ID",
                                          "Indtast canister‑ID for krystallen (principal):",
                                          text=current)
        if ok and new_id:
            self.crystal_canister_id = new_id
            self.settings.setValue("crystal_canister_id", new_id)
            self.status.showMessage(f"Canister ID opdateret til {new_id}")

    def show_privacy_warning(self):
        if self.settings.value("privacy_warning_shown", False, type=bool):
            return True

        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setWindowTitle("OBS: Offentlig blockchain")
        msg.setText(
            "⚠️ ADVARSEL: Du er ved at sende din kode til Chromaplex!\n\n"
            "Koden vil blive lagret PERMANENT og OFFENTLIGT tilgængelig "
            "på blockchainen. Dette kan IKKE fortrydes.\n\n"
            "Sørg for, at koden IKKE indeholder:\n"
            "• API-nøgler eller adgangskoder\n"
            "• Personlige eller fortrolige data\n"
            "• Proprietær forretningslogik\n\n"
            "Er du sikker på, at du vil fortsætte?"
        )
        msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        msg.setDefaultButton(QMessageBox.StandardButton.No)

        checkbox = QCheckBox("Vis ikke denne advarsel igen")
        msg.setCheckBox(checkbox)

        result = msg.exec()

        if checkbox.isChecked():
            self.settings.setValue("privacy_warning_shown", True)

        return result == QMessageBox.StandardButton.Yes

    def new_file(self):
        self.editor.clear()
        self.current_file = None
        self._set_language("CPL")
        self.optical_stream = None
        self.status.showMessage("Ny fil")

    def _set_language(self, language: str):
        self.language = language
        if hasattr(self, "language_combo"):
            index = self.language_combo.findText(language)
            if index >= 0:
                self.language_combo.blockSignals(True)
                self.language_combo.setCurrentIndex(index)
                self.language_combo.blockSignals(False)

    def _language_selected(self, language: str):
        self.language = language
        if hasattr(self, "optical_simulator_panel"):
            self.optical_simulator_panel.schedule_refresh()

    def _current_source(self):
        return self.editor.toPlainText(), self.language

    def hide_optical_simulator(self):
        index = self.bottom_tabs.indexOf(self.optical_simulator_panel)
        if index >= 0:
            self.bottom_tabs.removeTab(index)
        self.optical_simulator_panel.stop_server()
        self.status.showMessage(
            "Optical Simulator lukket — åbn igen fra Vis-menuen"
        )

    def show_optical_simulator(self):
        index = self.bottom_tabs.indexOf(self.optical_simulator_panel)
        if index < 0:
            index = self.bottom_tabs.addTab(
                self.optical_simulator_panel, "Optical Simulator"
            )
        self.bottom_tabs.setCurrentIndex(index)
        self.optical_simulator_panel.start_server()
        self.optical_simulator_panel.refresh_colour_code()
        self.vert_split.setSizes([560, 390])

    def open_runtime_manager(self):
        dialog = RuntimeManagerDialog(self)
        dialog.exec()

    def compile_cpl_to_cpa(self):
        if self.language != "CPL":
            QMessageBox.information(
                self,
                "Vælg CPL",
                "CPL → CPA-kompilering kræver, at sproget er sat til CPL.",
            )
            return
        try:
            cpa, dialect = compile_cpl(self.editor.toPlainText())
        except Exception as exc:
            self.log_to_bugtracker(f"CPL compilerfejl: {exc}")
            QMessageBox.critical(self, "CPL compilerfejl", str(exc))
            return

        dialog = QDialog(self)
        dialog.setWindowTitle(f"Genereret CPA — {dialect}")
        dialog.resize(980, 700)
        layout = QVBoxLayout(dialog)
        info = QLabel(
            f"Compiler: {dialect}. Koden nedenfor er genereret af den "
            "medfølgende ChromaPlex compiler."
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        output = QPlainTextEdit()
        output.setPlainText(cpa)
        layout.addWidget(output)
        buttons = QHBoxLayout()
        open_button = QPushButton("Åbn CPA i editor")
        save_button = QPushButton("Gem CPA…")
        close_button = QPushButton("Luk")
        buttons.addStretch()
        buttons.addWidget(open_button)
        buttons.addWidget(save_button)
        buttons.addWidget(close_button)
        layout.addLayout(buttons)

        def open_in_editor():
            self.editor.setPlainText(output.toPlainText())
            self.current_file = None
            self._set_language("CPA")
            dialog.accept()

        def save_cpa():
            path, _ = QFileDialog.getSaveFileName(
                dialog, "Gem CPA", "", "ChromaPlex CPA (*.cpa)"
            )
            if path:
                with open(path, "w", encoding="utf-8") as handle:
                    handle.write(output.toPlainText())

        open_button.clicked.connect(open_in_editor)
        save_button.clicked.connect(save_cpa)
        close_button.clicked.connect(dialog.accept)
        dialog.exec()

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Åbn fil", "",
                                              "Alle filer (*);;ChromaPlex (*.cpl *.cpa);;PRISME (*.prisme *.asm4);;C/C++ (*.c *.cpp);;Python (*.py);;JSON payloads (*.json);;Binary (*.bin)")
        if not path:
            return
        try:
            with open(path, 'rb') as f:
                magic = f.read(4)
            if magic == b'CPX2':
                code = self.backend.decompile_bin(path)
                self._set_language("CPL")
            elif magic == b'OPTB':
                choices = ["PRISME ASM", "CPL", "CPA", "Python", "JavaScript",
                           "TypeScript", "C", "C++", "Rust", "Go", "Spectral IR",
                           "Hex", "JSON IR"]
                view, ok = QInputDialog.getItem(
                    self, "Åbn OPTB v1", "Vis den optiske strøm som:", choices, 0, False
                )
                if not ok:
                    return
                try:
                    code, language, stream = self.backend.import_optical_binary(path, view)
                except ValueError:
                    code, language, stream = self.backend.import_optical_binary(path, "Spectral IR")
                    QMessageBox.information(
                        self,
                        "Rå spektral strøm",
                        "Filen er en gyldig OPTB-strøm, men den er ikke grupperet som "
                        "PRISME-glimt i R/G/B/V/UV-rækkefølge. Den åbnes derfor som "
                        "tabsfri spektral IR."
                    )
                self.optical_stream = stream
                self._set_language(language)
            else:
                with open(path, 'r', encoding='utf-8') as f:
                    code = f.read()
                self._set_language(self.backend.detect_language(path))
            self.editor.setPlainText(code)
            self.current_file = path
            self.status.showMessage(f"Åbnet: {path}  |  Sprog: {self.language}")
        except Exception as e:
            self.log_to_bugtracker(f"Fejl ved åbning af fil: {traceback.format_exc()}")

    def save_file(self):
        if self.current_file:
            self._write_file(self.current_file)
        else:
            self.save_file_as()

    def save_file_as(self):
        path, _ = QFileDialog.getSaveFileName(self, "Gem som", "",
                                              "Optical PRISME stream (*.bin);;PRISME assembler (*.prisme);;ChromaPlex CPL (*.cpl);;ChromaPlex CPA (*.cpa);;C source (*.c);;Alle filer (*)")
        if not path:
            return
        self.current_file = path
        self._write_file(path)

    def _write_file(self, path):
        if path.lower().endswith(".bin"):
            self.backend.export_optical_binary(
                path, self.editor.toPlainText(), self.language
            )
        else:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.editor.toPlainText())
        self.status.showMessage(f"Gemt: {path}")

    def decompile_json(self):
        path, _ = QFileDialog.getOpenFileName(self, "Vælg JSON payload", "", "JSON (*.json)")
        if not path:
            return
        try:
            code, original_lang = self.backend.decompile_json_full(path)
            self.editor.setPlainText(code)
            self.current_file = None
            self.language = original_lang if original_lang else "Ukendt"
            self.status.showMessage("JSON decompilet.")
        except Exception as e:
            self.log_to_bugtracker(f"JSON decompile fejl: {traceback.format_exc()}")

    def decompile_bin(self):
        path, _ = QFileDialog.getOpenFileName(self, "Vælg BIN (CPX2 / OPTB)", "", "Binary (*.bin)")
        if not path:
            return
        try:
            with open(path, "rb") as f:
                magic = f.read(4)
            if magic == b"OPTB":
                try:
                    code, language, stream = self.backend.import_optical_binary(path, "PRISME ASM")
                except ValueError:
                    code, language, stream = self.backend.import_optical_binary(path, "Spectral IR")
                self.optical_stream = stream
                self._set_language(language)
            else:
                code = self.backend.decompile_bin(path)
                self._set_language("CPL")
            self.editor.setPlainText(code)
            self.current_file = None
            self.status.showMessage("BIN dekompileret.")
        except Exception as e:
            self.log_to_bugtracker(f"BIN decompile fejl: {traceback.format_exc()}")

    def update_preview(self):
        code = self.editor.toPlainText()
        js_enabled = (self.language == "HTML" or code.strip().startswith("<"))
        self.preview_pane.set_javascript_enabled(js_enabled)
        if js_enabled:
            self.preview_pane.load_html(code)
        else:
            escaped = code.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            html = f"""
            <html><head><style>
                body {{
                    background-color: #F8FAFD; color: #172033;
                    font-family: system-ui, sans-serif; padding: 28px;
                }}
                .notice {{
                    background: #EFF6FF; border: 1px solid #BFDBFE;
                    border-radius: 10px; padding: 14px 16px; margin-bottom: 18px;
                }}
                .notice strong {{ color: #1D4ED8; }}
                pre {{
                    color: #2563EB; font-family: monospace; white-space: pre-wrap;
                    background: white; border: 1px solid #D8E0EC;
                    border-radius: 10px; padding: 18px;
                }}
            </style></head><body>
                <div class="notice">
                    <strong>{self.language}</strong> køres ikke inde i HTML-previewet.
                    Brug <strong>▶ Kør i eget vindue</strong> eller
                    <strong>Ctrl+F5</strong> for test, output og fejl.
                </div>
                <pre>{escaped}</pre>
            </body></html>
            """
            self.preview_pane.load_html(html)
        print("Forhåndsvisning opdateret.")

    def run_external(self):
        code = self.editor.toPlainText()
        if not code.strip():
            QMessageBox.warning(self, "Ingen kode", "Editoren er tom.")
            return
        if self.language == "HTML" or code.strip().startswith("<"):
            self.update_preview()
            self.preview_pane.show_fullscreen()
            self.status.showMessage("HTML kører i preview-vinduet")
            return

        window = ExternalRunWindow(code, self.language, self)
        self.run_windows.add(window)
        window.destroyed.connect(
            lambda _object=None, run_window=window:
            self.run_windows.discard(run_window)
        )
        window.show()
        window.raise_()
        window.activateWindow()
        self.status.showMessage(
            f"{self.language} startet i separat testvindue"
        )

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showMaximized()
        else:
            self.showFullScreen()

    def ship_to_chromaplex(self):
        code = self.editor.toPlainText()
        if not code.strip():
            QMessageBox.warning(self, "Intet kode", "Editor er tom.")
            return

        if not self.show_privacy_warning():
            self.status.showMessage("Shipping afbrudt af brugeren")
            return

        if self.crystal_canister_id == "<DIN_CANISTER_ID>":
            new_id, ok = QInputDialog.getText(self, "Canister ID",
                                              "Indtast canister‑ID for krystallen (principal):")
            if ok and new_id:
                self.crystal_canister_id = new_id
                self.settings.setValue("crystal_canister_id", new_id)
            else:
                self.status.showMessage("Shipping afbrudt – mangler canister‑ID")
                return

        self._set_buttons_enabled(False)
        self.status.showMessage("Pinger krystallen for at reservere adresse...")

        self.crystal_worker = CrystalAddressWorker(self.crystal_canister_id)
        self.crystal_worker.finished.connect(self._on_crystal_address_received)
        self.crystal_worker.error.connect(self._on_crystal_error)
        self.crystal_worker.start()

    def _on_crystal_address_received(self, address: str):
        self._set_buttons_enabled(True)
        if address is None:
            QMessageBox.warning(self, "Adresse udsolgt",
                                "Alle 2850 adresser i krystallen er optaget.")
            self.status.showMessage("Shipping afbrudt – ingen ledige adresser")
            return
        self._ship_with_address(address)

    def _on_crystal_error(self, error_msg: str):
        self._set_buttons_enabled(True)
        QMessageBox.critical(self, "Fejl ved krystal‑ping",
                             f"Kunne ikke hente adresse:\n{error_msg}")
        self.status.showMessage("Shipping afbrudt – fejl")

    def _ship_with_address(self, source_address: str):
        try:
            code = self.editor.toPlainText()
            filename = self.current_file or "untitled.cpl"

            payload, _, hash_string = self.backend.compile_payload(
                code,
                filename,
                source_address=source_address
            )

            if self.encryption_enabled and self.wallet_public_key:
                try:
                    metadata = payload.pop("metadata", {})
                    encrypted_result = self.encrypt_metadata(metadata)
                    payload["metadata_encrypted"] = encrypted_result["metadata_encrypted"]
                    payload["metadata_key_id"] = encrypted_result["metadata_key_id"]
                    print("🔒 Metadata krypteret med walletens offentlige nøgle")
                except Exception as e:
                    self.log_to_bugtracker(f"Krypteringsfejl: {e}")
                    QMessageBox.warning(
                        self,
                        "Krypteringsfejl",
                        f"Kunne ikke kryptere metadata:\n{e}\n\n"
                        "Payload sendes uden kryptering."
                    )
                    payload["metadata"] = metadata

            json_str = json.dumps(payload, indent=2, ensure_ascii=False)

            export_dir = self.settings.value("export_dir")
            if not export_dir:
                export_dir = os.path.join(
                    QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DocumentsLocation),
                    "ChromaBridge"
                )
                self.settings.setValue("export_dir", export_dir)
            try:
                os.makedirs(export_dir, exist_ok=True)
            except OSError as e:
                QMessageBox.critical(self, "Fejl", f"Kan ikke oprette eksportmappe:\n{e}")
                return

            filepath = os.path.join(export_dir, f"refract_{int(time.time())}.json")
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(json_str)

            # Kopier JSON-streng til clipboard (ikke filnavn)
            QApplication.clipboard().setText(json_str)

            print(f"\n{'='*60}")
            print(f"✅ Shippet til Chromaplex!")
            print(f"📄 JSON gemt: {filepath}")
            print(f"📍 source_address: {source_address}")
            print(f"🔑 extraction_hash: {payload['extraction_hash']}")
            print(f"🔍 Hash-streng: {hash_string}")
            if "metadata_encrypted" in payload:
                print(f"🔒 Metadata: KRYPTERT")
            else:
                print(f"📄 Metadata: PLAINTEXT")
            print(f"📋 JSON kopieret til clipboard.\n{'='*60}")
            self.status.showMessage("Payload shippet til wallet.")
        except Exception as e:
            self.log_to_bugtracker(f"SHIP fejl: {traceback.format_exc()}")
            QMessageBox.critical(self, "Fejl ved shipping",
                                 f"Der opstod en fejl under shipping:\n{traceback.format_exc()}")
        finally:
            self._set_buttons_enabled(True)

    def _set_buttons_enabled(self, enabled: bool):
        self.setEnabled(enabled)

    def choose_export_dir(self):
        current = self.settings.value("export_dir", "")
        dir_path = QFileDialog.getExistingDirectory(self, "Vælg exportmappe", current)
        if dir_path:
            self.settings.setValue("export_dir", dir_path)
            print(f"Exportmappe sat til: {dir_path}")

    def log_to_bugtracker(self, msg: str):
        timestamp = time.strftime("%H:%M:%S")
        self.bug_tracker.appendPlainText(f"[{timestamp}] {msg}")

    def closeEvent(self, event):
        if hasattr(self, "optical_simulator_panel"):
            self.optical_simulator_panel.shutdown()
        sys.stdout = self.original_stdout
        super().closeEvent(event)

    def show_about(self):
        QMessageBox.about(self, "Om Refract Studio",
                          "Refract Studio 2026 — ChromaPlex\n\n"
                          "100% cross‑platform, modular, secure.\n"
                          "Backend logic: npp_chromabridge compliant.\n\n"
                          "🔒 End-to-end kryptering af metadata\n"
                          "📍 Integration med Chromaplex‑krystal\n"
                          "📦 Generering af smart contracts\n\n"
                          "© 2024 Chromaplex")
