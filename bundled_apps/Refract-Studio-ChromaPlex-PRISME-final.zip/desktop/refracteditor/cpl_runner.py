"""Command-line entry point for the bundled CPL/CPA compilers and VMs."""

from __future__ import annotations

from pathlib import Path
import argparse

from cpl_adapter import run_cpa, run_cpl


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("--language", choices=("CPL", "CPA"), default="CPL")
    args = parser.parse_args()

    try:
        source = Path(args.source).read_text(encoding="utf-8")
        result = run_cpl(source) if args.language == "CPL" else run_cpa(source)
        print(f"Compiler/VM: {result.dialect}")
        print("\n── Genereret CPA ──")
        print(result.cpa)
        print("\n── Program-output ──")
        if result.output:
            for value in result.output:
                print(value)
        else:
            print("(intet OUT/PRINT-output)")
        print("\n── VM-status ──")
        print(result.state)
        return 0
    except Exception as exc:
        print(f"{args.language}-fejl: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
