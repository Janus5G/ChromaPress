"""
Code editor with high‑DPI line numbers and multiline comment highlighter.
"""
from PyQt6.QtWidgets import QPlainTextEdit, QTextEdit, QWidget
from PyQt6.QtGui import (
    QFont, QFontDatabase, QColor, QTextCharFormat, QSyntaxHighlighter,
    QPainter, QTextFormat
)
from PyQt6.QtCore import Qt, QRect, QSize
import re


class LineNumberArea(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.line_number_area_width(), 0)

    def paintEvent(self, event):
        self.editor.line_number_area_paint_event(event)


class CodeEditor(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.line_number_area = LineNumberArea(self)

        self.blockCountChanged.connect(self.update_line_number_area_width)
        self.updateRequest.connect(self.update_line_number_area)
        self.cursorPositionChanged.connect(self.highlight_current_line)

        self.update_line_number_area_width(0)
        self.highlight_current_line()

        # System monospace font
        sys_font = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        sys_font.setPointSize(11)
        self.setFont(sys_font)

        self.setStyleSheet("""
            QPlainTextEdit {
                background-color: #F8FAFD;
                color: #2563EB;
                border: none;
            }
        """)
        self.setTabStopDistance(40)

    def line_number_area_width(self):
        digits = len(str(max(1, self.blockCount())))
        space = 3 + self.fontMetrics().horizontalAdvance('9') * digits
        return space

    def update_line_number_area_width(self, _):
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def update_line_number_area(self, rect, dy):
        if dy:
            self.line_number_area.scroll(0, dy)
        else:
            self.line_number_area.update(0, rect.y(), self.line_number_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self.update_line_number_area_width(0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.line_number_area.setGeometry(QRect(cr.left(), cr.top(),
                                                self.line_number_area_width(), cr.height()))

    def highlight_current_line(self):
        extra_selections = []
        if not self.isReadOnly():
            selection = QTextEdit.ExtraSelection()
            line_color = QColor("#FFFFFF")
            selection.format.setBackground(line_color)
            selection.format.setProperty(QTextFormat.Property.FullWidthSelection, True)
            selection.cursor = self.textCursor()
            selection.cursor.clearSelection()
            extra_selections.append(selection)
        self.setExtraSelections(extra_selections)

    def line_number_area_paint_event(self, event):
        painter = QPainter(self.line_number_area)
        painter.fillRect(event.rect(), QColor("#FFFFFF"))

        block = self.firstVisibleBlock()
        block_number = block.blockNumber()
        top = self.blockBoundingGeometry(block).translated(self.contentOffset()).top()
        bottom = top + self.blockBoundingRect(block).height()
        font = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        font.setPointSize(9)

        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(block_number + 1)
                painter.setPen(QColor("#64748B"))
                painter.setFont(font)
                painter.drawText(0, int(top), self.line_number_area.width() - 3,
                                 self.fontMetrics().height(),
                                 Qt.AlignmentFlag.AlignRight, number)
            block = block.next()
            top = bottom
            bottom = top + self.blockBoundingRect(block).height()
            block_number += 1


class CPLHighlighter(QSyntaxHighlighter):
    """
    Syntax highlighter with multiline comment support (/* ... */) and escaped string quotes.
    """
    KEYWORDS = [
        "int", "float", "double", "char", "void", "if", "else", "while", "for",
        "return", "struct", "typedef", "sizeof", "switch", "case", "break", "continue",
        "func", "var", "let", "const", "print", "input", "loop"
    ]

    def __init__(self, parent):
        super().__init__(parent)
        self._formats = {}

        fmt = QTextCharFormat()
        fmt.setForeground(QColor("#7C3AED"))
        fmt.setFontWeight(700)
        self._formats["keyword"] = fmt

        fmt = QTextCharFormat()
        fmt.setForeground(QColor("#B45309"))
        self._formats["string"] = fmt

        fmt = QTextCharFormat()
        fmt.setForeground(QColor("#64748B"))
        self._formats["comment"] = fmt

        fmt = QTextCharFormat()
        fmt.setForeground(QColor("#0369A1"))
        self._formats["number"] = fmt

        self._rules = []
        for kw in self.KEYWORDS:
            self._rules.append((re.compile(r'\b' + kw + r'\b'), self._formats["keyword"]))
        # Streng med støtte for escaped quotes
        self._rules.append((re.compile(r'"(?:[^"\\]|\\.)*"'), self._formats["string"]))
        self._rules.append((re.compile(r"//[^\n]*"), self._formats["comment"]))
        self._rules.append((re.compile(r'\b\d+\.?\d*\b'), self._formats["number"]))

    def highlightBlock(self, text):
        # Enkeltlinje-regler
        for pattern, fmt in self._rules:
            for match in pattern.finditer(text):
                start, end = match.span()
                self.setFormat(start, end - start, fmt)

        # Multiline-kommentarer /* ... */
        self.highlight_multiline_comment(text)

    def highlight_multiline_comment(self, text):
        prev_state = self.previousBlockState()
        start_idx = 0
        if prev_state <= 0:  # Ikke inde i en kommentar
            start_match = re.search(r'/\*', text)
            if start_match:
                start_idx = start_match.start()
                end_match = re.search(r'\*/', text[start_idx+2:])
                if end_match:
                    end_idx = start_idx + 2 + end_match.end()
                    self.setFormat(start_idx, end_idx - start_idx, self._formats["comment"])
                    self.setCurrentBlockState(0)
                else:
                    self.setFormat(start_idx, len(text) - start_idx, self._formats["comment"])
                    self.setCurrentBlockState(1)
            else:
                self.setCurrentBlockState(0)
        else:  # Inde i en kommentar
            end_match = re.search(r'\*/', text)
            if end_match:
                end_idx = end_match.end()
                self.setFormat(0, end_idx, self._formats["comment"])
                self.setCurrentBlockState(0)
            else:
                self.setFormat(0, len(text), self._formats["comment"])
                self.setCurrentBlockState(1)
