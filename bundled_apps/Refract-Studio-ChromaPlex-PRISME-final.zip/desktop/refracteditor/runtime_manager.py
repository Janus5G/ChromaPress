"""Runtime status and controlled installation entry points."""

from __future__ import annotations

import importlib.util
import shutil
import sys

from PyQt6.QtCore import QProcess, QUrl
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import (
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)


class InstallProcessDialog(QDialog):
    def __init__(self, title: str, program: str, arguments: list[str], parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(850, 560)
        layout = QVBoxLayout(self)
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)
        close = QPushButton("Luk")
        close.clicked.connect(self.close)
        layout.addWidget(close)
        self.process = QProcess(self)
        self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self.process.readyRead.connect(self._read)
        self.process.finished.connect(
            lambda code, _status: self.output.appendPlainText(
                f"\nInstallation afsluttet med kode {code}."
            )
        )
        self.process.start(program, arguments)

    def _read(self):
        text = bytes(self.process.readAll()).decode("utf-8", errors="replace")
        self.output.insertPlainText(text)


class RuntimeManagerDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Runtimes og installation — Refract Studio")
        self.resize(860, 680)
        self.install_windows = set()

        outer = QVBoxLayout(self)
        intro = QLabel(
            "CPL/CPA-compiler og PRISME følger med programmet. Eksterne sprog "
            "bruger deres officielle lokale toolchain."
        )
        intro.setWordWrap(True)
        outer.addWidget(intro)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        body = QWidget()
        grid = QGridLayout(body)
        grid.addWidget(QLabel("<b>Komponent</b>"), 0, 0)
        grid.addWidget(QLabel("<b>Status</b>"), 0, 1)
        grid.addWidget(QLabel("<b>Handling</b>"), 0, 2)

        rows = [
            ("CPL/CPA compiler + VM", True, None, None),
            ("PRISME 256-byte assembler + VM", True, None, None),
            (
                "Optical Routing Simulator",
                all(importlib.util.find_spec(name) for name in ("fastapi", "numpy", "pydantic", "uvicorn")),
                "pip",
                None,
            ),
            ("C/C++ compiler", bool(shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")), "url", "https://visualstudio.microsoft.com/visual-cpp-build-tools/"),
            ("Node.js / JavaScript", bool(shutil.which("node")), "url", "https://nodejs.org/en/download"),
            ("TypeScript (tsx)", bool(shutil.which("tsx") or shutil.which("ts-node")), "npm", None),
            ("Rust", bool(shutil.which("rustc")), "url", "https://rustup.rs/"),
            ("Go", bool(shutil.which("go")), "url", "https://go.dev/dl/"),
            ("Java JDK", bool(shutil.which("javac") and shutil.which("java")), "url", "https://adoptium.net/"),
            ("PowerShell", bool(shutil.which("pwsh") or shutil.which("powershell")), "url", "https://learn.microsoft.com/powershell/scripting/install/installing-powershell"),
        ]
        for row, (name, available, action, target) in enumerate(rows, 1):
            grid.addWidget(QLabel(name), row, 0)
            status = QLabel("Installeret" if available else "Mangler")
            status.setStyleSheet(
                "color:#15803D;font-weight:700;" if available
                else "color:#B45309;font-weight:700;"
            )
            grid.addWidget(status, row, 1)
            button = QPushButton(
                "Medfølger" if available and action is None
                else "Installeret" if available
                else "Installér pakker" if action in {"pip", "npm"}
                else "Åbn officiel installation"
            )
            button.setEnabled(not available)
            if action == "pip":
                button.clicked.connect(self._install_simulator)
            elif action == "npm":
                button.clicked.connect(self._install_typescript)
            elif action == "url":
                button.clicked.connect(
                    lambda _checked=False, url=target:
                    QDesktopServices.openUrl(QUrl(url))
                )
            grid.addWidget(button, row, 2)
        grid.setColumnStretch(0, 1)
        scroll.setWidget(body)
        outer.addWidget(scroll)

        bottom = QHBoxLayout()
        bottom.addStretch()
        close = QPushButton("Luk")
        close.clicked.connect(self.accept)
        bottom.addWidget(close)
        outer.addLayout(bottom)

    def _track(self, window):
        self.install_windows.add(window)
        window.destroyed.connect(
            lambda _object=None, item=window: self.install_windows.discard(item)
        )
        window.show()

    def _install_simulator(self):
        self._track(
            InstallProcessDialog(
                "Installér Optical Routing Simulator-pakker",
                sys.executable,
                [
                    "-m", "pip", "install",
                    "fastapi>=0.115,<1", "numpy>=2,<3",
                    "pydantic>=2.10,<3", "uvicorn[standard]>=0.34,<1",
                ],
                self,
            )
        )

    def _install_typescript(self):
        npm = shutil.which("npm")
        if npm:
            self._track(
                InstallProcessDialog(
                    "Installér TypeScript runtime",
                    npm,
                    ["install", "-g", "tsx"],
                    self,
                )
            )
