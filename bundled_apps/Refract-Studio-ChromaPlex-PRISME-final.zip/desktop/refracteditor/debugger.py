"""
State‑safe debugger with real hash calculation.
"""
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
from PyQt6.QtCore import Qt
import hashlib


class DebuggerPanel(QWidget):
    def __init__(self, log_to_bugtracker_callback, parent=None):
        super().__init__(parent)
        self.log_bug = log_to_bugtracker_callback
        self.debug_steps = []
        self.debug_step_index = 0
        self.debug_vars = {
            "value": 1234567, "base": 0, "exp": 0, "rest": 0,
            "address": "", "hash": ""
        }

        layout = QVBoxLayout(self)
        self.var_label = QLabel()
        self.var_label.setStyleSheet("color: #2563EB; font-family: monospace; background-color: #F5F7FB;")
        self.var_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.var_label)

        btn_layout = QHBoxLayout()
        step_btn = QPushButton("Step")
        reset_btn = QPushButton("Reset")
        for btn in (step_btn, reset_btn):
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #FFFFFF; color: #2563EB;
                    border: 1px solid #D8E0EC; padding: 4px 12px;
                }
                QPushButton:hover {
                    background-color: #2563EB; color: #FFFFFF;
                }
            """)
        step_btn.clicked.connect(self.debug_step)
        reset_btn.clicked.connect(self.debug_reset)
        btn_layout.addWidget(step_btn)
        btn_layout.addWidget(reset_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

    def start_debug(self):
        self.debug_steps = [
            ("base = 3", {}),
            ("exp = 12", {}),
            ("rest = 703126", {}),
            ("Generer source_address", {}),
            ("Beregn extraction_hash", {})
        ]
        self.debug_step_index = 0
        self.debug_vars = {
            "value": 1234567, "base": 0, "exp": 0, "rest": 0,
            "address": "", "hash": ""
        }
        self._update_display()
        print("Debug startet. Tryk 'Step'.")

    def debug_step(self):
        if not hasattr(self, 'debug_steps') or not self.debug_steps:
            self.log_bug("Debugger: Ingen aktive trin. Start debug først.")
            return
        if self.debug_step_index >= len(self.debug_steps):
            self.log_bug("Debugger: Alle trin gennemført.")
            return

        desc, _ = self.debug_steps[self.debug_step_index]
        if self.debug_step_index == 0:
            self.debug_vars["base"] = 3
        elif self.debug_step_index == 1:
            self.debug_vars["exp"] = 12
        elif self.debug_step_index == 2:
            self.debug_vars["rest"] = 703126
        elif self.debug_step_index == 3:
            # Simuleret adresse (samme som backend)
            self.debug_vars["address"] = "C0:F1:rød:D1"
        elif self.debug_step_index == 4:
            # Beregn ægte SHA-256 hash som backend gør
            hash_string = f"{self.debug_vars['address']}:{self.debug_vars['value']}:{self.debug_vars['base']}:{self.debug_vars['exp']}:{self.debug_vars['rest']}"
            full_hash = hashlib.sha256(hash_string.encode('utf-8')).hexdigest()
            self.debug_vars["hash"] = full_hash[:16] + "..."  # vis kun starten
        self.debug_step_index += 1
        self._update_display()
        print(f"Step: {desc}")

    def debug_reset(self):
        self.debug_vars = {
            "value": 1234567, "base": 0, "exp": 0, "rest": 0,
            "address": "", "hash": ""
        }
        self.debug_step_index = 0
        self._update_display()
        print("Debug nulstillet.")

    def _update_display(self):
        text = "\n".join(f"{var:10} = {val}" for var, val in self.debug_vars.items())
        self.var_label.setText(text)