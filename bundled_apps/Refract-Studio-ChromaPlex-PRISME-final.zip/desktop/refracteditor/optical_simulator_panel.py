"""Embedded Optical Routing Simulator, colour stream, and source viewer."""

from __future__ import annotations

from html import escape
import importlib.util
import os
from pathlib import Path
import socket
import sys

from PyQt6.QtCore import (
    QProcess,
    QProcessEnvironment,
    QTimer,
    QUrl,
    pyqtSignal,
)
from PyQt6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)
from PyQt6.QtWebEngineCore import QWebEngineSettings
from PyQt6.QtWebEngineWidgets import QWebEngineView

from .cpl_adapter import compile_cpl
from .prisme_isa import assemble as assemble_prisme, byte_to_levels


DESKTOP_ROOT = Path(__file__).resolve().parent.parent
SIMULATOR_ROOT = DESKTOP_ROOT / "vendor" / "optical-routing-simulator"
SIMULATOR_SOURCE = SIMULATOR_ROOT / "src"


class OpticalSimulatorPanel(QWidget):
    close_requested = pyqtSignal()

    def __init__(self, source_provider, parent=None):
        super().__init__(parent)
        self.source_provider = source_provider
        self.server = QProcess(self)
        self.server.readyReadStandardError.connect(self._server_message)
        self.server.finished.connect(self._server_finished)
        self._port = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)

        bar = QHBoxLayout()
        title = QLabel("Optical Routing Simulator")
        title.setStyleSheet("font-weight: 800; color: #172033;")
        self.status = QLabel("Farvekode klar")
        self.status.setStyleSheet("color: #64748B;")
        refresh = QPushButton("⟳ Opdater")
        refresh.clicked.connect(self.refresh_colour_code)
        restart = QPushButton("Genstart fysiksimulator")
        restart.clicked.connect(self.restart_server)
        close = QPushButton("Luk panel")
        close.clicked.connect(self.close_panel)
        bar.addWidget(title)
        bar.addWidget(self.status)
        bar.addStretch()
        bar.addWidget(refresh)
        bar.addWidget(restart)
        bar.addWidget(close)
        layout.addLayout(bar)

        self.views = QTabWidget()
        layout.addWidget(self.views)

        self.colour_view = QWebEngineView()
        self.colour_view.settings().setAttribute(
            QWebEngineSettings.WebAttribute.JavascriptEnabled, False
        )
        self.views.addTab(self.colour_view, "Farvekode")

        self.physics_view = QWebEngineView()
        self.views.addTab(self.physics_view, "Fysiksimulator")

        source_widget = QWidget()
        source_layout = QVBoxLayout(source_widget)
        self.source_choice = QComboBox()
        self.source_editor = QPlainTextEdit()
        self.source_editor.setReadOnly(True)
        source_layout.addWidget(self.source_choice)
        source_layout.addWidget(self.source_editor)
        self.views.addTab(source_widget, "Simulatorens kode")

        self.source_files = sorted(
            path for path in SIMULATOR_ROOT.rglob("*")
            if path.is_file() and path.suffix.lower() in {".py", ".html", ".toml", ".md"}
        )
        for path in self.source_files:
            self.source_choice.addItem(str(path.relative_to(SIMULATOR_ROOT)), path)
        self.source_choice.currentIndexChanged.connect(self._show_source_file)
        self._show_source_file()

        self.refresh_timer = QTimer(self)
        self.refresh_timer.setSingleShot(True)
        self.refresh_timer.setInterval(300)
        self.refresh_timer.timeout.connect(self.refresh_colour_code)

        self.setStyleSheet(
            """
            QPushButton {
                background: #FFFFFF; color: #2563EB;
                border: 1px solid #D8E0EC; border-radius: 6px;
                padding: 6px 10px; font-weight: 700;
            }
            QPushButton:hover { background: #2563EB; color: white; }
            """
        )
        self.refresh_colour_code()
        self.start_server()

    def schedule_refresh(self):
        self.refresh_timer.start()

    def _program_bytes(self, source: str, language: str) -> tuple[bytes, str]:
        if language == "CPL":
            cpa, dialect = compile_cpl(source)
            return cpa.encode("utf-8"), f"{dialect} → CPA → PRISME"
        if language == "PRISME ASM":
            return assemble_prisme(source), "PRISME ASM → 256-byte alfabet"
        return source.encode("utf-8"), f"{language} UTF-8 → PRISME"

    def refresh_colour_code(self):
        source, language = self.source_provider()
        try:
            data, route = self._program_bytes(source, language)
            shown = data[:256]
            cards = []
            colours = ("#EF4444", "#22C55E", "#3B82F6", "#8B5CF6", "#A855F7")
            names = ("R", "G", "B", "V", "UV")
            for offset, value in enumerate(shown):
                levels = byte_to_levels(value)
                channels = "".join(
                    f'<span class="channel"><i style="background:{colour};'
                    f'opacity:{0.18 + level * 0.27:.2f};height:{10 + level * 7}px"></i>'
                    f'<small>{name}{level}</small></span>'
                    for name, colour, level in zip(names, colours, levels)
                )
                printable = chr(value) if 32 <= value < 127 else "·"
                cards.append(
                    f'<div class="byte"><b>{offset:03d}</b><em>0x{value:02X} {escape(printable)}</em>'
                    f'<div class="channels">{channels}</div></div>'
                )
            note = (
                f"Viser de første {len(shown)} af {len(data)} bytes."
                if len(data) > len(shown) else f"Viser {len(data)} bytes."
            )
            html = f"""
            <html><head><style>
            body {{ margin:0; padding:16px; background:#F8FAFD; color:#172033;
                    font-family:system-ui,sans-serif; }}
            header {{ display:flex; justify-content:space-between; margin-bottom:12px; }}
            header b {{ color:#2563EB; }} header span {{ color:#64748B; }}
            main {{ display:grid; grid-template-columns:repeat(auto-fill,minmax(168px,1fr)); gap:8px; }}
            .byte {{ background:white; border:1px solid #D8E0EC; border-radius:8px; padding:8px; }}
            .byte>b {{ font:11px monospace; color:#64748B; }} .byte>em {{ float:right;
                    font:11px monospace; color:#2563EB; font-style:normal; }}
            .channels {{ display:flex; align-items:end; gap:5px; height:42px; margin-top:7px; }}
            .channel {{ flex:1; text-align:center; }} .channel i {{ display:block; border-radius:4px; }}
            .channel small {{ font:8px monospace; color:#64748B; }}
            </style></head><body><header><b>{escape(route)}</b><span>{note}</span></header>
            <main>{''.join(cards)}</main></body></html>
            """
            self.colour_view.setHtml(html)
            self.status.setText(f"{len(data)} bytes farvekodet")
        except Exception as exc:
            self.colour_view.setHtml(
                f"<body style='font-family:monospace;padding:20px;color:#B91C1C'>"
                f"<h3>Kompileringsfejl</h3><pre>{escape(str(exc))}</pre></body>"
            )
            self.status.setText("Farvekode kunne ikke opdateres")

    def _show_source_file(self):
        path = self.source_choice.currentData()
        if path:
            try:
                self.source_editor.setPlainText(
                    Path(path).read_text(encoding="utf-8")
                )
            except Exception as exc:
                self.source_editor.setPlainText(str(exc))

    @staticmethod
    def _free_port() -> int:
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            return sock.getsockname()[1]

    def start_server(self):
        if self.server.state() != QProcess.ProcessState.NotRunning:
            return
        missing = [
            name for name in ("fastapi", "numpy", "pydantic", "uvicorn")
            if importlib.util.find_spec(name) is None
        ]
        if missing:
            self.physics_view.setHtml(
                "<body style='font-family:system-ui;padding:24px'>"
                "<h2>Fysiksimulatorens pakker mangler</h2>"
                "<p>Åbn <b>Indstillinger → Runtimes og installation</b> "
                f"for at installere: {escape(', '.join(missing))}.</p></body>"
            )
            self.status.setText("Simulatorpakker mangler")
            return
        self._port = self._free_port()
        environment = QProcessEnvironment.systemEnvironment()
        existing = environment.value("PYTHONPATH")
        python_path = str(SIMULATOR_SOURCE)
        if existing:
            python_path += os.pathsep + existing
        environment.insert("PYTHONPATH", python_path)
        self.server.setProcessEnvironment(environment)
        self.server.start(
            sys.executable,
            [
                "-m", "uvicorn", "optical_router.api:app",
                "--host", "127.0.0.1", "--port", str(self._port),
                "--log-level", "warning",
            ],
        )
        self.status.setText("Starter lokal fysiksimulator…")
        QTimer.singleShot(1200, self._load_dashboard)

    def _load_dashboard(self):
        if self._port is not None:
            self.physics_view.load(QUrl(f"http://127.0.0.1:{self._port}/"))
            self.status.setText("Lokal fysiksimulator klar")

    def _server_message(self):
        message = bytes(self.server.readAllStandardError()).decode(
            "utf-8", errors="replace"
        ).strip()
        if message:
            self.status.setToolTip(message)

    def _server_finished(self, _code, _status):
        if self.isVisible():
            self.status.setText("Fysiksimulator stoppet")

    def restart_server(self):
        self.stop_server()
        self.start_server()

    def stop_server(self):
        if self.server.state() != QProcess.ProcessState.NotRunning:
            self.server.terminate()
            if not self.server.waitForFinished(1000):
                self.server.kill()

    def close_panel(self):
        self.stop_server()
        self.close_requested.emit()

    def shutdown(self):
        self.stop_server()
