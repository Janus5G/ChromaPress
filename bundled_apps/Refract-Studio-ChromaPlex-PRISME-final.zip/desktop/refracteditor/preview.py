"""
Live preview pane with a sandboxed QWebEngineView and full-screen presentation.
"""

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QKeyEvent, QKeySequence, QShortcut
from PyQt6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)
from PyQt6.QtWebEngineCore import QWebEngineSettings
from PyQt6.QtWebEngineWidgets import QWebEngineView


class FullScreenPreview(QDialog):
    """Independent full-screen copy of the current preview."""

    def __init__(self, html: str, javascript_enabled: bool, parent=None):
        super().__init__(parent, Qt.WindowType.Window)
        self.setWindowTitle("Preview — Refract Studio")
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        bar = QWidget()
        bar.setObjectName("previewFullScreenBar")
        bar_layout = QHBoxLayout(bar)
        bar_layout.setContentsMargins(12, 8, 12, 8)
        bar_layout.addWidget(QLabel("Preview i fuld skærm"))
        bar_layout.addStretch()

        exit_button = QPushButton("Luk fuld skærm  Esc")
        exit_button.clicked.connect(self.close)
        bar_layout.addWidget(exit_button)
        layout.addWidget(bar)

        self.webview = QWebEngineView()
        self.webview.settings().setAttribute(
            QWebEngineSettings.WebAttribute.JavascriptEnabled,
            javascript_enabled,
        )
        self.webview.setHtml(html)
        layout.addWidget(self.webview)

        self.setStyleSheet(
            """
            QWidget#previewFullScreenBar {
                background: #FFFFFF;
                border-bottom: 1px solid #D8E0EC;
            }
            QLabel { color: #172033; font-weight: 700; }
            QPushButton {
                background: #2563EB; color: white;
                border: 0; border-radius: 6px; padding: 7px 12px;
                font-weight: 700;
            }
            QPushButton:hover { background: #1D4ED8; }
            """
        )
        self.escape_shortcut = QShortcut(QKeySequence("Esc"), self)
        self.escape_shortcut.activated.connect(self.close)
        self.fullscreen_shortcut = QShortcut(QKeySequence("F11"), self)
        self.fullscreen_shortcut.activated.connect(self.close)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() in (Qt.Key.Key_Escape, Qt.Key.Key_F11):
            self.close()
            return
        super().keyPressEvent(event)


class PreviewPane(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        controls = QWidget()
        controls_layout = QHBoxLayout(controls)
        controls_layout.setContentsMargins(8, 6, 8, 6)

        self.refresh_btn = QPushButton("⟳ Opdater preview")
        self.run_btn = QPushButton("▶ Kør i eget vindue")
        self.fullscreen_btn = QPushButton("⛶ Fuld skærm")
        for button in (self.refresh_btn, self.run_btn, self.fullscreen_btn):
            button.setStyleSheet(
                """
                QPushButton {
                    background-color: #FFFFFF; color: #2563EB;
                    border: 1px solid #D8E0EC; border-radius: 6px;
                    padding: 6px 10px; font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #2563EB; color: #FFFFFF;
                }
                """
            )
            controls_layout.addWidget(button)
        controls_layout.addStretch()
        layout.addWidget(controls)

        self.webview = QWebEngineView()
        self.webview.settings().setAttribute(
            QWebEngineSettings.WebAttribute.JavascriptEnabled, False
        )
        self.webview.setStyleSheet("background-color: #F8FAFD;")
        layout.addWidget(self.webview)

        self._html = ""
        self._javascript_enabled = False
        self._fullscreen_window = None
        self.fullscreen_btn.clicked.connect(self.show_fullscreen)

    def set_javascript_enabled(self, enabled: bool):
        self._javascript_enabled = enabled
        self.webview.settings().setAttribute(
            QWebEngineSettings.WebAttribute.JavascriptEnabled, enabled
        )

    def load_html(self, html: str):
        self._html = html
        self.webview.setHtml(html)

    def show_fullscreen(self):
        if self._fullscreen_window is not None:
            self._fullscreen_window.raise_()
            self._fullscreen_window.activateWindow()
            return
        self._fullscreen_window = FullScreenPreview(
            self._html,
            self._javascript_enabled,
            self.window(),
        )
        self._fullscreen_window.destroyed.connect(self._fullscreen_closed)
        self._fullscreen_window.showFullScreen()

    def _fullscreen_closed(self):
        self._fullscreen_window = None
