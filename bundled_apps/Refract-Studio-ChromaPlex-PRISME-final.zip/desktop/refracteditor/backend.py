"""
ChromaplexBackend – legacy logic preserved, cross‑platform, no file locking.
"""
import os, sys, json, time, hashlib, struct, traceback
from pathlib import Path
from PyQt6.QtCore import QStandardPaths
from .optical_bridge import export_optical, import_optical

COLOURS = ["rød", "grøn", "blå", "violet", "uv"]
FIXED_VALUE = 1234567
FIXED_REPRESENTATION = "3^12 + 703126"
FIXED_BASE = 3
FIXED_EXP = 12
FIXED_REST = 703126

def _get_registry_path():
    app_data = Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation))
    app_data.mkdir(parents=True, exist_ok=True)
    return app_data / "chromabridge_used_addresses.json"


class ChromaplexBackend:
    @staticmethod
    def load_address_registry():
        path = _get_registry_path()
        if not path.exists():
            return set()
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return set(data.get("used_addresses", []))
        except Exception:
            traceback.print_exc()
            return set()

    @staticmethod
    def save_address_registry(used_addresses):
        path = _get_registry_path()
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump({"used_addresses": list(used_addresses)}, f, indent=2, ensure_ascii=False)
        except Exception:
            traceback.print_exc()

    @staticmethod
    def generate_unique_source_address(used_addresses):
        counter = len(used_addresses)
        for _ in range(1000):
            facet = (counter % 57) + 1
            colour = COLOURS[counter % len(COLOURS)]
            depth = counter + 1
            address = f"C0:F{facet}:{colour}:D{depth}"
            counter += 1
            if address not in used_addresses:
                return address
        raise RuntimeError("Address space exhausted.")

    @staticmethod
    def compile_payload(code: str, filename: str, source_address: str = None):
        language = ChromaplexBackend.detect_language(filename)
        code_len = len(code)

        value = FIXED_VALUE
        representation = FIXED_REPRESENTATION
        base = FIXED_BASE
        exp = FIXED_EXP
        rest = FIXED_REST

        if source_address is None:
            used_addresses = ChromaplexBackend.load_address_registry()
            source_address = ChromaplexBackend.generate_unique_source_address(used_addresses)
            used_addresses.add(source_address)
            ChromaplexBackend.save_address_registry(used_addresses)
        else:
            used_addresses = ChromaplexBackend.load_address_registry()
            used_addresses.add(source_address)
            ChromaplexBackend.save_address_registry(used_addresses)

        hash_string = f"{source_address}:{value}:{base}:{exp}:{rest}"
        extraction_hash = hashlib.sha256(hash_string.encode('utf-8')).hexdigest()

        # RETTET: Afrund til 2 decimaler
        timestamp = round(time.time(), 2)

        payload_id = hashlib.md5(f"{filename}{timestamp}".encode()).hexdigest()[:16]
        ledger_proof = [
            hashlib.sha256(f"{hash_string}:1".encode('utf-8')).hexdigest(),
            hashlib.sha256(f"{hash_string}:2".encode('utf-8')).hexdigest()
        ]

        return {
            "payload_id": payload_id,
            "value": value,
            "representation": representation,
            "source_address": source_address,
            "base": base,
            "exponent": exp,
            "rest": rest,
            "extraction_hash": extraction_hash,
            "ledger_proof": ledger_proof,
            "timestamp": timestamp,
            "metadata": {
                "original_language": language,
                "original_filename": filename,
                "code_length": code_len,
                "code": code
            }
        }, source_address, hash_string

    @staticmethod
    def detect_language(filename: str) -> str:
        ext = os.path.splitext(filename)[1].lower()
        ext_map = {
            ".html": "HTML", ".htm": "HTML", ".css": "CSS", ".js": "JavaScript",
            ".ts": "TypeScript", ".py": "Python", ".c": "C", ".cpp": "C++",
            ".java": "Java", ".go": "Go", ".rs": "Rust", ".rb": "Ruby",
            ".php": "PHP", ".pl": "Perl", ".sh": "Shell/Bash", ".ps1": "PowerShell",
            ".bat": "Batch", ".sql": "SQL", ".lua": "Lua", ".r": "R",
            ".mo": "Motoko", ".cpl": "CPL", ".cpa": "CPA",
            ".prisme": "PRISME ASM", ".asm4": "Spectral IR",
        }
        return ext_map.get(ext, "Ukendt sprog")

    @staticmethod
    def decompile_json_full(filepath: str):
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        meta = data.get("metadata", {})
        code = meta.get("code") or meta.get("code_preview", "// No code found.")
        lang = meta.get("original_language", "Ukendt sprog")
        return code, lang

    @staticmethod
    def decompile_bin(filepath: str) -> str:
        with open(filepath, "rb") as f:
            magic = f.read(4)
            if magic == b'CPX2':
                meta_len = struct.unpack(">I", f.read(4))[0]
                meta_bytes = f.read(meta_len)
                metadata = json.loads(meta_bytes.decode("utf-8"))
                code_bytes = f.read()
                try:
                    return code_bytes.decode("utf-8")
                except UnicodeDecodeError:
                    return code_bytes.decode("latin-1")
            if magic == b'OPTB':
                f.seek(0)
                code, _language, _stream = import_optical(f.read(), "PRISME ASM")
                return code
            raise ValueError("Unsupported binary header (expected CPX2 or OPTB)")

    @staticmethod
    def import_optical_binary(filepath: str, view: str = "PRISME ASM"):
        with open(filepath, "rb") as f:
            return import_optical(f.read(), view)

    @staticmethod
    def export_optical_binary(filepath: str, code: str, language: str):
        content = export_optical(code, language)
        with open(filepath, "wb") as f:
            f.write(content)
        return len(content)

    @staticmethod
    def detect_file_type(filepath: str) -> str:
        with open(filepath, 'rb') as f:
            magic = f.read(4)
        if magic == b'CPX2':
            return 'cpx2'
        if magic == b'OPTB':
            return 'optb'
        return 'text'
