"""Run source code in an isolated output window without changing editor files."""

from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile

from PyQt6.QtCore import QProcess, QTimer, Qt
from PyQt6.QtGui import QCloseEvent, QFontDatabase, QTextCursor
from PyQt6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
)


@dataclass(frozen=True)
class Command:
    program: str
    arguments: list[str]


@dataclass(frozen=True)
class RunPlan:
    source_path: Path
    run: Command
    compile: Command | None = None


class UnsupportedRuntime(RuntimeError):
    pass


def _executable(*names: str) -> str | None:
    for name in names:
        if path := shutil.which(name):
            return path
    return None


def _require(description: str, *names: str) -> str:
    if path := _executable(*names):
        return path
    raise UnsupportedRuntime(
        f"{description} er ikke installeret eller findes ikke i PATH.\n"
        f"Forventet kommando: {', '.join(names)}"
    )


def create_run_plan(source: str, language: str, directory: Path) -> RunPlan:
    """Create a shell-free compile/run plan for the selected language."""

    normalized = language.strip().lower()
    extension = ".txt"
    compile_command = None

    if normalized == "python":
        extension = ".py"
        run_command = Command(sys.executable, [])
    elif normalized == "javascript":
        extension = ".js"
        run_command = Command(_require("Node.js", "node"), [])
    elif normalized == "typescript":
        extension = ".ts"
        run_command = Command(_require("TypeScript-runtime", "tsx", "ts-node"), [])
    elif normalized in {"shell/bash", "shell", "bash"}:
        extension = ".sh"
        run_command = Command(_require("Bash", "bash"), [])
    elif normalized == "powershell":
        extension = ".ps1"
        run_command = Command(_require("PowerShell", "pwsh", "powershell"), ["-File"])
    elif normalized == "ruby":
        extension = ".rb"
        run_command = Command(_require("Ruby", "ruby"), [])
    elif normalized == "php":
        extension = ".php"
        run_command = Command(_require("PHP", "php"), [])
    elif normalized == "perl":
        extension = ".pl"
        run_command = Command(_require("Perl", "perl"), [])
    elif normalized == "lua":
        extension = ".lua"
        run_command = Command(_require("Lua", "lua"), [])
    elif normalized == "r":
        extension = ".r"
        run_command = Command(_require("Rscript", "Rscript"), [])
    elif normalized == "go":
        extension = ".go"
        run_command = Command(_require("Go", "go"), ["run"])
    elif normalized == "c":
        extension = ".c"
        output = directory / ("program.exe" if os.name == "nt" else "program")
        compiler = _require("C-compiler", "cc", "gcc", "clang")
        compile_command = Command(compiler, [])
        run_command = Command(str(output), [])
    elif normalized == "c++":
        extension = ".cpp"
        output = directory / ("program.exe" if os.name == "nt" else "program")
        compiler = _require("C++-compiler", "c++", "g++", "clang++")
        compile_command = Command(compiler, [])
        run_command = Command(str(output), [])
    elif normalized == "rust":
        extension = ".rs"
        output = directory / ("program.exe" if os.name == "nt" else "program")
        compiler = _require("Rust-compiler", "rustc")
        compile_command = Command(compiler, [])
        run_command = Command(str(output), [])
    elif normalized == "java":
        match = re.search(r"\bpublic\s+class\s+([A-Za-z_$][\w$]*)", source)
        class_name = match.group(1) if match else "Main"
        extension = ".java"
        source_path = directory / f"{class_name}{extension}"
        source_path.write_text(source, encoding="utf-8")
        compile_command = Command(_require("Java-compiler", "javac"), [str(source_path)])
        run_command = Command(
            _require("Java-runtime", "java"),
            ["-cp", str(directory), class_name],
        )
        return RunPlan(source_path, run_command, compile_command)
    elif normalized == "prisme asm":
        extension = ".prisme"
        runner = Path(__file__).with_name("prisme_runner.py")
        run_command = Command(sys.executable, [str(runner)])
    elif normalized in {"cpl", "cpa"}:
        extension = f".{normalized}"
        runner = Path(__file__).with_name("cpl_runner.py")
        run_command = Command(
            sys.executable,
            [str(runner), "--language", normalized.upper()],
        )
    elif normalized == "batch":
        if os.name != "nt":
            raise UnsupportedRuntime("Batch-filer kan kun køres direkte på Windows.")
        extension = ".bat"
        run_command = Command("cmd.exe", ["/C"])
    else:
        raise UnsupportedRuntime(
            f"{language} har ikke en lokal runtime i Refract Studio.\n"
            "Åbn Indstillinger → Runtimes og installation, eller vælg et "
            "understøttet sprog."
        )

    source_path = directory / f"refract_run{extension}"
    source_path.write_text(source, encoding="utf-8")

    if compile_command:
        output_path = Path(run_command.program)
        compile_args = [str(source_path), "-o", str(output_path)]
        if normalized == "rust":
            compile_args = [str(source_path), "-o", str(output_path)]
        compile_command = Command(compile_command.program, compile_args)

    run_arguments = [*run_command.arguments, str(source_path)]
    if normalized in {"c", "c++", "rust"}:
        run_arguments = run_command.arguments
    return RunPlan(
        source_path,
        Command(run_command.program, run_arguments),
        compile_command,
    )


class ExternalRunWindow(QDialog):
    """Compile/run output and process controls in a separate window."""

    def __init__(self, source: str, language: str, parent=None):
        super().__init__(parent, Qt.WindowType.Window)
        self.source = source
        self.language = language
        self.setWindowTitle(f"Kørsel — {language} — Refract Studio")
        self.resize(1050, 720)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

        layout = QVBoxLayout(self)
        header = QHBoxLayout()
        self.status_label = QLabel("Klar")
        self.status_label.setStyleSheet("font-weight: 700; color: #172033;")
        header.addWidget(self.status_label)
        header.addStretch()

        self.rerun_button = QPushButton("▶ Kør igen")
        self.stop_button = QPushButton("■ Stop")
        self.clear_button = QPushButton("Ryd output")
        self.close_button = QPushButton("Luk")
        for button in (
            self.rerun_button,
            self.stop_button,
            self.clear_button,
            self.close_button,
        ):
            header.addWidget(button)
        layout.addLayout(header)

        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.output.setFont(
            QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        )
        self.output.setStyleSheet(
            """
            QPlainTextEdit {
                background: #0F172A; color: #E2E8F0;
                border: 1px solid #CBD5E1; border-radius: 8px;
                padding: 10px;
            }
            """
        )
        layout.addWidget(self.output)

        input_row = QHBoxLayout()
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText(
            "Standard input til det kørende program…"
        )
        self.send_button = QPushButton("Send input")
        input_row.addWidget(self.input_field)
        input_row.addWidget(self.send_button)
        layout.addLayout(input_row)

        self.setStyleSheet(
            """
            QDialog { background: #F5F7FB; }
            QLineEdit {
                background: #FFFFFF; color: #172033;
                border: 1px solid #D8E0EC; border-radius: 6px;
                padding: 8px 10px;
            }
            QPushButton {
                background: #FFFFFF; color: #2563EB;
                border: 1px solid #D8E0EC; border-radius: 6px;
                padding: 7px 11px; font-weight: 700;
            }
            QPushButton:hover { background: #2563EB; color: #FFFFFF; }
            """
        )

        self.process = QProcess(self)
        self.process.setProcessChannelMode(
            QProcess.ProcessChannelMode.SeparateChannels
        )
        self.process.readyReadStandardOutput.connect(self._read_stdout)
        self.process.readyReadStandardError.connect(self._read_stderr)
        self.process.finished.connect(self._finished)
        self.process.errorOccurred.connect(self._process_error)

        self.rerun_button.clicked.connect(self.run)
        self.stop_button.clicked.connect(self.stop)
        self.clear_button.clicked.connect(self.output.clear)
        self.close_button.clicked.connect(self.close)
        self.send_button.clicked.connect(self.send_input)
        self.input_field.returnPressed.connect(self.send_input)

        self._temporary_directory = None
        self._plan = None
        self._phase = "idle"
        self.send_button.setEnabled(False)
        self.input_field.setEnabled(False)
        QTimer.singleShot(0, self.run)

    def _append(self, text: str):
        if text:
            self.output.moveCursor(QTextCursor.MoveOperation.End)
            self.output.insertPlainText(text)
            self.output.ensureCursorVisible()

    def run(self):
        if self.process.state() != QProcess.ProcessState.NotRunning:
            return
        if self._temporary_directory is not None:
            self._temporary_directory.cleanup()
        self._temporary_directory = tempfile.TemporaryDirectory(
            prefix="refract-studio-run-"
        )
        directory = Path(self._temporary_directory.name)
        self._append(f"\n── {self.language} · ny kørsel ──\n")
        try:
            self._plan = create_run_plan(self.source, self.language, directory)
        except Exception as exc:
            self.status_label.setText("Kan ikke køres")
            self._append(f"{exc}\n")
            self.stop_button.setEnabled(False)
            return

        self.process.setWorkingDirectory(str(directory))
        self.stop_button.setEnabled(True)
        if self._plan.compile:
            self._phase = "compile"
            self.status_label.setText("Kompilerer…")
            self._start(self._plan.compile)
        else:
            self._start_run_phase()

    def _start(self, command: Command):
        self._append(f"$ {Path(command.program).name} {' '.join(command.arguments)}\n")
        self.process.start(command.program, command.arguments)

    def _start_run_phase(self):
        self._phase = "run"
        self.status_label.setText("Kører…")
        self.send_button.setEnabled(True)
        self.input_field.setEnabled(True)
        self.input_field.setFocus()
        self._start(self._plan.run)

    def _read_stdout(self):
        data = bytes(self.process.readAllStandardOutput()).decode(
            "utf-8", errors="replace"
        )
        self._append(data)

    def _read_stderr(self):
        data = bytes(self.process.readAllStandardError()).decode(
            "utf-8", errors="replace"
        )
        self._append(data)

    def _finished(self, exit_code: int, _exit_status):
        if self._phase == "compile" and exit_code == 0:
            self._append("Kompilering fuldført.\n")
            self._start_run_phase()
            return
        self._append(f"\nProces afsluttet med kode {exit_code}.\n")
        self.status_label.setText(
            "Færdig" if exit_code == 0 else f"Fejl · exit {exit_code}"
        )
        self.stop_button.setEnabled(False)
        self.send_button.setEnabled(False)
        self.input_field.setEnabled(False)
        self._phase = "idle"

    def _process_error(self, error):
        if error == QProcess.ProcessError.FailedToStart:
            self.status_label.setText("Kunne ikke starte")
            self._append(f"Processen kunne ikke startes: {self.process.errorString()}\n")
            self.stop_button.setEnabled(False)
            self.send_button.setEnabled(False)
            self.input_field.setEnabled(False)

    def send_input(self):
        if (
            self._phase != "run"
            or self.process.state() == QProcess.ProcessState.NotRunning
        ):
            return
        text = self.input_field.text()
        self.process.write((text + "\n").encode("utf-8"))
        self._append(f"> {text}\n")
        self.input_field.clear()

    def stop(self):
        if self.process.state() == QProcess.ProcessState.NotRunning:
            return
        self.status_label.setText("Stopper…")
        self.process.terminate()
        QTimer.singleShot(
            1500,
            lambda: self.process.kill()
            if self.process.state() != QProcess.ProcessState.NotRunning
            else None,
        )

    def closeEvent(self, event: QCloseEvent):
        if self.process.state() != QProcess.ProcessState.NotRunning:
            self.process.kill()
            self.process.waitForFinished(1000)
        if self._temporary_directory is not None:
            self._temporary_directory.cleanup()
            self._temporary_directory = None
        super().closeEvent(event)
