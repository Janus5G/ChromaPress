# Refract Studio — ChromaPlex + PRISME bridge

Refract Editor now uses the visible product name **Refract Studio**. This build
keeps the existing ChromaPlex payload, address, wallet, and NaCl
encryption paths intact. It adds a light interface and an OPTB v1 bridge based
on the supplied PRISME 256-byte alphabet.

The program is the original Refract Editor layout and workflow: File/Run/
Settings/Help menus, New, Save, Open/Decompile, **SHIP TO CHROMAPLEX**,
encryption state, code editor, preview, Console, Debugger, and Bug Tracker.
It is not the separate browser demo.

## Binary model

One PRISME byte is encoded exactly as in `prisme-reference.html`:

- R, G, B, and V each carry one base-4 digit.
- UV carries `(R + G + B + V) mod 4`.
- Every value from `0x00` through `0xFF` therefore has one exact flash.
- In OPTB, a flash is serialized as five adjacent states in R/G/B/V/UV order.

No language envelope or replacement compiler is added. CPL remains the
high-level ChromaPlex language, CPA remains ChromaPlex Assembly, and PRISME is
the physical optical byte layer.

## Run

Install the dependencies from `requirements.txt`, then:

```bash
python run.py
```

The main window starts in full-screen mode. Press **F11** to switch between
full-screen and a maximized window.
The preview has its own **Fuld skærm** button; **Esc** or **F11** closes that
full-screen preview.

Use **Kør kode i eget vindue** or **Ctrl+F5** for code that cannot execute in
the HTML preview. The separate run window streams standard output and errors
and includes standard input, stop, clear, and rerun controls. Python,
JavaScript, TypeScript, C, C++, Rust, Go, Java, common script runtimes,
and PRISME ASM are supported
when the relevant local toolchain is installed. PRISME ASM uses its existing
256-byte instruction alphabet and a small local test VM. **F5 remains reserved
for SHIP TO CHROMAPLEX.**

The original CPL/CPA compiler, assembler, VM, and crystal simulator are bundled
byte-for-byte from the supplied `chromaplex_os_package.json`. Those files match
the `chromaplex-os-compiler` Git repository and remain unchanged. The corrected
official ChromaPlex OS v1.0.1 compiler and simulator are bundled alongside that
legacy reference. Compatibility handling is isolated in Refract's adapter; no
replacement compiler is introduced. Use **F6** to compile CPL to visible CPA,
or **Ctrl+F5** to compile and run it in the bundled VM.

The bottom **Optical Simulator** tab contains:

- a live PRISME colour-code view of the current program;
- the supplied Optical Routing Simulator physics dashboard;
- a read-only browser for the simulator source code.

The panel can be closed and reopened from **Vis → Vis Optical Routing
Simulator**. Missing optional runtimes and simulator packages can be handled
from **Indstillinger → Runtimes og installation**.

Open an OPTB `.bin` through **Åbn / Decompile**. A PRISME-grouped file can be
shown as PRISME assembler or decoded bytes in the selected source language.
A generic simulator stream that is not grouped into five-channel flashes opens
as lossless Spectral IR instead of being misidentified as program code.

Choose **Optical PRISME stream (`*.bin`)** in Save As to serialize the edited
source through the existing 256-byte PRISME mapping.

Run `python tests/verify_preservation.py` from the `desktop` directory to verify
that the wallet, canister, encryption, and SHIP functions still match the
original uploaded editor.

Run `python tests/verify_original_compiler.py` to verify that every bundled
`chromaplex_os/*.py` file still matches the original JSON package byte-for-byte.

Run `python tests/verify_corrected_chromaplex.py` to verify the synchronized
corrected ChromaPlex OS v1.0.1 source against its SHA-256 manifest.

See `TEST_RESULTS.txt` for the release verification summary and
`KNOWN_ISSUES.md` for the two deliberately deferred metadata-display/key tasks.
