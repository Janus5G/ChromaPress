from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parents[1]))

from refracteditor.optical_bridge import (  # noqa: E402
    bytes_to_prisme_stream,
    decode_optb,
    encode_optb,
    export_optical,
    prisme_stream_to_bytes,
)
from refracteditor.prisme_isa import assemble, byte_to_levels, disassemble, levels_to_byte  # noqa: E402


def test_all_256_prisme_characters_roundtrip():
    alphabet = bytes(range(256))
    stream = bytes_to_prisme_stream(alphabet)
    encoded = encode_optb(stream)
    assert prisme_stream_to_bytes(decode_optb(encoded)) == alphabet


def test_uv_checksum_for_all_256_characters():
    for value in range(256):
        assert levels_to_byte(byte_to_levels(value)) == value


def test_supplied_prisme_program_roundtrip():
    source = """
        SET A, 72
        OUT A
        SET A, 105
        OUT A
        HALT
    """
    machine_code = assemble(source)
    assert assemble(disassemble(machine_code)) == machine_code


def test_text_language_uses_prisme_alphabet_without_metadata_envelope():
    source = "var data = 255;"
    content = export_optical(source, "CPL")
    stream = decode_optb(content)
    assert prisme_stream_to_bytes(stream).decode("utf-8") == source
    assert len(stream.symbols) == len(source.encode("utf-8")) * 5
