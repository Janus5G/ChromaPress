"""Verify that critical code still matches the user's original Refract Editor."""

from __future__ import annotations

import ast
import hashlib
from pathlib import Path


EXPECTED = {
    "_ping_crystal": "d9afdfa546a71703237f1591f706a87e07a01ba457cc4f5c858ab6975e0c1d63",
    "_fetch_public_key": "586a03478a82d5afd3a5912a1581eecf228eff54253abceddf4e9b24275b340d",
    "fetch_key_from_wallet": "0cca38916e19a1cda690f895c8a1707ac2c131cfb6fdb0e78b8fddc56931b840",
    "encrypt_metadata": "4ec15397d7f17f767c6e30431be05a5f419b2149d5c1beea484fbfca642c959b",
    "ship_to_chromaplex": "05ea69450e700558688d20120fe926baf9c32b88b806037115b2315e687f1ce7",
    "_on_crystal_address_received": "ba86436cead4e584fad9fcef8550194e1f0e4a0414a361eeb2ca8ca3ef9a26f2",
    "_on_crystal_error": "d81ce083f2c1eaad07a6bae1bcd2deaa1ebf0bbb062ccc0f68dff1483630e016",
    "_ship_with_address": "a16b6caa20848172e32deee9b0f71b83d4abafe36cbe0501697735febccb6d7f",
}


def main() -> None:
    source = Path(__file__).parents[1] / "refracteditor" / "mainwindow.py"
    tree = ast.parse(source.read_text(encoding="utf-8"))
    found = {}
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in EXPECTED:
            normalized = ast.dump(node, include_attributes=False).encode()
            found[node.name] = hashlib.sha256(normalized).hexdigest()
    mismatches = {
        name: (EXPECTED[name], found.get(name))
        for name in EXPECTED
        if found.get(name) != EXPECTED[name]
    }
    if mismatches:
        raise SystemExit(f"Critical function mismatch: {mismatches}")
    print("PASS: shipping, wallet, canister, and encryption functions match the original.")


if __name__ == "__main__":
    main()
