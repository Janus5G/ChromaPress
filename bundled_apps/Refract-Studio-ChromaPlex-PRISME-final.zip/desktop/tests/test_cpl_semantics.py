"""Semantic compatibility checks against both documented chromaplex-os dialects."""

from __future__ import annotations

from pathlib import Path
import sys


DESKTOP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(DESKTOP))

from refracteditor.cpl_adapter import run_cpl
from chromaplex.cpa_assembler import assemble
from chromaplex.cpl_compiler import compile_cpl
from chromaplex.crystal_simulator import CrystalSimulator
from chromaplex.utils import (
    exponent_remainder_to_number,
    number_to_exponent_remainder,
)


TOOLCHAIN_SOURCE = """
var data = 1234567;
store data at (5, 5, 5) colour GREEN;
load result from (5, 5, 5) colour GREEN;
print result;
"""

SPECIFICATION_SOURCE = """
tal data = 1234567;
potens e = findEksponent(data);
tal rest = data - (2^e);
skriv_voxel(5, 5, 5) {
    kanal grøn = e, rest = rest;
}
"""


def main():
    toolchain = run_cpl(TOOLCHAIN_SOURCE)
    assert toolchain.dialect == "original ChromaPlex OS CPL v1.0.0"
    assert toolchain.output == [1234567]
    assert "SET_COLOR GREEN" in toolchain.cpa
    assert "1 voxels skrevet" in toolchain.state

    specification = run_cpl(SPECIFICATION_SOURCE)
    assert specification.dialect == "current chromaplex-os specification CPL"
    assert "LOAD.PAIR grøn, 20, 185991" in specification.cpa
    assert "STORE.C (5,5,5), grøn, grøn" in specification.cpa
    assert "Voxels i brug: 1" in specification.state

    corrected_cpa = compile_cpl(TOOLCHAIN_SOURCE)
    corrected_simulator = CrystalSimulator()
    corrected_output = corrected_simulator.execute_program(assemble(corrected_cpa))
    assert corrected_output == [1234567]

    assert number_to_exponent_remainder(0) == (0, 0)
    assert number_to_exponent_remainder(1) == (0, 1)
    assert exponent_remainder_to_number(0, 0) == 0
    assert exponent_remainder_to_number(0, 1) == 1

    print(
        "PASS: legacy and corrected CPL compile and execute; "
        "zero/one remain distinct."
    )


if __name__ == "__main__":
    main()
