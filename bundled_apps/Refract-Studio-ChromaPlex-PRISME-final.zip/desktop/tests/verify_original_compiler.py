"""Verify that bundled ChromaPlex compiler files match the original JSON package."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


DESKTOP = Path(__file__).resolve().parents[1]
VENDOR = DESKTOP / "vendor" / "chromaplex-toolchain"
PACKAGE = VENDOR / "chromaplex_os_package.json"


def digest(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def main():
    package = json.loads(PACKAGE.read_text(encoding="utf-8"))
    checked = 0
    for relative, original_text in package["files"].items():
        if not relative.startswith("chromaplex_os/"):
            continue
        bundled = VENDOR / relative
        assert bundled.exists(), f"Mangler: {relative}"
        expected = digest(original_text.encode("utf-8"))
        actual = digest(bundled.read_bytes())
        assert actual == expected, (
            f"Ændret originalfil: {relative}\n"
            f"forventet {expected}\nfaktisk   {actual}"
        )
        checked += 1
    assert checked == 10, f"Forventede 10 originale Python-filer, fik {checked}"
    print(f"PASS: {checked} ChromaPlex OS-filer matcher original JSON byte-for-byte.")


if __name__ == "__main__":
    main()
