"""Verify the corrected ChromaPlex OS source bundled with Refract Studio."""

from __future__ import annotations

from hashlib import sha256
from pathlib import Path


DESKTOP = Path(__file__).resolve().parents[1]
SOURCE = DESKTOP / "vendor" / "chromaplex-main" / "chromaplex"

EXPECTED_SHA256 = {
    "__init__.py": "9270ba1df54883b52e1b7fa242e473a5dcd367906a5fb098ab8d8ce6ca33626b",
    "ai_coder.py": "eb3a18551bdb94a6639dba9bae4b34f6966504d08e3666e10afa0ffd7e789a1a",
    "bf_compiler.py": "784b33a078105bae803e1e93870e1cf6fee960b1e3992932323245eb4f08db12",
    "cpa_assembler.py": "1108d530e00174b754553890af0aace7ae854dbae23e2cbfda483ef085ee11df",
    "cpl_compiler.py": "3a8ee5b06a50f6fe7b1e36b295adab5c3ee8b318e3970fd51e74f457f035cad5",
    "crystal_simulator.py": "373b60c6a6da3c1f6a190fe1a482ca8ede51d0dfd481ef2520ffea7f4d4b70eb",
    "utils.py": "8c0c803f9736368aec4a02333641318af1dd0e2077a254f446a8f779558baea4",
}


def main() -> None:
    actual_names = {path.name for path in SOURCE.glob("*.py")}
    assert actual_names == set(EXPECTED_SHA256), (
        f"Uventede ChromaPlex-kildefiler: {sorted(actual_names)}"
    )

    for name, expected in EXPECTED_SHA256.items():
        actual = sha256((SOURCE / name).read_bytes()).hexdigest()
        assert actual == expected, (
            f"{name} matcher ikke den verificerede ChromaPlex OS v1.0.1-kilde"
        )

    print("PASS: 7 korrigerede ChromaPlex OS-kildefiler matcher SHA-256-manifestet.")


if __name__ == "__main__":
    main()
