# Known deferred metadata issues

These issues are intentionally outside this release. The verified SHIP,
wallet, canister, ledger-proof, hashing, and encryption paths remain unchanged.

1. **Received date displays `Invalid Date`**
   - The receiving application most likely interprets Unix seconds as
     milliseconds.
   - Correct the display conversion in the receiving entry-details view.

2. **Metadata cannot be decrypted**
   - The current private key/recipient does not resolve the encrypted metadata
     associated with key ID `rdmx6-jaaaa-aaaaa-aaadq-cai`.
   - Key distribution and recipient matching must be investigated separately.

Neither issue invalidates the received payload ID, source address, extraction
hash, numeric representation, or ledger proofs.
